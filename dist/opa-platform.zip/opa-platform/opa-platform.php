<?php
/**
 * Plugin Name: Opa Platform
 * Description: Replaces WordPress admin with the Opa branded SPA.
 * Version: 0.1.0
 * Requires PHP: 8.0
 * Network: true
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OPA_PLATFORM_VERSION', '0.1.0' );
define( 'OPA_PLATFORM_DIR', __DIR__ . '/opa-platform/' );

// Resolve OPA_PLATFORM_URL from where this loader lives. Two install shapes:
//   - mu-plugin (Pressable, Studio): /wp-content/mu-plugins/opa-platform.php
//   - regular plugin (Playground installPlugin): /wp-content/plugins/<slug>/opa-platform.php
// basename(__DIR__) gives the parent dir name regardless of symlinks.
// Use content_url() (not plugin_dir_url — that follows symlinks and breaks Studio).
$opa_parent_dir = basename( __DIR__ );
if ( 'mu-plugins' === $opa_parent_dir ) {
	define( 'OPA_PLATFORM_URL', content_url( 'mu-plugins/opa-platform/' ) );
} else {
	define( 'OPA_PLATFORM_URL', content_url( 'plugins/' . $opa_parent_dir . '/opa-platform/' ) );
}
unset( $opa_parent_dir );

require_once OPA_PLATFORM_DIR . 'includes/admin-page.php';
require_once OPA_PLATFORM_DIR . 'includes/admin-redirect.php';
require_once OPA_PLATFORM_DIR . 'includes/welcome-post.php';
require_once OPA_PLATFORM_DIR . 'includes/editor-curation.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-create-draft.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-dashboard-rhythm.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-user-avatar.php';
require_once OPA_PLATFORM_DIR . 'includes/user-preferences.php';
require_once OPA_PLATFORM_DIR . 'includes/public-toolbar.php';
require_once OPA_PLATFORM_DIR . 'includes/default-category.php';

// Multisite onboarding: provisioning, login + email branding, WP-CLI ops.
require_once OPA_PLATFORM_DIR . 'includes/multisite-provisioning.php';
require_once OPA_PLATFORM_DIR . 'includes/login-url-rewrite.php';
require_once OPA_PLATFORM_DIR . 'includes/email-shell.php';     // opa_email_shell() helper — load before email-branding.php
require_once OPA_PLATFORM_DIR . 'includes/email-branding.php';
require_once OPA_PLATFORM_DIR . 'includes/login-branding.php';
require_once OPA_PLATFORM_DIR . 'includes/cli-create-site.php';
