<?php
/**
 * Plugin Name: Opa Platform
 * Description: Replaces WordPress admin with the Opa branded SPA.
 * Version: 0.1.0
 * Requires PHP: 8.0
 * Network: true
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OPA_PLATFORM_VERSION', '0.1.0' );
define( 'OPA_PLATFORM_DIR', __DIR__ . '/opa-platform/' );
define( 'OPA_PLATFORM_URL', content_url( 'mu-plugins/opa-platform/' ) );

require_once OPA_PLATFORM_DIR . 'includes/admin-page.php';
require_once OPA_PLATFORM_DIR . 'includes/admin-redirect.php';
require_once OPA_PLATFORM_DIR . 'includes/editor-curation.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-create-draft.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-dashboard-rhythm.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-user-avatar.php';
require_once OPA_PLATFORM_DIR . 'includes/user-preferences.php';
require_once OPA_PLATFORM_DIR . 'includes/public-toolbar.php';
require_once OPA_PLATFORM_DIR . 'includes/default-category.php';

// Multisite onboarding: provisioning, login + email branding, WP-CLI ops.
require_once OPA_PLATFORM_DIR . 'includes/multisite-provisioning.php';
require_once OPA_PLATFORM_DIR . 'includes/login-url-rewrite.php';
require_once OPA_PLATFORM_DIR . 'includes/email-shell.php';     // opa_email_shell() helper — load before email-branding.php
require_once OPA_PLATFORM_DIR . 'includes/email-branding.php';
require_once OPA_PLATFORM_DIR . 'includes/login-branding.php';
require_once OPA_PLATFORM_DIR . 'includes/cli-create-site.php';
