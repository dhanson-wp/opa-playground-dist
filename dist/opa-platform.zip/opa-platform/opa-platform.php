<?php
/**
 * Plugin Name: Opa Platform
 * Description: Replaces WordPress admin with the Opa branded SPA.
 * Version: 0.1.0
 * Requires PHP: 8.0
 * Network: true
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OPA_PLATFORM_VERSION', '0.1.0' );
define( 'OPA_PLATFORM_DIR', __DIR__ . '/opa-platform/' );
// Resolve URL from where this loader file is located. We support two install
// shapes — mu-plugin (production: Pressable, Studio) and regular plugin
// (Playground distribution).
//
// Detection by parent directory name (basename of __DIR__) — works regardless
// of how PHP resolves symlinks. In mu-plugin form __DIR__ ends in
// `/mu-plugins`; in plugin form it ends in `/plugins/<plugin-slug>`. We use
// content_url() to construct URLs (rather than plugin_dir_url, which follows
// symlinks and yields paths Studio's server doesn't route).
$opa_parent_dir = basename( __DIR__ );
if ( 'mu-plugins' === $opa_parent_dir ) {
	define( 'OPA_PLATFORM_URL', content_url( 'mu-plugins/opa-platform/' ) );
} else {
	define( 'OPA_PLATFORM_URL', content_url( 'plugins/' . $opa_parent_dir . '/opa-platform/' ) );
}
unset( $opa_parent_dir );

require_once OPA_PLATFORM_DIR . 'includes/admin-page.php';
require_once OPA_PLATFORM_DIR . 'includes/admin-redirect.php';
require_once OPA_PLATFORM_DIR . 'includes/editor-curation.php';
require_once OPA_PLATFORM_DIR . 'includes/rest-create-draft.php';
require_once OPA_PLATFORM_DIR . 'includes/user-preferences.php';
require_once OPA_PLATFORM_DIR . 'includes/public-toolbar.php';
