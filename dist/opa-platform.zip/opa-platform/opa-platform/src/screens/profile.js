import {
	Button,
	TextControl,
	TextareaControl,
	Spinner,
} from '@wordpress/components';
import { useSelect, useDispatch } from '@wordpress/data';
import { useEntityProp, store as coreStore } from '@wordpress/core-data';
import { Camera, Key, SignOut, PlusCircle, Check } from '@phosphor-icons/react';

/**
 * Profile screen — public identity (left) + account/writing goals (right).
 *
 * Display name + bio persist to /wp/v2/users/me via core-data.
 * Username and email are read-only (account-managed elsewhere).
 * Goals are stubbed in v0; "Add goal" is disabled with a tooltip.
 */
export default function ProfileScreen() {
	const userId = useSelect(
		( select ) => select( coreStore ).getCurrentUser()?.id,
		[]
	);

	if ( ! userId ) {
		return (
			<div className="opa-screen opa-screen-profile">
				<Spinner />
			</div>
		);
	}

	return <ProfileForm userId={ userId } />;
}

function ProfileForm( { userId } ) {
	const [ name, setName ] = useEntityProp( 'root', 'user', 'name', userId );
	const [ description, setDescription ] = useEntityProp(
		'root',
		'user',
		'description',
		userId
	);
	const [ slug ] = useEntityProp( 'root', 'user', 'slug', userId );
	const [ email ] = useEntityProp( 'root', 'user', 'email', userId );

	const initial = ( name || 'D' ).trim().charAt( 0 ).toUpperCase();

	return (
		<div className="opa-screen opa-screen-profile">
			<div className="opa-profile-grid">
				<div className="opa-profile-stack">
					<article className="opa-card opa-profile-head">
						<div className="opa-profile-avatar">{ initial }</div>
						<div className="opa-profile-head-text">
							<div className="opa-eyebrow">Profile</div>
							<h2 className="opa-profile-name">
								{ name || 'Your name' }
							</h2>
							<p className="opa-profile-byline">
								How you show up inside Opa and across your
								public blog.
							</p>
						</div>
						<Button
							variant="secondary"
							icon={ <Camera weight="bold" /> }
							className="opa-btn-soft"
							disabled
							title="Coming soon"
						>
							Change photo
						</Button>
					</article>

					<article className="opa-card">
						<h3 className="opa-card-title">Public identity</h3>
						<div className="opa-form-grid">
							<TextControl
								label="Display name"
								value={ name || '' }
								onChange={ setName }
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
							<TextControl
								label="Public handle"
								value={ slug || '' }
								onChange={ () => {} }
								readOnly
								help="Set on signup; cannot be changed."
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
							<TextareaControl
								label="Bio"
								value={ description || '' }
								onChange={ setDescription }
								rows={ 2 }
								__nextHasNoMarginBottom
							/>
							<div className="opa-form-actions">
								<SaveProfileButton userId={ userId } />
							</div>
						</div>
					</article>
				</div>

				<aside className="opa-profile-stack">
					<article className="opa-card">
						<h3 className="opa-card-title">Account</h3>
						<p className="opa-card-subtitle">
							Some account details are permanent.
						</p>
						<div className="opa-form-grid">
							<div className="opa-readonly-row">
								<strong>{ slug || '—' }</strong>
								<span>Username cannot be changed</span>
							</div>
							<div className="opa-readonly-row">
								<strong>{ email || '—' }</strong>
								<span>Email managed by account</span>
							</div>
							<Button
								variant="secondary"
								icon={ <Key weight="bold" /> }
								className="opa-btn-soft opa-btn-soft--full"
								disabled
								title="Coming soon"
							>
								Reset password
							</Button>
							<Button
								variant="secondary"
								icon={ <SignOut weight="bold" /> }
								className="opa-btn-soft opa-btn-soft--full opa-btn-soft--danger"
								href={ window.opaSettings?.logoutUrl || '#' }
							>
								Sign out
							</Button>
						</div>
					</article>

					<article className="opa-card">
						<h3 className="opa-card-title">Writing goals</h3>
						<p className="opa-card-subtitle">
							Personalize the momentum nudges on your dashboard.
						</p>
						<div className="opa-goal-list">
							<GoalItem
								text="Write 4 days each week"
								done={ false }
							/>
							<GoalItem
								text="Publish every Friday"
								done={ false }
							/>
						</div>
						<button
							className="opa-add-goal"
							disabled
							title="Coming soon"
						>
							<PlusCircle weight="bold" size={ 16 } />
							Add goal
						</button>
					</article>
				</aside>
			</div>
		</div>
	);
}

function SaveProfileButton( { userId } ) {
	const { isSaving, hasEdits } = useSelect(
		( select ) => {
			const core = select( coreStore );
			return {
				isSaving: core.isSavingEntityRecord( 'root', 'user', userId ),
				hasEdits: core.hasEditsForEntityRecord(
					'root',
					'user',
					userId
				),
			};
		},
		[ userId ]
	);

	const { saveEditedEntityRecord } = useDispatch( coreStore );

	return (
		<Button
			variant="primary"
			isBusy={ isSaving }
			disabled={ ! hasEdits || isSaving }
			onClick={ () => saveEditedEntityRecord( 'root', 'user', userId ) }
			className="opa-btn-primary"
		>
			Save profile
		</Button>
	);
}

function GoalItem( { text, done } ) {
	return (
		<div className="opa-goal-item">
			<span className={ `opa-goal-check${ done ? ' done' : '' }` }>
				{ done && <Check weight="bold" size={ 14 } /> }
			</span>
			<span>{ text }</span>
		</div>
	);
}
