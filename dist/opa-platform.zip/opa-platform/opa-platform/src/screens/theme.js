export default function ThemeScreen() {
	return (
		<div className="opa-screen opa-screen-theme">
			<div className="opa-placeholder-card">
				<h2>Theme</h2>
				<p>Choose a visual style for your blog. Coming soon.</p>
			</div>
		</div>
	);
}
