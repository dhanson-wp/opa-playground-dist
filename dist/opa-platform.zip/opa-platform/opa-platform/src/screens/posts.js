import { useEntityRecords } from '@wordpress/core-data';
import { Spinner } from '@wordpress/components';

export default function PostsScreen( { onNavigate } ) {
	const { records: posts, isResolving } = useEntityRecords(
		'postType',
		'post',
		{ status: 'publish', per_page: 20, orderby: 'date', order: 'desc' }
	);

	if ( isResolving ) {
		return (
			<div className="opa-screen opa-screen-posts">
				<Spinner />
			</div>
		);
	}

	if ( ! posts || posts.length === 0 ) {
		return (
			<div className="opa-screen opa-screen-posts">
				<div className="opa-placeholder-card">
					<p>No published posts yet. Write your first one.</p>
				</div>
			</div>
		);
	}

	return (
		<div className="opa-screen opa-screen-posts">
			<div className="opa-posts-list">
				{ posts.map( ( post ) => (
					<button
						key={ post.id }
						className="opa-post-row"
						onClick={ () => onNavigate( 'editor', post.id ) }
					>
						<span className="opa-post-title">
							{ post.title.rendered || '(Untitled)' }
						</span>
						<span className="opa-post-date">
							{ new Date( post.date ).toLocaleDateString() }
						</span>
					</button>
				) ) }
			</div>
		</div>
	);
}
