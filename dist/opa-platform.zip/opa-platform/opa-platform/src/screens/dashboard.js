import { useMemo, useState } from '@wordpress/element';
import { useEntityRecords } from '@wordpress/core-data';
import {
	Fire,
	PencilSimpleLine,
	SealCheck,
	ChartLineUp,
} from '@phosphor-icons/react';
import HeroCapture from '../components/dashboard/hero-capture';
import StatCard from '../components/dashboard/stat-card';
import ResumeWriting from '../components/dashboard/resume-writing';
import RhythmGrid from '../components/dashboard/rhythm-grid';
import RecentActivity from '../components/dashboard/recent-activity';
import WelcomeOverlay from '../components/welcome-overlay';

/**
 * Dashboard v2 — positive momentum, no word-count pressure.
 *
 * Real data via core-data:
 *  - Living drafts count
 *  - Posts published count + this-week footnote
 *  - Resume writing list (top 2 drafts by modified)
 *  - Recent activity (top 4 posts by modified)
 *
 * Stubbed in v0 with realistic placeholders + visible "next pass" cues:
 *  - Active days
 *  - Views this week
 *  - 14-day rhythm grid
 *  - Goals
 * @param {Object}   props
 * @param {Function} [props.onNavigate] (target, postId) => void from app-shell.
 */
export default function DashboardScreen( { onNavigate } ) {
	const [ welcomeDismissed, setWelcomeDismissed ] = useState( false );

	const draftsQuery = useMemo(
		() => ( {
			// `auto-draft` covers posts started via the hero capture but not
			// yet edited. WP garbage-collects them after 7 days, so they read
			// naturally as "living drafts" in the stats.
			status: [ 'draft', 'auto-draft' ],
			per_page: 100,
			_fields: [ 'id', 'modified' ],
		} ),
		[]
	);
	const publishedQuery = useMemo(
		() => ( {
			status: 'publish',
			per_page: 100,
			_fields: [ 'id', 'date' ],
		} ),
		[]
	);

	const { records: drafts, hasResolved: draftsResolved } = useEntityRecords(
		'postType',
		'post',
		draftsQuery
	);
	const { records: published, hasResolved: publishedResolved } =
		useEntityRecords( 'postType', 'post', publishedQuery );

	// First-run detection: both queries resolved and both empty. Shows
	// the welcome overlay on top of the dashboard for new users / Playground
	// testers. Auto-hides as soon as any post exists. "Skip for now" only
	// dismisses for the current session (no localStorage / user-meta flag).
	const showWelcome =
		! welcomeDismissed &&
		draftsResolved &&
		publishedResolved &&
		( drafts?.length ?? 0 ) === 0 &&
		( published?.length ?? 0 ) === 0;

	const draftsCount = drafts?.length ?? 0;
	const publishedCount = published?.length ?? 0;
	const publishedThisWeek = useMemo( () => {
		if ( ! published ) {
			return 0;
		}
		const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
		return published.filter( ( p ) => {
			const ts = p.date ? new Date( p.date ).getTime() : 0;
			return ts >= cutoff;
		} ).length;
	}, [ published ] );

	return (
		<div className="opa-screen opa-screen-dashboard">
			{ showWelcome && (
				<WelcomeOverlay
					onNavigate={ onNavigate }
					onDismiss={ () => setWelcomeDismissed( true ) }
				/>
			) }
			<HeroCapture onNavigate={ onNavigate } />

			<div className="opa-dashboard-grid">
				<div className="opa-dashboard-stack">
					<div className="opa-stat-grid">
						<StatCard
							icon={ Fire }
							value="5"
							label="active days"
							note="ideas, edits, or publishes"
							color="#FF5A5F"
							bg="#FFF1EC"
						/>
						<StatCard
							icon={ PencilSimpleLine }
							value={ String( draftsCount ) }
							label="living drafts"
							note={
								draftsCount
									? 'touched recently'
									: 'start one to begin'
							}
							color="#7C3AED"
							bg="#F3E8FF"
						/>
						<StatCard
							icon={ SealCheck }
							value={ String( publishedCount ) }
							label="posts published"
							note={
								publishedThisWeek
									? `${ publishedThisWeek } this week`
									: 'all time'
							}
							color="#FF7EB6"
							bg="#FFE8F2"
						/>
						<StatCard
							icon={ ChartLineUp }
							value="—"
							label="views this week"
							note="ships with stats"
							color="#2563EB"
							bg="#E8F1FF"
						/>
					</div>

					<ResumeWriting onNavigate={ onNavigate } />
				</div>

				<aside className="opa-dashboard-stack">
					<RhythmGrid />
					<RecentActivity />
				</aside>
			</div>
		</div>
	);
}
