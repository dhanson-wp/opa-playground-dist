export default function SettingsScreen() {
	return (
		<div className="opa-screen opa-screen-settings">
			<div className="opa-placeholder-card">
				<h2>Settings</h2>
				<p>Configure your site. Coming soon.</p>
			</div>
		</div>
	);
}
