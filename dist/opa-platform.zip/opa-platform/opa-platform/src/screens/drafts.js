import { useEntityRecords } from '@wordpress/core-data';
import { Spinner } from '@wordpress/components';

export default function DraftsScreen( { onNavigate } ) {
	const { records: drafts, isResolving } = useEntityRecords(
		'postType',
		'post',
		{ status: 'draft', per_page: 20, orderby: 'modified', order: 'desc' }
	);

	if ( isResolving ) {
		return (
			<div className="opa-screen opa-screen-drafts">
				<Spinner />
			</div>
		);
	}

	if ( ! drafts || drafts.length === 0 ) {
		return (
			<div className="opa-screen opa-screen-drafts">
				<div className="opa-placeholder-card">
					<p>No drafts yet. Start writing something.</p>
				</div>
			</div>
		);
	}

	return (
		<div className="opa-screen opa-screen-drafts">
			<div className="opa-drafts-grid">
				{ drafts.map( ( draft ) => (
					<button
						key={ draft.id }
						className="opa-draft-card"
						onClick={ () => onNavigate( 'editor', draft.id ) }
					>
						<h3>{ draft.title.rendered || '(Untitled)' }</h3>
						<p className="opa-draft-excerpt">
							{ draft.excerpt?.rendered?.replace( /<[^>]+>/g, '' ).slice( 0, 120 ) || '' }
						</p>
						<span className="opa-draft-date">
							{ new Date( draft.modified ).toLocaleDateString() }
						</span>
					</button>
				) ) }
			</div>
		</div>
	);
}
