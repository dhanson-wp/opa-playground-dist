import { useState, useEffect, useMemo, useRef } from '@wordpress/element';
import { useEntityRecord } from '@wordpress/core-data';
import {
	BlockList,
	BlockCanvas,
	RecursionProvider,
	store as blockEditorStore,
	useSettings,
} from '@wordpress/block-editor';
import { EditorProvider, PostTitle, store as editorStore } from '@wordpress/editor';
import { Spinner, Button } from '@wordpress/components';
import { useDispatch, useSelect } from '@wordpress/data';
import { store as preferencesStore } from '@wordpress/preferences';
import { Eye } from '@phosphor-icons/react';
import apiFetch from '@wordpress/api-fetch';
import SaveStatus from '../components/save-status';
import PublishDrawer from '../components/publish-drawer';
import PreviewModal from '../components/preview-modal';
import PostSubtitle from '../components/post-subtitle';
import FloatingToolbar from '../components/floating-toolbar';
import '@wordpress/format-library';

export default function EditorScreen( { postId, onBack, referrer } ) {
	const [ activePostId, setActivePostId ] = useState( postId );
	const [ error, setError ] = useState( null );
	const { receiveEntityRecords } = useDispatch( 'core' );

	// Create a new auto-draft if no postId provided.
	// The endpoint returns the full post object so we can pre-seed core-data
	// and skip the second REST fetch from useEntityRecord.
	useEffect( () => {
		if ( ! postId ) {
			apiFetch( {
				path: '/opa/v1/create-draft',
				method: 'POST',
			} ).then( ( response ) => {
				if ( response?.id ) {
					receiveEntityRecords( 'postType', 'post', [ response ], {}, false );
					setActivePostId( response.id );
				} else {
					setError( 'Failed to create new post.' );
				}
			} ).catch( ( err ) => {
				// eslint-disable-next-line no-console
				console.error( '[opa] Failed to create draft:', err );
				setError( err.message || 'Failed to create new post.' );
			} );
		}
	}, [ postId ] );

	if ( error ) {
		return (
			<div className="opa-editor-loading">
				<p>{ error }</p>
				<Button variant="secondary" onClick={ onBack }>Go back</Button>
			</div>
		);
	}

	if ( ! activePostId ) {
		return (
			<div className="opa-editor-loading">
				<Spinner />
			</div>
		);
	}

	return <EditorCanvas postId={ activePostId } onBack={ onBack } referrer={ referrer } />;
}

function EditorCanvas( { postId, onBack } ) {
	const editorSettings = useMemo( () => ( {
		...( window.opaSettings?.editorSettings || {} ),
		// REQ-1 (Phase 2.65b): suppress the native contextual block-toolbar
		// popover (gate in @wordpress/block-editor BlockTools is `! isZoomOutMode
		// && ! hasFixedToolbar`). Our <FloatingToolbar /> renders the public
		// <BlockToolbar /> inside an Opa-styled <Popover> anchored to the
		// selection rect. We don't render <Header /> from @wordpress/editor,
		// so this setting does NOT mount any extra fixed toolbar UI.
		hasFixedToolbar: true,
	} ), [] );

	const contentRef = useRef();

	const { record: post, isResolving } = useEntityRecord(
		'postType',
		'post',
		postId
	);

	const { saveEditedEntityRecord } = useDispatch( 'core' );

	const [ showPublishDrawer, setShowPublishDrawer ] = useState( false );
	const [ showPreview, setShowPreview ] = useState( false );
	const [ isSavingClose, setIsSavingClose ] = useState( false );

	const { hasEdits } = useSelect(
		( select ) => ( {
			hasEdits: select( 'core' ).hasEditsForEntityRecord( 'postType', 'post', postId ),
		} ),
		[ postId ]
	);

	useEffect( () => {
		if ( ! hasEdits ) {
			return;
		}
		const timer = setTimeout( () => {
			saveEditedEntityRecord( 'postType', 'post', postId );
		}, 5000 );
		return () => clearTimeout( timer );
	}, [ hasEdits, postId ] );

	const handleSaveAndClose = async () => {
		setIsSavingClose( true );
		try {
			await saveEditedEntityRecord( 'postType', 'post', postId );
			onBack();
		} catch ( err ) {
			// eslint-disable-next-line no-console
			console.error( '[opa] Save & close failed:', err );
			setIsSavingClose( false );
		}
	};

	const handlePreview = async () => {
		await saveEditedEntityRecord( 'postType', 'post', postId );
		setShowPreview( true );
	};

	if ( isResolving || ! post ) {
		return (
			<div className="opa-editor-loading">
				<Spinner />
			</div>
		);
	}

	return (
		<>
			<EditorProvider
				post={ post }
				settings={ editorSettings }
			>
				<div className="opa-editor">
					<div className="opa-editor-topbar">
						<button
							className="opa-editor-back"
							onClick={ handleSaveAndClose }
							disabled={ isSavingClose }
						>
							<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
								<line x1="19" y1="12" x2="5" y2="12" />
								<polyline points="12 19 5 12 12 5" />
							</svg>
							{ isSavingClose ? 'Saving...' : 'Save & close' }
						</button>
						<SaveStatus postId={ postId } />
						<div className="opa-editor-actions">
							<Button variant="secondary" icon={ <Eye weight="bold" /> } onClick={ handlePreview }>
								Preview
							</Button>
							<Button variant="primary" onClick={ () => setShowPublishDrawer( true ) }>
								Publish
							</Button>
						</div>
					</div>

					<div className="opa-editor-scroll">
						<div className="opa-editor-area">
							<NativePostCanvas
								contentRef={ contentRef }
								postId={ postId }
							/>
						</div>
					</div>
				</div>
				<FloatingToolbar />
			</EditorProvider>

			{ showPublishDrawer && (
				<PublishDrawer
					postId={ postId }
					onClose={ () => setShowPublishDrawer( false ) }
					onSuccess={ onBack }
				/>
			) }

			{ showPreview && (
				<PreviewModal
					postId={ postId }
					onClose={ () => setShowPreview( false ) }
				/>
			) }
		</>
	);
}

function NativePostCanvas( { contentRef, postId } ) {
	const {
		canvasStyles,
		hasRootPaddingAwareAlignments,
		themeHasDisabledLayoutStyles,
		themeSupportsLayout,
		postContentAttributes,
		toolbarMode,
	} = useSelect(
		( select ) => {
			const blockEditorSettings = select( blockEditorStore ).getSettings();
			const currentEditorSettings =
				select( editorStore ).getEditorSettings?.() || {};

			return {
				canvasStyles: currentEditorSettings.styles,
				postContentAttributes:
					currentEditorSettings.postContentAttributes,
				themeHasDisabledLayoutStyles:
					blockEditorSettings.disableLayoutStyles,
				themeSupportsLayout: blockEditorSettings.supportsLayout,
				hasRootPaddingAwareAlignments:
					blockEditorSettings.__experimentalFeatures
						?.useRootPaddingAwareAlignments,
				toolbarMode:
					select( preferencesStore ).get( 'opa', 'toolbarMode' ) ||
					'floating',
			};
		},
		[]
	);

	// Push the post title further down when the fixed toolbar is active so it
	// clears the pinned pill (which lives at viewport top:88px). 4rem is the
	// floating-mode default; 6rem opens up balanced breathing room around the
	// fixed toolbar without leaving a yawning blank zone.
	const titleMarginTop = toolbarMode === 'fixed' ? '6rem' : '4rem';

	const [ globalLayoutSettings = {} ] = useSettings( 'layout' );
	const contentAttributes = postContentAttributes || {};
	const { layout = {}, align = '' } = contentAttributes;

	const fallbackLayout = useMemo( () => {
		if ( themeSupportsLayout ) {
			return { ...globalLayoutSettings, type: 'constrained' };
		}

		return { type: 'default' };
	}, [ themeSupportsLayout, globalLayoutSettings ] );

	const blockListLayoutClass = [
		`is-layout-${ blockListLayoutType( layout, themeSupportsLayout ) }`,
		align && `align${ align }`,
	].filter( Boolean ).join( ' ' );

	const postContentLayout = useMemo( () => {
		return layout &&
			( layout?.type === 'constrained' ||
				layout?.inherit ||
				layout?.contentSize ||
				layout?.wideSize )
			? { ...globalLayoutSettings, ...layout, type: 'constrained' }
			: { ...globalLayoutSettings, ...layout, type: 'default' };
	}, [
		layout?.type,
		layout?.inherit,
		layout?.contentSize,
		layout?.wideSize,
		globalLayoutSettings,
	] );

	const blockListLayout = postContentAttributes
		? postContentLayout
		: fallbackLayout;

	const titleWrapperClass = [
		'editor-visual-editor__post-title-wrapper',
		'edit-post-visual-editor__post-title-wrapper',
		hasRootPaddingAwareAlignments && 'has-global-padding',
	].filter( Boolean ).join( ' ' );

	const subtitleWrapperClass = [
		'opa-post-subtitle-wrapper',
		'is-layout-constrained',
		hasRootPaddingAwareAlignments && 'has-global-padding',
	].filter( Boolean ).join( ' ' );

	const blockListClass = [
		blockListLayoutClass,
		'wp-block-post-content',
		hasRootPaddingAwareAlignments && 'has-global-padding',
	].filter( Boolean ).join( ' ' );

	return (
		<div className="editor-visual-editor edit-post-visual-editor is-iframed">
			<div className="opa-block-canvas">
				<BlockCanvas
					contentRef={ contentRef }
					height="100%"
					styles={ canvasStyles }
				>
					{ themeSupportsLayout && ! themeHasDisabledLayoutStyles && (
						<CoreLayoutStyles
							titleLayout={ fallbackLayout }
							blockListLayout={ blockListLayout }
						/>
					) }
					<div
						className={ titleWrapperClass }
						contentEditable={ false }
						style={ { marginTop: titleMarginTop } }
					>
						<PostTitle />
					</div>
					<div className={ subtitleWrapperClass }>
						<PostSubtitle postId={ postId } />
					</div>
					<RecursionProvider
						blockName="core/post-content"
						uniqueId={ postId }
					>
						<BlockList
							className={ blockListClass }
							layout={ blockListLayout }
						/>
					</RecursionProvider>
				</BlockCanvas>
			</div>
		</div>
	);
}

function blockListLayoutType( layout = {}, themeSupportsLayout ) {
	if ( ! themeSupportsLayout ) {
		return 'flow';
	}

	return layout?.type === 'default' ? 'flow' : 'constrained';
}

function CoreLayoutStyles( { titleLayout, blockListLayout } ) {
	const css = [
		getConstrainedLayoutCSS(
			'.editor-visual-editor__post-title-wrapper',
			titleLayout
		),
		getConstrainedLayoutCSS(
			'.block-editor-block-list__layout.is-root-container',
			blockListLayout
		),
	].join( '\n' );

	return css ? <style>{ css }</style> : null;
}

function getConstrainedLayoutCSS( selector, layout = {} ) {
	const { contentSize, wideSize, justifyContent } = layout;

	if (
		layout.type !== 'constrained' &&
		! layout.inherit &&
		! contentSize &&
		! wideSize
	) {
		return '';
	}

	const contentWidth = contentSize || wideSize;
	const wideWidth = wideSize || contentSize;
	const marginLeft =
		justifyContent === 'left' ? '0 !important' : 'auto !important';
	const marginRight =
		justifyContent === 'right' ? '0 !important' : 'auto !important';

	return `
		${ selector } > :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
			${ contentWidth ? `max-width: ${ contentWidth };` : '' }
			margin-left: ${ marginLeft };
			margin-right: ${ marginRight };
		}
		${ selector } > .alignwide {
			${ wideWidth ? `max-width: ${ wideWidth };` : '' }
		}
		${ selector } > .alignfull {
			max-width: none;
		}
	`;
}
