/**
 * Opa author chrome — dropdown toggle behavior.
 *
 * Vanilla JS, no dependencies. Enqueued by includes/public-toolbar.php on
 * the public frontend for logged-in users only. Idempotent: safe to load twice
 * (re-binding is a no-op via the data-bound flag).
 */
( function () {
	'use strict';

	function init() {
		var roots = document.querySelectorAll( '[data-opa-author-chrome]' );
		for ( var i = 0; i < roots.length; i++ ) {
			bind( roots[ i ] );
		}
	}

	function bind( root ) {
		if ( root.dataset.opaBound === '1' ) {
			return;
		}
		root.dataset.opaBound = '1';

		var trigger = root.querySelector( '[data-opa-author-trigger]' );
		if ( ! trigger ) {
			return;
		}

		function isOpen() {
			return root.classList.contains( 'is-open' );
		}

		function open() {
			root.classList.add( 'is-open' );
			trigger.setAttribute( 'aria-expanded', 'true' );
			document.addEventListener( 'pointerdown', onOutsidePointer, true );
			document.addEventListener( 'keydown', onKeydown, true );
		}

		function close( restoreFocus ) {
			if ( ! isOpen() ) {
				return;
			}
			root.classList.remove( 'is-open' );
			trigger.setAttribute( 'aria-expanded', 'false' );
			document.removeEventListener( 'pointerdown', onOutsidePointer, true );
			document.removeEventListener( 'keydown', onKeydown, true );
			if ( restoreFocus ) {
				trigger.focus();
			}
		}

		function onOutsidePointer( event ) {
			if ( ! root.contains( event.target ) ) {
				close( false );
			}
		}

		function onKeydown( event ) {
			if ( event.key === 'Escape' || event.key === 'Esc' ) {
				event.preventDefault();
				close( true );
			}
		}

		trigger.addEventListener( 'click', function ( event ) {
			event.preventDefault();
			if ( isOpen() ) {
				close( false );
			} else {
				open();
			}
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
