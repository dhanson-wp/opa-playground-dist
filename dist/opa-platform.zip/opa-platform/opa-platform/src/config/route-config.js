import {
	Gauge,
	NotePencil,
	Article,
	Drop,
	Gear,
	UserCircle,
} from '@phosphor-icons/react';

export const ROUTE_CONFIG = {
	dashboard: {
		label: 'Dashboard',
		icon: Gauge,
		section: 'content',
		topbar: { title: 'Dashboard', primaryAction: 'newPost' },
		mobileTab: 'home',
	},
	drafts: {
		label: 'Drafts',
		icon: NotePencil,
		section: 'content',
		topbar: { title: 'Drafts', primaryAction: 'newPost' },
		mobileTab: null,
	},
	posts: {
		label: 'Posts',
		icon: Article,
		section: 'content',
		topbar: { title: 'Posts', primaryAction: 'newPost' },
		mobileTab: 'posts',
	},
	theme: {
		label: 'Theme',
		icon: Drop,
		section: 'design',
		topbar: { title: 'Theme', primaryAction: null },
		mobileTab: null,
	},
	settings: {
		label: 'Settings',
		icon: Gear,
		section: 'design',
		topbar: { title: 'Settings', primaryAction: null },
		mobileTab: 'settings',
	},
	profile: {
		label: 'Profile',
		icon: UserCircle,
		section: null, // Reached via avatar click, not the nav rail.
		topbar: { title: 'Profile', primaryAction: null },
		mobileTab: null,
	},
	editor: {
		label: 'Editor',
		icon: null,
		section: null,
		topbar: null,
		mobileTab: null,
	},
};
