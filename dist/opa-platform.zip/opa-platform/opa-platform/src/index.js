import { createRoot } from '@wordpress/element';
import { registerCoreBlocks } from '@wordpress/block-library';
import apiFetch from '@wordpress/api-fetch';
import App from './components/app-shell';
import './brand/tokens.css';
import './brand/editor-overrides.css';
import './brand/welcome-overlay.css';
// Vendored design system. Phosphor styles load before opa-tokens.css so the
// font-face declarations (Bold + Duotone) are in scope when any component
// uses the .ph-bold / .ph-duotone classes.
import '../../../design-system/assets/phosphor/bold/style.css';
import '../../../design-system/assets/phosphor/duotone/style.css';
import '../../../design-system/tokens/opa-tokens.css';

// Ensure apiFetch has nonce auth for the SPA context.
// WordPress may already register middleware via inline scripts, but the nonce
// middleware is idempotent (just sets the X-WP-Nonce header).
apiFetch.use( apiFetch.createNonceMiddleware( window.opaSettings?.nonce ) );

// Register core block types so BlockEditorProvider can use them.
registerCoreBlocks();

const root = document.getElementById( 'opa-root' );
if ( root ) {
	createRoot( root ).render( <App /> );
}
