import { useSelect, useDispatch } from '@wordpress/data';
import { useEntityProp, store as coreStore } from '@wordpress/core-data';

/**
 * Reads/writes the per-user `opa_sidebar_expanded` boolean stored in user meta.
 * Returns [expanded, toggle] — `expanded` defaults to false until meta resolves.
 *
 * The meta key is registered server-side in includes/user-preferences.php with
 * show_in_rest:true and an auth_callback that scopes writes to the meta owner.
 */
export function useSidebarExpanded() {
	const userId = useSelect(
		( select ) => select( coreStore ).getCurrentUser()?.id,
		[]
	);
	const [ meta, setMeta ] = useEntityProp( 'root', 'user', 'meta', userId );
	const { saveEditedEntityRecord } = useDispatch( coreStore );

	const expanded = !! meta?.opa_sidebar_expanded;

	const toggle = () => {
		if ( ! userId ) {
			return;
		}
		setMeta( { ...meta, opa_sidebar_expanded: ! expanded } );
		saveEditedEntityRecord( 'root', 'user', userId );
	};

	return [ expanded, toggle ];
}
