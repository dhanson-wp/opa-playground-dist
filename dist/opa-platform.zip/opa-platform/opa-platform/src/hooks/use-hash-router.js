import { useState, useEffect, useCallback } from '@wordpress/element';

const ROUTES = {
	'/dashboard': { screen: 'dashboard' },
	'/drafts': { screen: 'drafts' },
	'/posts': { screen: 'posts' },
	'/editor': { screen: 'editor' },
	'/editor/:id': { screen: 'editor' },
	'/theme': { screen: 'theme' },
	'/settings': { screen: 'settings' },
	'/profile': { screen: 'profile' },
};

function parseHash( hash ) {
	const path = hash.replace( /^#/, '' ) || '/dashboard';

	// Check parameterized routes first (e.g., /editor/:id).
	for ( const [ pattern, config ] of Object.entries( ROUTES ) ) {
		const paramMatch = pattern.match( /^(.+)\/:(\w+)$/ );
		if ( paramMatch ) {
			const [ , base, paramName ] = paramMatch;
			if ( path.startsWith( base + '/' ) ) {
				const paramValue = parseInt( path.slice( base.length + 1 ), 10 );
				return {
					...config,
					params: { [ paramName ]: isNaN( paramValue ) ? undefined : paramValue },
				};
			}
		}
		if ( path === pattern ) {
			return { ...config, params: {} };
		}
	}

	// Fallback: unrecognized hash -> dashboard.
	return { screen: 'dashboard', params: {} };
}

export function useHashRouter() {
	const [ route, setRoute ] = useState( () => parseHash( window.location.hash ) );

	useEffect( () => {
		const onHashChange = () => setRoute( parseHash( window.location.hash ) );
		window.addEventListener( 'hashchange', onHashChange );
		return () => window.removeEventListener( 'hashchange', onHashChange );
	}, [] );

	const navigate = useCallback( ( path ) => {
		window.location.hash = path;
	}, [] );

	return { ...route, navigate };
}
