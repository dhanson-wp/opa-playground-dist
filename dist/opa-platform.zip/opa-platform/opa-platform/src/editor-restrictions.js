/**
 * Opa Editor Restrictions
 *
 * Removes inline formats, block styles, and embed variations using the
 * official WordPress JavaScript APIs (Layers 4-6 of the curation hierarchy).
 * These cleanups can't be expressed via theme.json or PHP filters.
 *
 * Tunable lists track:
 * .planning/phases/02.5-editor-experience-lock-in/02.5-TUNABLES.md
 */

import domReady from '@wordpress/dom-ready';
import { unregisterFormatType } from '@wordpress/rich-text';
import {
	unregisterBlockStyle,
	unregisterBlockVariation,
} from '@wordpress/blocks';

domReady( () => {
	// Layer 4 - inline format types to REMOVE.
	// Kept (not listed): core/bold, core/italic, core/link,
	//                    core/strikethrough, core/code.
	[
		'core/image',
		'core/language',
		'core/keyboard',
		'core/subscript',
		'core/superscript',
	].forEach( ( name ) => {
		unregisterFormatType( name );
	} );

	// Layer 5 - block styles to REMOVE.
	[
		[ 'core/image', 'rounded' ],
		[ 'core/quote', 'plain' ],
		[ 'core/table', 'stripes' ],
	].forEach( ( [ blockName, styleName ] ) => {
		unregisterBlockStyle( blockName, styleName );
	} );

	// Layer 6 - embed variations to REMOVE.
	// Kept (not listed): youtube, twitter, spotify, vimeo, soundcloud,
	//                    instagram, tiktok, wordpress, pocket-casts,
	//                    plus the generic embed variation.
	[
		'amazon-kindle',
		'animoto',
		'bluesky',
		'cloudup',
		'crowdsignal',
		'dailymotion',
		'flickr',
		'imgur',
		'issuu',
		'kickstarter',
		'mixcloud',
		'pinterest',
		'reddit',
		'reverbnation',
		'screencast',
		'scribd',
		'slideshare',
		'smugmug',
		'speaker-deck',
		'ted',
		'tumblr',
		'videopress',
		'wolfram-cloud',
		'wordpress-tv',
	].forEach( ( variation ) => {
		unregisterBlockVariation( 'core/embed', variation );
	} );
} );
