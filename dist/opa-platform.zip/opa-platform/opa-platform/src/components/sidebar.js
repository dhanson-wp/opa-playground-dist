import { SidebarSimple } from '@phosphor-icons/react';
import { useSelect } from '@wordpress/data';
import { store as coreStore } from '@wordpress/core-data';
import OpaLogo, { OpaSpark } from './opa-logo';
import { ROUTE_CONFIG } from '../config/route-config';
import { useSidebarExpanded } from '../hooks/use-sidebar-expanded';

const NAV_SECTIONS = [
	{
		label: 'Content',
		items: [ 'dashboard', 'drafts', 'posts' ],
	},
	{
		label: 'Design',
		items: [ 'theme', 'settings' ],
	},
];

export default function Sidebar( { active, onNavigate } ) {
	const [ expanded, toggleExpanded ] = useSidebarExpanded();
	const user = useSelect(
		( select ) => select( coreStore ).getCurrentUser(),
		[]
	);
	const siteHost =
		window.opaSettings?.siteUrl?.replace( /^https?:\/\//, '' ) ||
		'opa.blog';
	const userName = user?.name || '';
	const userInitial = ( userName || '·' ).trim().charAt( 0 ).toUpperCase();

	return (
		<aside
			className="opa-sidebar"
			data-expanded={ expanded ? 'true' : 'false' }
		>
			<div className="opa-sidebar-header">
				{ expanded ? (
					<OpaLogo height={ 27 } className="opa-sidebar-logo" />
				) : (
					<OpaSpark size={ 42 } />
				) }
				{ expanded && (
					<div className="opa-sidebar-blog">
						<span className="opa-online-dot" />
						{ siteHost }
					</div>
				) }
			</div>

			<nav className="opa-sidebar-nav">
				{ NAV_SECTIONS.map( ( section ) => (
					<div key={ section.label } className="opa-nav-section">
						{ expanded && (
							<div className="opa-nav-section-label">
								{ section.label }
							</div>
						) }
						{ section.items.map( ( key ) => {
							const config = ROUTE_CONFIG[ key ];
							if ( ! config ) {
								return null;
							}
							const NavIcon = config.icon;
							const isActive = active === key;
							return (
								<button
									key={ key }
									className={ `opa-nav-item${
										isActive ? ' active' : ''
									}` }
									onClick={ () => onNavigate( key ) }
									data-tooltip={ config.label }
								>
									<NavIcon
										weight={ isActive ? 'duotone' : 'bold' }
										size={ 22 }
									/>
									{ expanded && (
										<span className="opa-nav-item-label">
											{ config.label }
										</span>
									) }
								</button>
							);
						} ) }
					</div>
				) ) }
			</nav>

			<div className="opa-sidebar-spacer" />

			<button
				className="opa-sidebar-toggle"
				onClick={ toggleExpanded }
				title={ expanded ? 'Show icons only' : 'Show menu labels' }
				data-tooltip={
					expanded ? 'Show icons only' : 'Show menu labels'
				}
			>
				<SidebarSimple weight="bold" size={ 18 } />
				{ expanded && <span>Icons only</span> }
			</button>

			<button
				className={ `opa-sidebar-user${
					active === 'profile' ? ' active' : ''
				}` }
				onClick={ () => onNavigate( 'profile' ) }
				data-tooltip="Profile"
			>
				<span className="opa-avatar">{ userInitial }</span>
				{ expanded && (
					<span className="opa-user-info">
						<span className="opa-user-name">
							{ userName || ' ' }
						</span>
						<span className="opa-user-sub">
							Profile and account
						</span>
					</span>
				) }
			</button>
		</aside>
	);
}
