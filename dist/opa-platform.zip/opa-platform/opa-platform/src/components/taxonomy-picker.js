/**
 * Chip-style taxonomy input with autocomplete and inline term creation.
 * Uses FormTokenField for the UI, useEntityRecords for term lookup,
 * and saveEntityRecord for creating new terms.
 */

import { useEntityRecords, useEntityProp } from '@wordpress/core-data';
import { FormTokenField } from '@wordpress/components';
import { useDispatch } from '@wordpress/data';

export default function TaxonomyPicker( { postId, taxonomy, label } ) {
	const propField = taxonomy === 'category' ? 'categories' : 'tags';

	const [ termIds, setTermIds ] = useEntityProp(
		'postType',
		'post',
		propField,
		postId
	);

	const { records: allTerms } = useEntityRecords( 'taxonomy', taxonomy, {
		per_page: 100,
		orderby: 'count',
		order: 'desc',
	} );

	const { saveEntityRecord } = useDispatch( 'core' );

	const terms = allTerms || [];
	const suggestions = terms.map( ( t ) => t.name );
	const selectedTokens = terms
		.filter( ( t ) => ( termIds || [] ).includes( t.id ) )
		.map( ( t ) => t.name );

	const handleChange = async ( tokens ) => {
		const ids = [];

		for ( const token of tokens ) {
			// Case-insensitive lookup against existing terms.
			const existing = terms.find(
				( t ) => t.name.toLowerCase() === token.toLowerCase()
			);

			if ( existing ) {
				ids.push( existing.id );
			} else {
				// Create the term via REST and use the returned ID.
				const newTerm = await saveEntityRecord(
					'taxonomy',
					taxonomy,
					{ name: token }
				);
				if ( newTerm?.id ) {
					ids.push( newTerm.id );
				}
			}
		}

		setTermIds( ids );
	};

	return (
		<div className="opa-taxonomy-picker">
			<label>{ label }</label>
			<FormTokenField
				value={ selectedTokens }
				suggestions={ suggestions }
				onChange={ handleChange }
			/>
		</div>
	);
}
