import { useRef, useEffect } from '@wordpress/element';
import { useHashRouter } from '../hooks/use-hash-router';
import { useSidebarExpanded } from '../hooks/use-sidebar-expanded';
import { ROUTE_CONFIG } from '../config/route-config';
import Sidebar from './sidebar';
import Topbar from './topbar';
import BottomNav from './bottom-nav';
import DashboardScreen from '../screens/dashboard';
import PostsScreen from '../screens/posts';
import DraftsScreen from '../screens/drafts';
import EditorScreen from '../screens/editor';
import ThemeScreen from '../screens/theme';
import SettingsScreen from '../screens/settings';
import ProfileScreen from '../screens/profile';

const SCREENS = {
	dashboard: DashboardScreen,
	drafts: DraftsScreen,
	posts: PostsScreen,
	editor: EditorScreen,
	theme: ThemeScreen,
	settings: SettingsScreen,
	profile: ProfileScreen,
};

export default function App() {
	const { screen, params, navigate } = useHashRouter();
	const config = ROUTE_CONFIG[ screen ];
	const [ expanded ] = useSidebarExpanded();

	// Track the screen before editor navigation (D-12/D-13).
	const previousScreenRef = useRef( 'dashboard' );

	useEffect( () => {
		if ( screen !== 'editor' ) {
			previousScreenRef.current = screen;
		}
	}, [ screen ] );

	// Editor is full-bleed — no sidebar/topbar.
	if ( screen === 'editor' ) {
		return (
			<EditorScreen
				postId={ params.id || null }
				onBack={ () => navigate( '#/' + previousScreenRef.current ) }
				referrer={ previousScreenRef.current }
			/>
		);
	}

	const CurrentScreen = SCREENS[ screen ] || DashboardScreen;

	return (
		<div
			className="opa-app"
			data-sidebar-expanded={ expanded ? 'true' : 'false' }
		>
			<Sidebar
				active={ screen }
				onNavigate={ ( key ) => navigate( '#/' + key ) }
			/>
			<main className="opa-main">
				<Topbar
					screen={ screen }
					config={ config }
					navigate={ navigate }
				/>
				<div className="opa-content">
					<CurrentScreen
						onNavigate={ ( target, postId ) => {
							if ( postId ) {
								navigate( '#/editor/' + postId );
							} else {
								navigate( '#/' + target );
							}
						} }
					/>
				</div>
			</main>
			<BottomNav active={ screen } navigate={ navigate } />
		</div>
	);
}
