/**
 * Publish drawer -- 380px right-edge slide-out overlay drawer with phase
 * machine (idle / publishing / success), in-place celebration morph, and 4
 * body sections (Visibility, Slug, Tags, Schedule). Replaces both
 * settings-panel.js and publish-modal.js in plan 03 (this plan only ships
 * the component; wiring + legacy delete are plan 03's job).
 *
 * Decisions enforced by this file:
 *   - D-VISIBILITY-LOCAL-STATE: Visibility lives in local React state until
 *     Publish is clicked. The status mutation is the single editEntityRecord
 *     call inside handlePublish. Cancel/Esc/backdrop never persist a status
 *     flip — closes the autosave-side-effect window in editor.js:103-111.
 *   - D-VISIBILITY-PUBLIC-PRIVATE: Visibility is Public/Private only
 *     (the "U-word" segment was dropped — WP core has no native equivalent).
 *   - D-PUBLISH-VERBATIM: handlePublish lifted from publish-modal.js:15-27,
 *     adapted to drawer phase vocabulary (failure → 'idle', not 'confirm').
 *   - D-DRAWER-NO-EXCERPT: NO Excerpt field. Subtitle (REQ-12) is the sole
 *     edit surface for post.excerpt.
 */

import { useState, useEffect } from '@wordpress/element';
import { useEntityProp } from '@wordpress/core-data';
import { useDispatch } from '@wordpress/data';
import { Button, TextControl, DateTimePicker } from '@wordpress/components';
import { ESC } from '@wordpress/keycodes';
import { isInTheFuture } from '@wordpress/date';
import { X, Check } from '@phosphor-icons/react';
import TaxonomyPicker from './taxonomy-picker';

export default function PublishDrawer( { postId, onClose, onSuccess } ) {
	const [ phase, setPhase ] = useState( 'idle' );
	const [ scheduleMode, setScheduleMode ] = useState( 'now' );

	const [ slug, setSlug ] = useEntityProp( 'postType', 'post', 'slug', postId );
	// READ-ONLY: status is read to seed local visibility state. We never call
	// setStatus from this component — the mutation is deferred to handlePublish
	// via editEntityRecord (D-VISIBILITY-LOCAL-STATE).
	const [ status ] = useEntityProp( 'postType', 'post', 'status', postId );
	const [ date, setDate ] = useEntityProp( 'postType', 'post', 'date', postId );

	const { editEntityRecord, saveEditedEntityRecord } = useDispatch( 'core' );

	// D-VISIBILITY-LOCAL-STATE: track Visibility in LOCAL React state.
	// The status mutation is deferred to handlePublish so that Cancel/Esc/backdrop
	// dismissal cannot trigger the editor.js autosave (lines 103-111) and persist
	// an unintended status flip. See file header comment for full rationale.
	const [ visibility, setVisibility ] = useState(
		status === 'private' ? 'private' : 'public'
	);

	// Esc-to-close (suppressed during publishing so users can't dismiss mid-save).
	useEffect( () => {
		const handler = ( e ) => {
			if ( e.keyCode === ESC && phase !== 'publishing' ) {
				onClose();
			}
		};
		document.addEventListener( 'keydown', handler );
		return () => document.removeEventListener( 'keydown', handler );
	}, [ phase, onClose ] );

	// Body scroll-lock while drawer is open; restore prior overflow on unmount.
	useEffect( () => {
		const prev = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.body.style.overflow = prev;
		};
	}, [] );

	const handleScheduleChange = ( mode ) => {
		setScheduleMode( mode );
		if ( mode === 'now' ) {
			setDate( null );
		}
	};

	const isScheduled = scheduleMode === 'later' && date && isInTheFuture( date );
	const publishLabel = isScheduled ? 'Schedule' : 'Publish post';
	// Schedule = Later requires a future date — without one, publishing would
	// silently flip to "now". Block it at the button so toggling the affordance
	// can't accidentally publish immediately.
	const canPublish = scheduleMode === 'now' || isScheduled;

	// D-PUBLISH-VERBATIM + D-VISIBILITY-LOCAL-STATE:
	// Lifted from publish-modal.js lines 15-27, with two adaptations:
	//   1. Failure target renamed from 'confirm' to 'idle' (drawer phase vocabulary).
	//   2. newStatus respects local `visibility` state (Public → 'publish', Private → 'private').
	// This is the ONLY place in the component where post.status is mutated.
	const handlePublish = async () => {
		setPhase( 'publishing' );
		try {
			const newStatus = isScheduled
				? 'future'
				: visibility === 'private'
					? 'private'
					: 'publish';
			editEntityRecord( 'postType', 'post', postId, { status: newStatus } );
			await saveEditedEntityRecord( 'postType', 'post', postId );
			setPhase( 'success' );
		} catch ( err ) {
			// eslint-disable-next-line no-console
			console.error( '[opa] Publish failed:', err );
			setPhase( 'idle' );
		}
	};

	return (
		<>
			<div
				className="opa-publish-drawer-backdrop"
				onClick={ phase !== 'publishing' ? onClose : undefined }
				role="presentation"
			/>
			<div
				className="opa-publish-drawer is-open"
				role="dialog"
				aria-modal="true"
				aria-labelledby="opa-publish-drawer-title"
			>
				{ phase === 'success' ? (
					<>
						<header className="opa-publish-drawer-header">
							<h2 id="opa-publish-drawer-title">Published!</h2>
							<Button
								icon={ <X weight="bold" /> }
								onClick={ onClose }
								label="Close"
							/>
						</header>
						<div className="opa-publish-drawer-celebration">
							<div className="opa-celebration-checkmark">
								<Check weight="bold" />
							</div>
							<p>Your post is live</p>
						</div>
						<footer className="opa-publish-drawer-footer">
							<Button variant="tertiary" onClick={ onSuccess }>
								Back to dashboard
							</Button>
							<Button
								variant="primary"
								href={ `${
									window.opaSettings?.siteUrl || ''
								}/?p=${ postId }` }
								target="_blank"
							>
								View post
							</Button>
						</footer>
					</>
				) : (
					<>
						<header className="opa-publish-drawer-header">
							<h2 id="opa-publish-drawer-title">Ready to publish?</h2>
							<Button
								icon={ <X weight="bold" /> }
								onClick={ onClose }
								disabled={ phase === 'publishing' }
								label="Close"
							/>
						</header>
						<div className="opa-publish-drawer-body">
							<div className="opa-publish-drawer-section">
								<label className="opa-publish-drawer-label">
									Visibility
								</label>
								<div
									className="opa-segmented"
									role="radiogroup"
									aria-label="Visibility"
								>
									{ /* D-VISIBILITY-LOCAL-STATE: onClick updates LOCAL state ONLY. */ }
									{ /* Do NOT call setStatus / editEntityRecord here. */ }
									<button
										type="button"
										role="radio"
										aria-checked={ visibility === 'public' }
										className={ `opa-segmented-option ${
											visibility === 'public' ? 'is-active' : ''
										}` }
										onClick={ () => setVisibility( 'public' ) }
									>
										Public
									</button>
									<button
										type="button"
										role="radio"
										aria-checked={ visibility === 'private' }
										className={ `opa-segmented-option ${
											visibility === 'private' ? 'is-active' : ''
										}` }
										onClick={ () => setVisibility( 'private' ) }
									>
										Private
									</button>
								</div>
							</div>

							<div className="opa-publish-drawer-section">
								<TextControl
									label="URL slug"
									value={ slug || '' }
									onChange={ setSlug }
								/>
							</div>

							<div className="opa-publish-drawer-section">
								<TaxonomyPicker
									postId={ postId }
									taxonomy="post_tag"
									label="Tags"
								/>
							</div>

							<div className="opa-publish-drawer-section">
								<label className="opa-publish-drawer-label">
									Schedule
								</label>
								<div
									className="opa-segmented"
									role="radiogroup"
									aria-label="Schedule"
								>
									<button
										type="button"
										role="radio"
										aria-checked={ scheduleMode === 'now' }
										className={ `opa-segmented-option ${
											scheduleMode === 'now' ? 'is-active' : ''
										}` }
										onClick={ () => handleScheduleChange( 'now' ) }
									>
										Now
									</button>
									<button
										type="button"
										role="radio"
										aria-checked={ scheduleMode === 'later' }
										className={ `opa-segmented-option ${
											scheduleMode === 'later' ? 'is-active' : ''
										}` }
										onClick={ () => handleScheduleChange( 'later' ) }
									>
										Later
									</button>
								</div>
								{ scheduleMode === 'later' && (
									<DateTimePicker
										currentDate={ date }
										onChange={ ( newDate ) => setDate( newDate ) }
										is12Hour
									/>
								) }
							</div>
						</div>
						<footer className="opa-publish-drawer-footer">
							<Button
								variant="tertiary"
								onClick={ onClose }
								disabled={ phase === 'publishing' }
							>
								Cancel
							</Button>
							<Button
								variant="primary"
								onClick={ handlePublish }
								isBusy={ phase === 'publishing' }
								disabled={ phase === 'publishing' || ! canPublish }
							>
								{ publishLabel }
							</Button>
						</footer>
					</>
				) }
			</div>
		</>
	);
}
