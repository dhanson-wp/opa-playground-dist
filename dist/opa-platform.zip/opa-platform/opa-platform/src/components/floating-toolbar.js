/**
 * Opa floating formatting toolbar — REQ-1 (Phase 02.65b).
 *
 * Custom 8-button selection-anchored pill matching
 * `design-handoffs/post-editor/project/handoff/spec/01-floating-toolbar.md`.
 *
 * Composition (left → right, per spec line TOOLBAR_ACTIONS in chrome.jsx):
 *   Bold · Italic · Link · Strikethrough · ─ · Heading · List · Quote · Image · ─ · Kebab
 *
 * All Phosphor icons (Bold weight default, Duotone for active state) per
 * `design-system/CLAUDE.md` icon canon. Replaces the native contextual
 * block-toolbar popover (suppressed via core/preferences.fixedToolbar=true).
 *
 * Format triggers (Bold/Italic/Link/Strikethrough): synthetic keyboard events
 * dispatched on the iframe's currently-focused editable. Verified live: this
 * triggers @wordpress/keyboard-shortcuts → format-library's RichTextShortcut
 * handlers, so the format toggles round-trip through Gutenberg's native
 * format engine (no DOM-poking, no execCommand, no internal API leakage).
 *
 * Structure transforms (Heading/List/Quote/Image): use the canonical
 * `wp.blocks.switchToBlockType()` for content-preserving conversions
 * (Heading/List/Quote — keep paragraph text), and
 * `wp.data.dispatch('core/block-editor').insertBlocks()` for Image
 * (insert empty image block after the current block — content can't convert).
 *
 * Active-state detection: walks up the DOM ancestor chain on the selection
 * common ancestor looking for `<strong>`, `<em>`, `<s>`, `<a>`, `<code>`.
 * Plus the selected block's name for structure-button active state
 * (Heading/List/Quote/Image highlight when the current block matches).
 *
 * Architecture rationale: .planning/phases/02.65b-toolbar-followup/REQ-1-ARCHITECTURE.md
 *
 * Phase 2.65c follow-ups (out of scope here):
 *   - Custom kebab settings menu with Floating/Fixed toggle (REQ-3 — kebab
 *     button renders but its onClick is a no-op for now).
 *   - Custom Link editor popover (REQ-7 — Link button currently fires Cmd+K
 *     which opens the native Gutenberg link UI).
 *   - Image upload flow (Image button inserts an empty image block; the
 *     image picker chrome ships with the standard core/image render).
 */

import { useEffect, useMemo, useState, useCallback, useRef } from '@wordpress/element';
import { useSelect, useDispatch } from '@wordpress/data';
import { store as blockEditorStore } from '@wordpress/block-editor';
import { store as preferencesStore } from '@wordpress/preferences';
import { Popover } from '@wordpress/components';
import { createBlock, switchToBlockType } from '@wordpress/blocks';
import {
	TextB,
	TextItalic,
	Link as LinkIcon,
	TextStrikethrough,
	TextHOne,
	ListBullets,
	ListNumbers,
	Quotes,
	Image as ImageIcon,
	DotsThreeVertical,
	Textbox,
} from '@phosphor-icons/react';

const IS_MAC = typeof navigator !== 'undefined' && /Mac|iPod|iPhone|iPad/.test( navigator.platform );

function translateRect( rect, offset ) {
	const left = rect.left + offset.left;
	const top = rect.top + offset.top;
	return {
		left,
		top,
		right: rect.right + offset.left,
		bottom: rect.bottom + offset.top,
		width: rect.width,
		height: rect.height,
		x: left,
		y: top,
	};
}

// Dispatch a synthetic keyboard event on the iframe's focused editable to
// trigger format-library's @wordpress/keyboard-shortcuts handler. Verified
// live: round-trips through Gutenberg's native format engine.
function dispatchKey( iframe, key, modifiers ) {
	if ( ! iframe?.contentDocument ) {
		return;
	}
	const doc = iframe.contentDocument;
	const win = iframe.contentWindow;
	const editable = doc.activeElement?.matches( '[contenteditable="true"]' )
		? doc.activeElement
		: doc.querySelector( '[contenteditable="true"][data-rich-text-format-boundaries], p.wp-block-paragraph[contenteditable="true"]' );
	if ( ! editable ) {
		return;
	}
	editable.focus();
	const init = {
		key,
		code: 'Key' + key.toUpperCase(),
		keyCode: key.toUpperCase().charCodeAt( 0 ),
		which: key.toUpperCase().charCodeAt( 0 ),
		bubbles: true,
		cancelable: true,
		view: win,
		...modifiers,
	};
	editable.dispatchEvent( new win.KeyboardEvent( 'keydown', init ) );
	editable.dispatchEvent( new win.KeyboardEvent( 'keyup', init ) );
}

// Modifier key conventions per @wordpress/keycodes:
//   `primary` (Cmd on Mac, Ctrl elsewhere)  → bold/italic/link
//   `access`  (Ctrl+Alt on Mac, Shift+Alt elsewhere) → strikethrough/code/etc.
// The `access` set is the screen-reader-friendly shortcut family Gutenberg
// uses for less-common formats. Cmd+Shift+D collides with the native
// "Duplicate block" shortcut, which is why a naive `cmdOrCtrl + shift` for
// strikethrough was duplicating the block instead of toggling the format.
const primary = IS_MAC
	? { metaKey: true }
	: { ctrlKey: true };
const access = IS_MAC
	? { ctrlKey: true, altKey: true }
	: { shiftKey: true, altKey: true };

// Format trigger map — keyed shortcut per format type, matches the shortcuts
// registered by @wordpress/format-library.
const FORMAT_TRIGGERS = {
	bold: ( iframe ) => dispatchKey( iframe, 'b', primary ),
	italic: ( iframe ) => dispatchKey( iframe, 'i', primary ),
	link: ( iframe ) => dispatchKey( iframe, 'k', primary ),
	strike: ( iframe ) => dispatchKey( iframe, 'd', access ),
};

// Walk the selection container's ancestor chain looking for inline format tags.
// Returns the set of format keys currently applied to the selection (used to
// drive the toolbar's `is-active` button state).
function detectActiveFormats( iframe ) {
	const active = new Set();
	const doc = iframe?.contentDocument;
	const win = iframe?.contentWindow;
	if ( ! doc || ! win ) {
		return active;
	}
	const sel = win.getSelection();
	if ( ! sel || sel.rangeCount === 0 ) {
		return active;
	}
	const range = sel.getRangeAt( 0 );
	let node = range.commonAncestorContainer;
	if ( node.nodeType === 3 ) {
		node = node.parentElement;
	}
	if ( ! node || ! node.closest ) {
		return active;
	}
	if ( node.closest( 'strong, b' ) ) active.add( 'bold' );
	if ( node.closest( 'em, i' ) ) active.add( 'italic' );
	if ( node.closest( 's, del' ) ) active.add( 'strike' );
	if ( node.closest( 'a' ) ) active.add( 'link' );
	return active;
}

const ACTION_GROUPS = [
	[
		{ key: 'bold',   icon: TextB,             tip: 'Bold' },
		{ key: 'italic', icon: TextItalic,        tip: 'Italic' },
		{ key: 'link',   icon: LinkIcon,          tip: 'Link' },
		{ key: 'strike', icon: TextStrikethrough, tip: 'Strikethrough' },
	],
	[
		{ key: 'h',           icon: TextHOne,    tip: 'Heading' },
		{ key: 'list',        icon: ListBullets, tip: 'Bulleted list' },
		{ key: 'list-ordered',icon: ListNumbers, tip: 'Numbered list' },
		{ key: 'quote',       icon: Quotes,      tip: 'Quote' },
		{ key: 'image',       icon: ImageIcon,   tip: 'Image' },
	],
];

// Block-type slug per structure-button key (for active-state matching and
// switchToBlockType() target). `list-ordered` shares the core/list target
// with `list` — the difference is the `ordered` attribute applied after
// the transform.
const STRUCTURE_BLOCK_NAMES = {
	h: 'core/heading',
	list: 'core/list',
	'list-ordered': 'core/list',
	quote: 'core/quote',
	image: 'core/image',
};

export default function FloatingToolbar() {
	const { selectedClientId, selectedBlockName, selectedBlock, isTyping } = useSelect(
		( select ) => {
			const store = select( blockEditorStore );
			const id = store.getSelectedBlockClientId();
			return {
				selectedClientId: id,
				selectedBlockName: id ? store.getBlockName( id ) : null,
				// Resolve the full block via the same store ref the rest of
				// the component reads from. Earlier drafts read window.wp
				// directly, which silently returned undefined when the editor
				// data lived in a different (iframe-scoped) registry —
				// switchToBlockType then got `null` and looked like a no-op.
				selectedBlock: id ? store.getBlock( id ) : null,
				isTyping: store.isTyping(),
			};
		},
		[]
	);

	// Active state for the numbered/bulleted list buttons depends on the
	// `ordered` attribute on the current block (both share core/list).
	const isOrderedList =
		selectedBlockName === 'core/list' && !! selectedBlock?.attributes?.ordered;

	const { set: setPreference } = useDispatch( preferencesStore );
	const { replaceBlocks, insertBlocks } = useDispatch( blockEditorStore );

	// Suppress the native contextual block-toolbar popover. BlockTools reads
	// from core/preferences.fixedToolbar (NOT editorSettings.hasFixedToolbar
	// — verified live 2026-05-04).
	useEffect( () => {
		setPreference( 'core', 'fixedToolbar', true );
	}, [ setPreference ] );

	const [ anchorRect, setAnchorRect ] = useState( null );
	const [ activeFormats, setActiveFormats ] = useState( () => new Set() );
	const [ settingsMenuOpen, setSettingsMenuOpen ] = useState( false );
	const kebabRef = useRef( null );

	// Toolbar mode preference — persisted via core/preferences (sticky across
	// reloads in this session). Defaults to 'floating' per discuss-phase D-A7
	// new-user default. Phase 2.65d will move this to user-meta for true
	// per-user persistence; using the preferences store now keeps the API
	// canonical and doesn't introduce a new endpoint.
	const toolbarMode = useSelect(
		( select ) =>
			select( preferencesStore ).get( 'opa', 'toolbarMode' ) || 'floating',
		[]
	);
	const handleToolbarMode = useCallback(
		( mode ) => {
			setPreference( 'opa', 'toolbarMode', mode );
			setSettingsMenuOpen( false );
		},
		[ setPreference ]
	);

	// Close settings menu on Esc / outside click while it's open.
	useEffect( () => {
		if ( ! settingsMenuOpen ) {
			return;
		}
		const onKeydown = ( e ) => {
			if ( e.key === 'Escape' ) {
				setSettingsMenuOpen( false );
			}
		};
		document.addEventListener( 'keydown', onKeydown );
		return () => document.removeEventListener( 'keydown', onKeydown );
	}, [ settingsMenuOpen ] );

	useEffect( () => {
		if ( ! selectedClientId ) {
			setAnchorRect( null );
			setActiveFormats( new Set() );
			return;
		}

		const iframe = document.querySelector( 'iframe[name="editor-canvas"]' );
		const doc = iframe ? iframe.contentDocument : document;
		const win = iframe ? iframe.contentWindow : window;
		if ( ! doc || ! win ) {
			return;
		}

		const computeRect = () => {
			const iframeRect = iframe
				? iframe.getBoundingClientRect()
				: { left: 0, top: 0 };

			const sel = win.getSelection();
			if ( sel && sel.rangeCount > 0 && ! sel.isCollapsed ) {
				const range = sel.getRangeAt( 0 );
				const r = range.getBoundingClientRect();
				if ( r.width > 0 || r.height > 0 ) {
					return translateRect( r, iframeRect );
				}
			}

			const blockEl = doc.querySelector(
				`[data-block="${ selectedClientId }"]`
			);
			if ( blockEl ) {
				return translateRect(
					blockEl.getBoundingClientRect(),
					iframeRect
				);
			}

			return null;
		};

		const update = () => {
			setAnchorRect( computeRect() );
			setActiveFormats( detectActiveFormats( iframe ) );
		};

		doc.addEventListener( 'selectionchange', update );
		win.addEventListener( 'scroll', update, true );
		win.addEventListener( 'resize', update );
		update();

		return () => {
			doc.removeEventListener( 'selectionchange', update );
			win.removeEventListener( 'scroll', update, true );
			win.removeEventListener( 'resize', update );
		};
	}, [ selectedClientId ] );

	const handleFormatClick = useCallback( ( key ) => {
		const iframe = document.querySelector( 'iframe[name="editor-canvas"]' );
		const trigger = FORMAT_TRIGGERS[ key ];
		if ( trigger ) {
			trigger( iframe );
		}
	}, [] );

	const handleStructureClick = useCallback( ( key ) => {
		if ( ! selectedClientId ) {
			return;
		}
		const targetName = STRUCTURE_BLOCK_NAMES[ key ];
		if ( ! targetName ) {
			return;
		}

		// Image — no content to convert; insert an empty block after the
		// current block instead of replacing it.
		if ( targetName === 'core/image' ) {
			insertBlocks(
				createBlock( 'core/image', {} ),
				undefined,
				undefined,
				false
			);
			return;
		}

		// Heading / List / Quote — content-preserving transform via the
		// canonical block-transform API. `selectedBlock` is read via
		// useSelect so it's bound to the same store ref as `selectedClientId`.
		if ( ! selectedBlock ) {
			return;
		}
		const transformed = switchToBlockType( selectedBlock, targetName );
		if ( ! transformed || ! transformed.length ) {
			return;
		}

		// Numbered list shares core/list with bulleted; flip `ordered: true`
		// on the resulting list block before replacing.
		if ( key === 'list-ordered' ) {
			transformed[ 0 ] = {
				...transformed[ 0 ],
				attributes: {
					...transformed[ 0 ].attributes,
					ordered: true,
				},
			};
		}

		replaceBlocks( selectedClientId, transformed );
	}, [ selectedClientId, selectedBlock, insertBlocks, replaceBlocks ] );

	const virtualAnchor = useMemo( () => {
		if ( ! anchorRect ) {
			return null;
		}
		return { getBoundingClientRect: () => anchorRect };
	}, [ anchorRect ] );

	// Floating mode: hide while typing (matches native Gutenberg behavior so
	// the pill doesn't get in the way of writing flow); requires a selected
	// block + computed anchor rect.
	// Fixed mode: always visible — pinned position, doesn't hide on typing,
	// doesn't depend on selection. Matches native Gutenberg fixed-toolbar.
	const isFixed = toolbarMode === 'fixed';
	if ( ! isFixed ) {
		if ( isTyping || ! selectedClientId || ! virtualAnchor ) {
			return null;
		}
	}

	const isActive = ( key ) => {
		if ( key === 'list' ) {
			return selectedBlockName === 'core/list' && ! isOrderedList;
		}
		if ( key === 'list-ordered' ) {
			return isOrderedList;
		}
		if ( STRUCTURE_BLOCK_NAMES[ key ] ) {
			return selectedBlockName === STRUCTURE_BLOCK_NAMES[ key ];
		}
		return activeFormats.has( key );
	};

	const pill = (
		<div
			className={
				'opa-floating-toolbar' +
				( isFixed ? ' is-fixed' : '' )
			}
			role="toolbar"
			aria-label="Formatting"
		>
			{ ACTION_GROUPS.map( ( group, gi ) => (
				<>
					{ gi > 0 && (
						<span
							className="opa-tb-sep"
							aria-hidden="true"
							key={ `sep-${ gi }` }
						/>
					) }
					{ group.map( ( action ) => {
						const Icon = action.icon;
						const active = isActive( action.key );
						const isFormat = !! FORMAT_TRIGGERS[ action.key ];
						return (
							<button
								key={ action.key }
								type="button"
								className={
									'opa-tb-btn' +
									( active ? ' is-active' : '' )
								}
								aria-label={ action.tip }
								aria-pressed={ active }
								title={ action.tip }
								onMouseDown={ ( e ) => {
									// Don't blur the editable — preserves
									// selection so format toggles see it.
									e.preventDefault();
								} }
								onClick={ () =>
									isFormat
										? handleFormatClick( action.key )
										: handleStructureClick( action.key )
								}
							>
								<Icon
									size={ 18 }
									weight={ active ? 'duotone' : 'bold' }
								/>
							</button>
						);
					} ) }
				</>
			) ) }

			<span className="opa-tb-sep" aria-hidden="true" />
			<button
				ref={ kebabRef }
				type="button"
				className={
					'opa-tb-btn opa-tb-btn-kebab' +
					( settingsMenuOpen ? ' is-active' : '' )
				}
				aria-label="Toolbar settings"
				aria-expanded={ settingsMenuOpen }
				aria-haspopup="menu"
				title="Toolbar settings"
				onMouseDown={ ( e ) => e.preventDefault() }
				onClick={ () => setSettingsMenuOpen( ( v ) => ! v ) }
			>
				<DotsThreeVertical
					size={ 18 }
					weight={ settingsMenuOpen ? 'duotone' : 'bold' }
				/>
			</button>

			{ settingsMenuOpen && kebabRef.current && (
				<Popover
					anchor={ kebabRef.current }
					placement="bottom-end"
					offset={ 8 }
					className="opa-toolbar-settings-popover"
					onClose={ () => setSettingsMenuOpen( false ) }
					focusOnMount="firstElement"
				>
					<div
						className="opa-toolbar-settings-menu"
						role="menu"
						aria-label="Toolbar settings"
					>
						<div className="opa-toolbar-settings-section">
							Toolbar position
						</div>
						<div className="opa-toolbar-settings-row">
							<span className="opa-toolbar-settings-label">
								<Textbox size={ 16 } weight="bold" />
								Show as
							</span>
							<span
								className="opa-toolbar-settings-segment"
								role="radiogroup"
								aria-label="Toolbar mode"
							>
								<button
									type="button"
									role="radio"
									aria-checked={ toolbarMode === 'floating' }
									className={
										toolbarMode === 'floating'
											? 'is-active'
											: ''
									}
									onClick={ () =>
										handleToolbarMode( 'floating' )
									}
								>
									Floating
								</button>
								<button
									type="button"
									role="radio"
									aria-checked={ toolbarMode === 'fixed' }
									className={
										toolbarMode === 'fixed'
											? 'is-active'
											: ''
									}
									onClick={ () =>
										handleToolbarMode( 'fixed' )
									}
								>
									Fixed
								</button>
							</span>
						</div>
					</div>
				</Popover>
			) }
		</div>
	);

	if ( isFixed ) {
		return <div className="opa-floating-toolbar-fixed">{ pill }</div>;
	}

	return (
		<Popover
			anchor={ virtualAnchor }
			placement="top-start"
			offset={ 8 }
			className="opa-floating-toolbar-popover"
			flip
			shift
			focusOnMount={ false }
		>
			{ pill }
		</Popover>
	);
}
