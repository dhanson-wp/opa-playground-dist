/**
 * Save status indicator -- colored dot + label reflecting entity save state.
 * Uses core-data selectors to track saving, edits, and errors.
 */

import { useSelect } from '@wordpress/data';

export default function SaveStatus( { postId } ) {
	const { isSaving, hasEdits, lastError } = useSelect(
		( select ) => {
			const {
				isSavingEntityRecord,
				hasEditsForEntityRecord,
				getLastEntitySaveError,
			} = select( 'core' );
			return {
				isSaving: isSavingEntityRecord( 'postType', 'post', postId ),
				hasEdits: hasEditsForEntityRecord( 'postType', 'post', postId ),
				lastError: getLastEntitySaveError( 'postType', 'post', postId ),
			};
		},
		[ postId ]
	);

	let dotColor = 'var(--opa-green)';
	let label = 'Saved';

	if ( isSaving ) {
		dotColor = 'var(--opa-sunshine)';
		label = 'Saving...';
	} else if ( lastError ) {
		dotColor = 'var(--opa-coral)';
		label = 'Error';
	} else if ( hasEdits ) {
		dotColor = 'var(--opa-sunshine)';
		label = 'Unsaved';
	}

	return (
		<div className="opa-editor-status">
			<span
				className="opa-status-dot"
				style={ { background: dotColor } }
			/>
			{ label }
		</div>
	);
}
