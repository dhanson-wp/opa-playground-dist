import { useState } from '@wordpress/element';
import { Modal, Button } from '@wordpress/components';
import { Monitor, DeviceMobile } from '@phosphor-icons/react';

export default function PreviewModal( { postId, onClose } ) {
	const [ device, setDevice ] = useState( 'desktop' );

	const previewUrl = `${ window.opaSettings?.siteUrl || '' }/?p=${ postId }&preview=true`;

	return (
		<Modal
			title="Preview"
			onRequestClose={ onClose }
			isFullScreen
			className="opa-preview-modal"
		>
			<div className="opa-preview-toolbar">
				<Button
					icon={ <Monitor weight={ device === 'desktop' ? 'duotone' : 'bold' } /> }
					isPressed={ device === 'desktop' }
					onClick={ () => setDevice( 'desktop' ) }
					label="Desktop preview"
				/>
				<Button
					icon={ <DeviceMobile weight={ device === 'mobile' ? 'duotone' : 'bold' } /> }
					isPressed={ device === 'mobile' }
					onClick={ () => setDevice( 'mobile' ) }
					label="Mobile preview"
				/>
			</div>
			<div className="opa-preview-frame-wrapper">
				<iframe
					src={ previewUrl }
					className={ `opa-preview-iframe opa-preview-iframe--${ device }` }
					title="Post preview"
				/>
			</div>
		</Modal>
	);
}
