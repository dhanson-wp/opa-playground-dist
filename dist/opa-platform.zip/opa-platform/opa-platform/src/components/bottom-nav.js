import { House, FileText, PaintBucket, Gear, Plus } from '@phosphor-icons/react';

const tabs = [
	{ key: 'dashboard', icon: House,       label: 'Home' },
	{ key: 'posts',     icon: FileText,    label: 'Posts' },
	{ key: 'fab',       isFab: true },
	{ key: 'theme',     icon: PaintBucket, label: 'Theme' },
	{ key: 'settings',  icon: Gear,        label: 'Settings' },
];

export default function BottomNav( { active, navigate } ) {
	return (
		<nav className="opa-bottom-nav">
			{ tabs.map( ( tab ) => {
				if ( tab.isFab ) {
					return (
						<button
							key="fab"
							className="opa-fab"
							onClick={ () => navigate( '#/editor' ) }
							aria-label="New post"
						>
							<Plus weight="bold" size={ 28 } color="white" />
						</button>
					);
				}

				const TabIcon = tab.icon;
				const isActive = active === tab.key;
				return (
					<button
						key={ tab.key }
						className={ `opa-bottom-tab${ isActive ? ' active' : '' }` }
						onClick={ () => navigate( `#/${ tab.key }` ) }
					>
						<TabIcon weight={ isActive ? 'duotone' : 'bold' } size={ 26 } />
						<span className="opa-bottom-tab-label">{ tab.label }</span>
					</button>
				);
			} ) }
		</nav>
	);
}
