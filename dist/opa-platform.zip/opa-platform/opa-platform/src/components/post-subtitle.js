/**
 * Post Subtitle -- canvas-scoped editable surface bound to post.excerpt.
 *
 * REQ-12: a pre-loaded subtitle row beneath the title, reading and writing
 * post.excerpt via useEntityProp (single source of truth -- no separate
 * post_meta, no custom block).
 *
 * The component renders inside the canvas (between PostTitle and BlockList)
 * so it visually inherits the active TT5 style variation. CSS for this
 * component lives in editor-overrides.css and uses theme tokens only;
 * no chrome tokens appear here either (canvas-vs-shell rule).
 *
 * Slash menu does NOT trigger here: a free-standing RichText outside any
 * registered block has no block context, so Gutenberg's Autocomplete
 * completer never registers (structural, not opt-in suppression).
 */

import { RichText } from '@wordpress/block-editor';
import { useEntityProp } from '@wordpress/core-data';
import { useDispatch } from '@wordpress/data';
import { ENTER, BACKSPACE } from '@wordpress/keycodes';
import { __ } from '@wordpress/i18n';

export default function PostSubtitle( { postId } ) {
	const [ excerpt, setExcerpt ] = useEntityProp(
		'postType',
		'post',
		'excerpt',
		postId
	);

	const { insertDefaultBlock } = useDispatch( 'core/block-editor' );

	const handleKeyDown = ( event ) => {
		if ( event.keyCode === ENTER ) {
			event.preventDefault();
			// Insert a default paragraph at the top of the body and focus it.
			// Mirrors what Gutenberg PostTitle does on Enter.
			insertDefaultBlock( undefined, undefined, 0 );
		} else if ( event.keyCode === BACKSPACE ) {
			// D-BACKSPACE-SELECTOR: only exit to title when subtitle is
			// empty AND cursor is at offset 0 -- otherwise let RichText
			// handle the keypress normally.
			const sel = window.getSelection();
			if ( sel?.isCollapsed && sel.anchorOffset === 0 && ! excerpt ) {
				event.preventDefault();
				document
					.querySelector( '.editor-post-title__input' )
					?.focus();
			}
		}
	};

	return (
		<RichText
			tagName="p"
			className="opa-post-subtitle"
			value={ excerpt || '' }
			onChange={ setExcerpt }
			placeholder={ __( 'Add a subtitle to give readers a preview', 'opa-platform' ) }
			allowedFormats={ [] }
			disableLineBreaks
			identifier="opa-subtitle"
			onKeyDown={ handleKeyDown }
		/>
	);
}
