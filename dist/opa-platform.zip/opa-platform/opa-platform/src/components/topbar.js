import { Button } from '@wordpress/components';
import { Plus, ArrowSquareOut } from '@phosphor-icons/react';
import OpaLogo from './opa-logo';

export default function Topbar( { screen, config, navigate } ) {
	// Editor has no topbar (full-bleed).
	if ( ! config?.topbar ) {
		return null;
	}

	const { title, primaryAction } = config.topbar;

	return (
		<div className="opa-topbar">
			<h1 className="opa-topbar-title opa-topbar-title--desktop">
				{ title }
			</h1>
			<OpaLogo
				height={ 20 }
				className="opa-topbar-logo opa-topbar-logo--mobile"
			/>
			<div className="opa-topbar-actions">
				<Button
					variant="link"
					icon={ <ArrowSquareOut weight="bold" /> }
					href={ window.opaSettings?.siteUrl || '#' }
					target="_blank"
					rel="noopener noreferrer"
					className="opa-btn-view-blog"
				>
					View blog
				</Button>
				{ primaryAction === 'newPost' && (
					<Button
						variant="primary"
						icon={ <Plus weight="bold" /> }
						onClick={ () => navigate( '#/editor' ) }
						className="opa-btn-new-post"
					>
						New post
					</Button>
				) }
			</div>
		</div>
	);
}
