/**
 * Reusable dashboard stat tile — icon, value, label, footnote.
 *
 * Color/bg drive the tinted icon chip; footnote color matches.
 * @param {Object}   props
 * @param {Function} props.icon  Phosphor React component.
 * @param {string}   props.value Display number/string.
 * @param {string}   props.label Caption below the value.
 * @param {string}   props.note  Footnote (uses `color`).
 * @param {string}   props.color Foreground (icon + footnote).
 * @param {string}   props.bg    Icon chip background.
 */
export default function StatCard( {
	icon: Icon,
	value,
	label,
	note,
	color,
	bg,
} ) {
	return (
		<article className="opa-card opa-stat-card">
			<div className="opa-stat-chip" style={ { background: bg } }>
				<Icon
					weight="duotone"
					size={ 20 }
					color={ color }
					style={ {
						'--ph-secondary-color': color,
						'--ph-secondary-opacity': '0.28',
					} }
				/>
			</div>
			<div className="opa-stat-value">{ value }</div>
			<div className="opa-stat-label">{ label }</div>
			<div className="opa-stat-note" style={ { color } }>
				{ note }
			</div>
		</article>
	);
}
