import { PlusCircle, Check } from '@phosphor-icons/react';

/**
 * 14-day rhythm card — STUBBED for v0.
 *
 * The real source for rhythm data needs either a custom
 * opa/v1/dashboard/rhythm endpoint or Jetpack Stats integration. Layout
 * is faithful to the v2 mockup so the page reads as a finished surface;
 * the underlying data is a static placeholder pattern. Active days /
 * goals are similarly stubbed with disabled controls.
 *
 * "Coming soon" microcopy makes the v0 stub state explicit to the user.
 */
export default function RhythmGrid() {
	return (
		<article className="opa-card opa-rhythm-card">
			<div className="opa-rhythm-header">
				<div>
					<strong className="opa-rhythm-value">5</strong>
					<span className="opa-rhythm-label">
						active days this week
					</span>
				</div>
				<span className="opa-pill opa-pill--coral">Rhythm</span>
			</div>

			<div className="opa-rhythm-grid">
				{ STUB_DAYS.map( ( type, i ) => (
					<span
						key={ i }
						className={ `opa-rhythm-cell opa-rhythm-cell--${
							type || 'empty'
						}` }
					/>
				) ) }
			</div>

			<div className="opa-rhythm-legend">
				<span>
					<i className="opa-legend-dot opa-legend-dot--idea" />
					Idea saved
				</span>
				<span>
					<i className="opa-legend-dot opa-legend-dot--touched" />
					Draft touched
				</span>
				<span>
					<i className="opa-legend-dot opa-legend-dot--published" />
					Published
				</span>
			</div>

			<div className="opa-momentum-note">
				A day counts when you engage with your space, even briefly.
			</div>

			<div className="opa-goal-list">
				<GoalItem text="Capture one new idea" done />
				<GoalItem text="Return to a living draft" done />
				<GoalItem text="Publish before Friday" />
				<button className="opa-add-goal" disabled title="Coming soon">
					<PlusCircle weight="bold" size={ 16 } />
					Add goal
				</button>
			</div>

			<div className="opa-rhythm-footnote">
				Real rhythm data ships with the next pass.
			</div>
		</article>
	);
}

function GoalItem( { text, done } ) {
	return (
		<div className="opa-goal-item">
			<span className={ `opa-goal-check${ done ? ' done' : '' }` }>
				{ done && <Check weight="bold" size={ 14 } /> }
			</span>
			<span>{ text }</span>
		</div>
	);
}

// 28 cells (4 rows x 7 days = 4 weeks). Pattern roughly matches the
// mockup's "active 5 days last week" shape so the visual reads correctly.
const STUB_DAYS = [
	'',
	'idea',
	'touched',
	'',
	'published',
	'touched',
	'multi',
	'',
	'idea',
	'touched',
	'published',
	'touched',
	'',
	'published',
	'idea',
	'',
	'touched',
	'touched',
	'published',
	'',
	'idea',
	'touched',
	'multi',
	'published',
	'touched',
	'',
	'idea',
	'published',
];
