import { useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { Button } from '@wordpress/components';
import { NotePencil } from '@phosphor-icons/react';

/**
 * Hero card with quick-capture input.
 *
 * Submitting POSTs to the existing opa/v1/create-draft endpoint
 * (mu-plugins/opa-platform/includes/rest-create-draft.php), then navigates
 * to the editor for the new post id. The typed text is dropped on the floor
 * for v0 — passing it through as a seed (title or first block) is a fast-
 * follow once the editor accepts it.
 * @param {Object}   props
 * @param {Function} [props.onNavigate] (target, postId) => void from app-shell.
 */
export default function HeroCapture( { onNavigate } ) {
	const [ value, setValue ] = useState( '' );
	const [ isCreating, setIsCreating ] = useState( false );

	const handleSubmit = async ( event ) => {
		event?.preventDefault?.();
		if ( isCreating ) {
			return;
		}
		setIsCreating( true );
		try {
			const post = await apiFetch( {
				path: '/opa/v1/create-draft',
				method: 'POST',
			} );
			if ( post?.id ) {
				onNavigate?.( 'editor', post.id );
			}
		} catch ( e ) {
			// Surface a console error in v0; toast/banner is a fast-follow.
			// eslint-disable-next-line no-console
			console.error( 'opa create-draft failed', e );
		} finally {
			setIsCreating( false );
		}
	};

	return (
		<article className="opa-card opa-hero-card">
			<div className="opa-hero-decor" aria-hidden="true" />
			<div className="opa-hero-content">
				<div className="opa-eyebrow">Today in your space</div>
				<h2 className="opa-hero-title">Keep showing up.</h2>
				<p className="opa-hero-body">
					You&apos;ve touched your space five times this week. Capture
					the next idea while it&apos;s still fresh, then come back
					when you&apos;re ready to shape it.
				</p>
				<form className="opa-hero-capture" onSubmit={ handleSubmit }>
					<input
						type="text"
						className="opa-hero-input"
						placeholder="A title, thought, or first line…"
						value={ value }
						onChange={ ( e ) => setValue( e.target.value ) }
						disabled={ isCreating }
					/>
					<Button
						type="submit"
						variant="primary"
						isBusy={ isCreating }
						disabled={ isCreating }
						icon={ <NotePencil weight="bold" /> }
						className="opa-hero-cta"
					>
						Start draft
					</Button>
				</form>
			</div>
		</article>
	);
}
