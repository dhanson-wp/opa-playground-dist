import { useMemo } from '@wordpress/element';
import { useEntityRecords } from '@wordpress/core-data';
import { Button, Spinner } from '@wordpress/components';

/**
 * "Resume writing" card — top 2 most-recently-modified drafts.
 *
 * Status pill + suggested next-step copy are derived from `modified` recency.
 * No word counts, no progress rings — positive framing only.
 * @param {Object}   props
 * @param {Function} [props.onNavigate] (target, postId) => void from app-shell.
 */
export default function ResumeWriting( { onNavigate } ) {
	const query = useMemo(
		() => ( {
			// Match dashboard stats: include auto-drafts so a freshly started
			// idea shows up immediately in resume writing.
			status: [ 'draft', 'auto-draft' ],
			per_page: 2,
			orderby: 'modified',
			order: 'desc',
			_fields: [ 'id', 'title', 'excerpt', 'modified' ],
		} ),
		[]
	);
	const { records: drafts, isResolving } = useEntityRecords(
		'postType',
		'post',
		query
	);

	return (
		<article className="opa-card opa-resume-card">
			<div className="opa-card-row">
				<div>
					<h3 className="opa-card-title">Resume writing</h3>
					<p className="opa-card-subtitle">
						The ideas with enough life to return to.
					</p>
				</div>
				<Button
					variant="secondary"
					className="opa-btn-soft"
					onClick={ () => onNavigate?.( 'drafts' ) }
				>
					See all drafts
				</Button>
			</div>
			<div className="opa-resume-body">
				{ isResolving && <Spinner /> }
				{ ! isResolving && drafts && drafts.length === 0 && (
					<div className="opa-resume-empty">
						No living drafts yet. Start one from the hero above.
					</div>
				) }
				{ ! isResolving &&
					drafts &&
					drafts.map( ( draft ) => (
						<ResumeItem
							key={ draft.id }
							draft={ draft }
							onOpen={ () => onNavigate?.( 'editor', draft.id ) }
						/>
					) ) }
			</div>
		</article>
	);
}

function ResumeItem( { draft, onOpen } ) {
	const title = draft.title?.rendered || '(Untitled)';
	const excerpt = ( draft.excerpt?.rendered || '' )
		.replace( /<[^>]+>/g, '' )
		.replace( /\s+/g, ' ' )
		.trim()
		.slice( 0, 160 );
	const { status, nextStep } = describeMomentum( draft.modified );

	return (
		<div className="opa-resume-item">
			<div className="opa-resume-text">
				<h4 className="opa-resume-title">{ title }</h4>
				{ excerpt && <p className="opa-resume-excerpt">{ excerpt }</p> }
				<div className="opa-resume-pills">
					<span className="opa-pill opa-pill--coral">{ status }</span>
					<span className="opa-pill">{ nextStep }</span>
				</div>
			</div>
			<Button
				variant="tertiary"
				className="opa-btn-resume"
				onClick={ onOpen }
			>
				Continue
			</Button>
		</div>
	);
}

/**
 * Derive a positive momentum cue from a draft's last-modified timestamp.
 * No word-count comparison; framing is encouragement, not pressure.
 * @param {string} modifiedIso ISO timestamp from the post record.
 */
function describeMomentum( modifiedIso ) {
	if ( ! modifiedIso ) {
		return { status: 'New idea', nextStep: 'Save a first line' };
	}
	const modifiedAt = new Date( modifiedIso ).getTime();
	const now = Date.now();
	const hours = ( now - modifiedAt ) / ( 1000 * 60 * 60 );
	if ( hours < 24 ) {
		return {
			status: 'Has a strong start',
			nextStep: 'Add the next thought',
		};
	}
	if ( hours < 24 * 7 ) {
		return { status: 'Ready to shape', nextStep: 'Add one example' };
	}
	return { status: 'Quiet for a while', nextStep: 'Re-read and add a line' };
}
