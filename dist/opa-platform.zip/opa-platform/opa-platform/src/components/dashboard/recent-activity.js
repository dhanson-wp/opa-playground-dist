import { useMemo } from '@wordpress/element';
import { useEntityRecords } from '@wordpress/core-data';
import { Spinner } from '@wordpress/components';

/**
 * "Recent activity" feed — last 4 modified posts (any status).
 *
 * Event type and copy derived from `status`/`modified`/`date_gmt`. No
 * dedicated activity log endpoint in v0; this approximates one from
 * post records the SPA already loads.
 */
export default function RecentActivity() {
	const query = useMemo(
		() => ( {
			status: [
				'publish',
				'draft',
				'auto-draft',
				'pending',
				'future',
			],
			per_page: 4,
			orderby: 'modified',
			order: 'desc',
			_fields: [ 'id', 'title', 'status', 'date', 'modified' ],
		} ),
		[]
	);
	const { records: posts, isResolving } = useEntityRecords(
		'postType',
		'post',
		query
	);

	return (
		<article className="opa-card opa-activity-card">
			<div className="opa-card-row opa-card-row--header">
				<div>
					<h3 className="opa-card-title">Recent activity</h3>
					<p className="opa-card-subtitle">Your publishing trail.</p>
				</div>
			</div>
			<div className="opa-activity-list">
				{ isResolving && <Spinner /> }
				{ ! isResolving && posts && posts.length === 0 && (
					<div className="opa-activity-empty">
						Nothing yet. Publish your first post to start the trail.
					</div>
				) }
				{ ! isResolving &&
					posts &&
					posts.map( ( post ) => (
						<ActivityItem key={ post.id } post={ post } />
					) ) }
			</div>
		</article>
	);
}

function ActivityItem( { post } ) {
	const title = post.title?.rendered || '(Untitled)';
	const event = describeEvent( post );
	return (
		<div className="opa-activity-item">
			<div>
				<strong className="opa-activity-title">
					{ event.verb } { title }
				</strong>
				<span className="opa-activity-copy">{ event.copy }</span>
			</div>
			<span className="opa-activity-time">
				{ formatRelative( post.modified ) }
			</span>
		</div>
	);
}

function describeEvent( post ) {
	if ( post.status === 'publish' ) {
		// If created and published recently, treat as fresh publish.
		const dateGmt = post.date ? new Date( post.date ).getTime() : 0;
		const modGmt = post.modified ? new Date( post.modified ).getTime() : 0;
		const editGap = Math.abs( modGmt - dateGmt );
		if ( editGap < 1000 * 60 * 5 ) {
			return { verb: 'Published', copy: 'Live on your blog now.' };
		}
		return { verb: 'Updated', copy: 'A small refinement.' };
	}
	if ( post.status === 'future' ) {
		return { verb: 'Scheduled', copy: 'Queued to publish.' };
	}
	if ( post.status === 'pending' ) {
		return { verb: 'Awaiting review', copy: 'Pending publish.' };
	}
	if ( post.status === 'auto-draft' ) {
		return { verb: 'Captured', copy: 'A new idea saved.' };
	}
	// Draft — distinguish create vs touch.
	const dateGmt = post.date ? new Date( post.date ).getTime() : 0;
	const modGmt = post.modified ? new Date( post.modified ).getTime() : 0;
	const editGap = Math.abs( modGmt - dateGmt );
	if ( editGap < 1000 * 60 * 5 ) {
		return { verb: 'Captured', copy: 'A new idea saved.' };
	}
	return { verb: 'Resumed', copy: 'Moved the idea forward.' };
}

function formatRelative( iso ) {
	if ( ! iso ) {
		return '';
	}
	const ts = new Date( iso ).getTime();
	const now = Date.now();
	const minutes = Math.floor( ( now - ts ) / ( 1000 * 60 ) );
	if ( minutes < 1 ) {
		return 'just now';
	}
	if ( minutes < 60 ) {
		return `${ minutes }m`;
	}
	const hours = Math.floor( minutes / 60 );
	if ( hours < 24 ) {
		return `${ hours }h`;
	}
	const days = Math.floor( hours / 24 );
	if ( days < 7 ) {
		return `${ days }d`;
	}
	return new Date( iso ).toLocaleDateString( undefined, {
		month: 'short',
		day: 'numeric',
	} );
}
