import { useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { Button } from '@wordpress/components';
import { NotePencil } from '@phosphor-icons/react';
import { OpaSpark } from './opa-logo';

/**
 * Welcome overlay — first-run state for new users.
 *
 * Renders a full-screen modal-style card on top of the dashboard when the
 * user has zero posts (any status). Reuses the existing /opa/v1/create-draft
 * endpoint from HeroCapture so a tester can go from cold to writing in one
 * click.
 *
 * Auto-hides as soon as the user has any post — no localStorage flag needed.
 * Local "Skip for now" sets a session-level dismissed flag so the overlay
 * stops nagging during the same login.
 *
 * @param {Object}   props
 * @param {Function} [props.onNavigate] (target, postId) => void from dashboard.
 * @param {Function} [props.onDismiss]  () => void — caller hides the overlay.
 */
export default function WelcomeOverlay( { onNavigate, onDismiss } ) {
	const [ value, setValue ] = useState( '' );
	const [ isCreating, setIsCreating ] = useState( false );

	const handleSubmit = async ( event ) => {
		event?.preventDefault?.();
		if ( isCreating ) {
			return;
		}
		setIsCreating( true );
		try {
			const post = await apiFetch( {
				path: '/opa/v1/create-draft',
				method: 'POST',
			} );
			if ( post?.id ) {
				onNavigate?.( 'editor', post.id );
			}
		} catch ( e ) {
			// eslint-disable-next-line no-console
			console.error( 'opa create-draft failed', e );
		} finally {
			setIsCreating( false );
		}
	};

	return (
		<div className="opa-welcome-overlay" role="dialog" aria-modal="true" aria-labelledby="opa-welcome-title">
			<div className="opa-welcome-card">
				<div className="opa-welcome-mark" aria-hidden="true">
					<OpaSpark size={ 48 } />
				</div>

				<h1 id="opa-welcome-title" className="opa-welcome-title">
					Welcome to <span className="opa-welcome-wordmark">opa</span>.
				</h1>

				<p className="opa-welcome-body">
					A small, welcoming place to write online and publish to
					WordPress without ceremony.
				</p>

				<form className="opa-welcome-form" onSubmit={ handleSubmit }>
					<input
						type="text"
						className="opa-welcome-input"
						placeholder="A title, thought, or first line…"
						value={ value }
						onChange={ ( e ) => setValue( e.target.value ) }
						disabled={ isCreating }
						autoFocus
					/>
					<Button
						type="submit"
						variant="primary"
						isBusy={ isCreating }
						disabled={ isCreating }
						icon={ <NotePencil weight="bold" /> }
						className="opa-welcome-cta"
					>
						Start writing
					</Button>
				</form>

				<button
					type="button"
					className="opa-welcome-skip"
					onClick={ () => onDismiss?.() }
				>
					Skip for now
				</button>
			</div>
		</div>
	);
}
