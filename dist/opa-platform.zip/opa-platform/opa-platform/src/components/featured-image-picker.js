/**
 * Featured image upload/remove using the WordPress media library.
 * Uses useEntityProp for the featured_media field and MediaUpload
 * from @wordpress/block-editor.
 */

import { useEntityProp } from '@wordpress/core-data';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { Button, Spinner } from '@wordpress/components';
import { useSelect } from '@wordpress/data';

export default function FeaturedImagePicker( { postId } ) {
	const [ featuredMedia, setFeaturedMedia ] = useEntityProp(
		'postType',
		'post',
		'featured_media',
		postId
	);

	const media = useSelect(
		( select ) => {
			if ( ! featuredMedia ) {
				return null;
			}
			return select( 'core' ).getMedia( featuredMedia );
		},
		[ featuredMedia ]
	);

	return (
		<div className="opa-featured-image-picker">
			<MediaUploadCheck>
				<MediaUpload
					onSelect={ ( selected ) =>
						setFeaturedMedia( selected.id )
					}
					allowedTypes={ [ 'image' ] }
					value={ featuredMedia }
					render={ ( { open } ) => (
						<div className="opa-featured-image-picker__content">
							{ featuredMedia && media ? (
								<>
									<img
										src={ media.source_url }
										alt=""
										className="opa-featured-image-picker__preview"
									/>
									<div className="opa-featured-image-picker__actions">
										<Button
											variant="secondary"
											onClick={ open }
										>
											Replace
										</Button>
										<Button
											variant="tertiary"
											isDestructive
											onClick={ () =>
												setFeaturedMedia( 0 )
											}
										>
											Remove
										</Button>
									</div>
								</>
							) : featuredMedia && ! media ? (
								<Spinner />
							) : (
								<Button
									variant="secondary"
									onClick={ open }
								>
									Set featured image
								</Button>
							) }
						</div>
					) }
				/>
			</MediaUploadCheck>
		</div>
	);
}
