/**
 * Native Gutenberg toolbar wrapper -- replaces the decorative mockup toolbar.
 * Renders inside BlockEditorProvider context (from editor.js).
 * Per D-06: use native BlockToolbar, not custom buttons.
 * Per D-09: start with native styling, Opa CSS overrides layer on top.
 */

import { BlockToolbar } from '@wordpress/block-editor';

export default function EditorToolbar() {
	return (
		<div className="opa-toolbar">
			<BlockToolbar hideDragHandle />
		</div>
	);
}
