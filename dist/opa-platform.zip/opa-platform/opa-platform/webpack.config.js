/**
 * Opa Platform — wp-scripts webpack config
 *
 * Extends @wordpress/scripts default config with a second entry for
 * editor-restrictions.js so it ships as its own bundle (loaded on the
 * standard `enqueue_block_editor_assets` hook for any block editor
 * surface, independent of the Opa SPA bundle).
 */

const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );

module.exports = {
	...defaultConfig,
	entry: {
		index: './src/index.js',
		'editor-restrictions': './src/editor-restrictions.js',
	},
};
