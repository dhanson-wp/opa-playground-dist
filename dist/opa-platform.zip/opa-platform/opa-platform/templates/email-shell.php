<?php
/**
 * HTML email shell template.
 *
 * Variables in scope: $args (associative, see opa_email_shell() docblock).
 *
 * Table-based layout for Outlook compatibility. Inline styles on every
 * visual element. A small <style> block in <head> handles mobile padding
 * via @media query (Outlook desktop ignores it but the base desktop
 * padding values render fine).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="x-apple-disable-message-reformatting">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="color-scheme" content="light only">
<meta name="supported-color-schemes" content="light only">
<title><?php echo esc_html( $args['subject'] ); ?></title>
<style type="text/css">
	/* Modern email clients honor <style>. Outlook desktop strips it but
	   the inline desktop values render fine on its own. */
	@media only screen and (max-width: 480px) {
		.opa-card { padding: 32px 24px !important; }
		.opa-wrap { padding: 24px 12px !important; }
		.opa-h1   { font-size: 24px !important; }
		.opa-cta  { padding: 12px 24px !important; }
	}
	/* Link hover for clients that render hover state (Apple Mail). */
	a:hover { opacity: 0.85; }
</style>
</head>
<body style="margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;background:#F5F5F7;color:#111111;-webkit-text-size-adjust:100%;">

<?php /* Preheader — hidden text shown by mailbox clients in inbox preview */ ?>
<?php if ( $args['preheader'] !== '' ) : ?>
<div style="display:none;max-height:0;overflow:hidden;color:transparent;font-size:1px;line-height:1px;mso-hide:all;">
<?php echo esc_html( $args['preheader'] ); ?>
</div>
<?php endif; ?>

<?php /* Coral brand strip across the top */ ?>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#FF5A5F;">
<tr><td style="height:6px;line-height:6px;font-size:6px;">&nbsp;</td></tr>
</table>

<?php /* Outer wrapper */ ?>
<table class="opa-wrap" role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F5F5F7;padding:48px 16px;">
<tr><td align="center">

<?php /* The card */ ?>
<table role="presentation" width="560" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;width:100%;">
<tr><td class="opa-card" style="background:#FFFFFF;border-radius:12px;padding:48px 40px;border:1px solid #ECECEF;">

<?php /* Wordmark */ ?>
<div style="margin:0 0 32px;">
<a href="https://opa.blog" style="display:inline-block;text-decoration:none;color:#FF5A5F;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;font-size:28px;font-weight:700;letter-spacing:-0.02em;line-height:1;">Opa</a>
</div>

<?php /* Heading */ ?>
<?php if ( $args['heading'] !== '' ) : ?>
<h1 class="opa-h1" style="margin:0 0 24px;font-size:28px;font-weight:600;color:#111111;line-height:1.25;letter-spacing:-0.01em;">
<?php echo esc_html( $args['heading'] ); ?>
</h1>
<?php endif; ?>

<?php /* Greeting */ ?>
<?php if ( $args['greeting'] !== '' ) : ?>
<p style="margin:0 0 24px;font-size:16px;line-height:1.5;color:#2A2A2A;">
<?php echo esc_html( $args['greeting'] ); ?>
</p>
<?php endif; ?>

<?php /* Body paragraphs */ ?>
<?php foreach ( (array) $args['paragraphs'] as $p ) : ?>
<?php if ( ! is_string( $p ) || $p === '' ) continue; ?>
<p style="margin:0 0 24px;font-size:16px;line-height:1.5;color:#2A2A2A;">
<?php echo esc_html( $p ); ?>
</p>
<?php endforeach; ?>

<?php /* Primary CTA + copy-paste fallback */ ?>
<?php if ( $args['cta_label'] !== '' && $args['cta_url'] !== '' ) : ?>
<p style="margin:0 0 32px;">
<a class="opa-cta" href="<?php echo esc_url( $args['cta_url'] ); ?>" style="display:inline-block;padding:14px 32px;background:#FF5A5F;color:#FFFFFF;text-decoration:none;border-radius:999px;font-size:16px;font-weight:600;box-shadow:0 6px 20px rgba(255,90,95,0.30);">
<?php echo esc_html( $args['cta_label'] ); ?>
</a>
</p>

<p style="margin:0 0 8px;font-size:14px;line-height:1.5;color:#6B6B70;">
<?php echo esc_html( $args['fallback_intro'] ); ?>
</p>
<p style="margin:0 0 32px;font-size:14px;line-height:1.5;color:#6B6B70;word-break:break-all;">
<a href="<?php echo esc_url( $args['cta_url'] ); ?>" style="color:#6B6B70;text-decoration:underline;">
<?php echo esc_html( $args['cta_url'] ); ?>
</a>
</p>
<?php endif; ?>

<?php /* Meta rows + note share a divider above */ ?>
<?php
$has_meta = false;
if ( ! empty( $args['meta'] ) ) {
	foreach ( (array) $args['meta'] as $row ) {
		if ( ! empty( $row['label'] ) && ! empty( $row['url'] ) ) {
			$has_meta = true;
			break;
		}
	}
}
$has_note = $args['note'] !== '';
?>
<?php if ( $has_meta || $has_note ) : ?>
<hr style="border:none;border-top:1px solid #ECECEF;margin:0 0 24px;">
<?php endif; ?>

<?php if ( $has_meta ) : ?>
<?php foreach ( (array) $args['meta'] as $row ) : ?>
<?php if ( empty( $row['label'] ) || empty( $row['url'] ) ) continue; ?>
<p style="margin:0 0 8px;font-size:13px;line-height:1.5;color:#6B6B70;">
<?php echo esc_html( $row['label'] ); ?>
<a href="<?php echo esc_url( $row['url'] ); ?>" style="color:#6B6B70;text-decoration:underline;">
<?php echo esc_html( $row['url'] ); ?>
</a>
</p>
<?php endforeach; ?>
<?php endif; ?>

<?php if ( $has_note ) : ?>
<p style="margin:<?php echo $has_meta ? '8px' : '0'; ?> 0 0;font-size:13px;line-height:1.5;color:#6B6B70;">
<?php echo esc_html( $args['note'] ); ?>
</p>
<?php endif; ?>

</td></tr>
</table>

<?php /* Outer footer */ ?>
<?php if ( $args['sender_email'] !== '' ) : ?>
<p style="margin:24px 0 0;font-size:12px;color:#6B6B70;text-align:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;">
Sent from <?php echo esc_html( $args['sender_email'] ); ?>
</p>
<?php endif; ?>

</td></tr>
</table>

</body>
</html>
