<?php
/**
 * Welcome-to-Opa post seeding.
 *
 * Provides opa_seed_welcome_post() — invoked from the Playground blueprint's
 * runPHP step after the default Hello World / Sample Page are deleted. Idempotent
 * via post-meta marker (_opa_seeded_welcome): re-running the blueprint or the
 * function manually never produces duplicate Welcome posts.
 *
 * The post body is intentionally block markup (wp:paragraph, wp:image, wp:button)
 * so it round-trips cleanly through the Block Editor when a tester opens it.
 * Dashboard + editor screenshots are served from the public Playground dist
 * repo (dhanson-wp/opa-playground-dist/welcome-assets/) and referenced by raw
 * URL — they don't need to be imported as wp media for the alpha viewing path.
 *
 * @see scripts/build-and-push-playground.sh — pushes the screenshots alongside the zips.
 * @see https://github.com/dhanson-wp/opa-playground-dist/blob/main/blueprint.json — invokes this.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Feedback form URL. TODO: replace placeholder before sharing the Alpha link.
 *
 * Filterable via 'opa_feedback_url' for env-specific overrides.
 */
function opa_get_feedback_url() {
	$url = 'https://opa.blog/alpha-feedback'; // placeholder — wire real form URL before sharing
	/** @var string $url */
	return apply_filters( 'opa_feedback_url', $url );
}

/**
 * Base URL for welcome-post assets (screenshots). Lives in the public dist repo
 * so it's reachable from playground.wordpress.net without auth.
 */
function opa_get_welcome_assets_base_url() {
	return 'https://raw.githubusercontent.com/dhanson-wp/opa-playground-dist/main/welcome-assets';
}

/**
 * Welcome post body, returned as Gutenberg block markup.
 */
function opa_get_welcome_post_content() {
	$assets   = opa_get_welcome_assets_base_url();
	$feedback = esc_url( opa_get_feedback_url() );

	$dashboard_img = esc_url( $assets . '/dashboard.png' );
	$editor_img    = esc_url( $assets . '/editor.png' );

	$content  = '';

	// Lede.
	$content .= "<!-- wp:paragraph -->\n";
	$content .= '<p>Welcome to the closed alpha. Opa is a small, welcoming place to write online — you pick your space, you write, you ship it. No dashboards full of dials. No long onboarding. Just writing.</p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n\n";

	$content .= "<!-- wp:paragraph -->\n";
	$content .= '<p>This Playground instance is yours for the session. Click around, write a post, hit publish. Nothing you do here persists past closing the tab.</p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n\n";

	// Section 1 — dashboard.
	$content .= "<!-- wp:heading -->\n";
	$content .= '<h2 class="wp-block-heading">The dashboard</h2>' . "\n";
	$content .= "<!-- /wp:heading -->\n\n";

	$content .= "<!-- wp:image {\"sizeSlug\":\"large\"} -->\n";
	$content .= '<figure class="wp-block-image size-large"><img src="' . $dashboard_img . '" alt="The Opa dashboard"/></figure>' . "\n";
	$content .= "<!-- /wp:image -->\n\n";

	$content .= "<!-- wp:paragraph -->\n";
	$content .= '<p>Your home screen. Quick-capture a thought into a draft, see your rhythm of writing this week, and pick up living drafts where you left off. The sidebar holds the rest — drafts, posts, theme, settings.</p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n\n";

	// Section 2 — editor.
	$content .= "<!-- wp:heading -->\n";
	$content .= '<h2 class="wp-block-heading">The editor</h2>' . "\n";
	$content .= "<!-- /wp:heading -->\n\n";

	$content .= "<!-- wp:image {\"sizeSlug\":\"large\"} -->\n";
	$content .= '<figure class="wp-block-image size-large"><img src="' . $editor_img . '" alt="The Opa editor"/></figure>' . "\n";
	$content .= "<!-- /wp:image -->\n\n";

	$content .= "<!-- wp:paragraph -->\n";
	$content .= '<p>Writing-first. Type your title, then your post. The toolbar appears only when you need it. The Publish button on the right opens a drawer with featured image, categories, and scheduling — set as much or as little as feels right, then publish.</p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n\n";

	$content .= "<!-- wp:paragraph -->\n";
	$content .= '<p>Try the golden path: hit the back button at the top-left to come back here, then click <strong>New post</strong> from the topbar.</p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n\n";

	// Section 3 — feedback ask.
	$content .= "<!-- wp:heading -->\n";
	$content .= '<h2 class="wp-block-heading">What we want from you</h2>' . "\n";
	$content .= "<!-- /wp:heading -->\n\n";

	$content .= "<!-- wp:paragraph -->\n";
	$content .= '<p>Honest feedback. What feels good. What feels off. What\'s missing. What confused you. The smallest detail you noticed is useful — we\'re shaping this for real writers, and the rough edges are where the next iteration starts.</p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n\n";

	$content .= "<!-- wp:buttons {\"layout\":{\"type\":\"flex\",\"justifyContent\":\"left\"}} -->\n";
	$content .= '<div class="wp-block-buttons">' . "\n";
	$content .= "<!-- wp:button {\"backgroundColor\":\"vivid-red\",\"textColor\":\"white\"} -->\n";
	$content .= '<div class="wp-block-button"><a class="wp-block-button__link has-white-color has-vivid-red-background-color has-text-color has-background wp-element-button" href="' . $feedback . '" target="_blank" rel="noreferrer noopener">Share your feedback</a></div>' . "\n";
	$content .= "<!-- /wp:button -->\n";
	$content .= '</div>' . "\n";
	$content .= "<!-- /wp:buttons -->\n\n";

	$content .= "<!-- wp:paragraph {\"fontSize\":\"small\"} -->\n";
	$content .= '<p class="has-small-font-size"><em>Thanks for trying it. — The Opa team</em></p>' . "\n";
	$content .= "<!-- /wp:paragraph -->\n";

	return $content;
}

/**
 * Insert (or update) the Welcome-to-Opa post. Idempotent.
 *
 * @return int|WP_Error Post ID on success, WP_Error otherwise.
 */
function opa_seed_welcome_post() {
	// Reuse existing seeded post if present (idempotency marker on post meta).
	$existing = get_posts( array(
		'post_type'      => 'post',
		'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
		'meta_key'       => '_opa_seeded_welcome',
		'meta_value'     => '1',
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );

	$post_args = array(
		'post_title'   => 'Welcome to Opa!',
		'post_content' => opa_get_welcome_post_content(),
		'post_status'  => 'publish',
		'post_type'    => 'post',
		'post_author'  => 1,
	);

	if ( ! empty( $existing ) ) {
		$post_args['ID'] = (int) $existing[0];
		$post_id         = wp_update_post( $post_args, true );
	} else {
		$post_id = wp_insert_post( $post_args, true );
		if ( ! is_wp_error( $post_id ) && $post_id ) {
			update_post_meta( $post_id, '_opa_seeded_welcome', '1' );
		}
	}

	return $post_id;
}
