<?php
/**
 * Opa Editor Curation
 *
 * Controls the editing experience at the platform level using WordPress
 * core filters. Independent of whatever theme is active on the site.
 *
 * Architecture:
 * - Theme (TT5) = how the site looks to visitors (styles, variations, templates).
 * - Opa platform = how the editor works for writers (blocks, controls, behavior).
 *
 * Tunable values (block allowlist, embed kept set, theme.json layout sizes)
 * track .planning/phases/02.5-editor-experience-lock-in/02.5-TUNABLES.md.
 *
 * @package Opa_Platform
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter 1 (Layer 1) — wp_theme_json_data_theme
 *
 * Disables design controls in the editor (color, typography, border, spacing,
 * shadow, position, dimensions, background) without disabling the active
 * theme's front-end styles or style variations. Sets editor canvas widths.
 */
add_filter( 'wp_theme_json_data_theme', 'opa_editor_curation' );

function opa_editor_curation( $theme_json ) {
	return $theme_json->update_with(
		array(
			'version'  => 3,
			'settings' => array(
				'layout'     => array(
					'contentSize' => '680px',
					'wideSize'    => '1080px',
				),
				'color'      => array(
					'custom'           => false,
					'customGradient'   => false,
					'customDuotone'    => false,
					'defaultPalette'   => false,
					'defaultGradients' => false,
					'defaultDuotone'   => false,
				),
				'typography' => array(
					'customFontSize' => false,
					'dropCap'        => false,
					'fontStyle'      => false,
					'fontWeight'     => false,
					'letterSpacing'  => false,
					'lineHeight'     => false,
					'textDecoration' => false,
					'textTransform'  => false,
					'writingMode'    => false,
				),
				'border'     => array(
					'color'  => false,
					'radius' => false,
					'style'  => false,
					'width'  => false,
				),
				'spacing'    => array(
					'margin'            => false,
					'padding'           => false,
					'customSpacingSize' => false,
				),
				'shadow'     => array(
					'defaultPresets' => false,
					'presets'        => array(),
				),
				'position'   => array(
					'sticky' => false,
				),
				'dimensions' => array(
					'minHeight'           => false,
					'defaultAspectRatios' => false,
				),
				'background' => array(
					'backgroundImage' => false,
					'backgroundSize'  => false,
				),
				'blocks'     => array(
					'core/image' => array(
						'lightbox' => array(
							'allowEditing' => false,
							'enabled'      => false,
						),
					),
				),
			),
		)
	);
}

/**
 * Filter 2 (Layer 2) — allowed_block_types_all
 *
 * Restricts the block inserter (sidebar, slash command, "+" button) to a
 * writing-focused allowlist. See 02.5-TUNABLES.md item 1 for the current
 * 16-block set.
 */
add_filter( 'allowed_block_types_all', 'opa_allowed_blocks', 25, 2 );

function opa_allowed_blocks( $allowed_blocks, $editor_context ) {
	return array(
		'core/paragraph',
		'core/heading',
		'core/list',
		'core/list-item',
		'core/quote',
		'core/pullquote',
		'core/verse',
		'core/code',
		'core/table',
		'core/image',
		'core/gallery',
		'core/video',
		'core/audio',
		'core/separator',
		'core/embed',
		'core/missing',
	);
}

/**
 * Filter 3 (Layer 3) — block_editor_settings_all
 *
 * Editor-level behavior settings not covered by theme.json. Disables the
 * code editor view; restricts block locking to network admins.
 */
add_filter( 'block_editor_settings_all', 'opa_editor_behavior', 10, 2 );

function opa_editor_behavior( $settings, $context ) {
	$settings['codeEditingEnabled'] = false;

	if ( ! current_user_can( 'manage_network' ) ) {
		$settings['canLockBlocks'] = false;
	}

	// REQ-12 (D-A5c): replace Gutenberg's "Add title" with Opa-voiced prompt.
	// Source: Gutenberg's PostTitle component reads titlePlaceholder via
	// getSettings() and falls back to __( 'Add title' ) when absent.
	$settings['titlePlaceholder'] = __( "What's on your mind?", 'opa-platform' );

	// REQ-12 (Plan 01 follow-up): inject Subtitle canvas styles into the
	// BlockCanvas iframe. editor-overrides.css only loads in the editor shell
	// (enqueue_block_editor_assets), not inside the iframe. Settings.styles
	// is the canonical primitive for canvas-scoped CSS.
	if ( ! isset( $settings['styles'] ) || ! is_array( $settings['styles'] ) ) {
		$settings['styles'] = array();
	}
	$settings['styles'][] = array(
		'css' => '
			.opa-post-subtitle-wrapper { margin-top: 0.5rem; margin-bottom: 1.5rem; }
			.opa-post-subtitle {
				font-family: inherit;
				font-size: 1.125rem;
				line-height: 1.5;
				color: inherit;
				opacity: 0.72;
				margin: 0;
				padding: 0;
			}
			.opa-post-subtitle[data-rich-text-placeholder]::before,
			.opa-post-subtitle.is-empty::before {
				opacity: 0.55;
				font-style: normal;
			}
			/* Generous bottom padding so the writer never bumps into the canvas
			   edge — keeps the next block insert always feeling roomy. */
			.editor-styles-wrapper,
			.is-root-container,
			.wp-block-post-content {
				padding-bottom: 12rem;
			}
		',
	);

	return $settings;
}

/**
 * Action — remove core block patterns
 *
 * Opa supplies its own patterns (Phase 2.5+). Core patterns clutter the
 * inserter and don't match the writing-first editorial intent.
 */
add_action( 'after_setup_theme', 'opa_remove_core_patterns' );

function opa_remove_core_patterns() {
	remove_theme_support( 'core-block-patterns' );
}

/**
 * Action — load active theme's editor styles into the canvas
 *
 * Required so the writer sees the theme's typography and layout in the
 * editor (not just on the front end).
 */
add_action( 'after_setup_theme', 'opa_add_editor_styles_support' );

function opa_add_editor_styles_support() {
	add_theme_support( 'editor-styles' );
}

/**
 * Enqueue — editor-restrictions.js (Layers 4-6)
 *
 * Runs `wp.richText.unregisterFormatType`, `wp.blocks.unregisterBlockStyle`,
 * and `wp.blocks.unregisterBlockVariation` calls per
 * .planning/phases/02.5-editor-experience-lock-in/02.5-TUNABLES.md.
 *
 * Loaded on every block editor surface (`enqueue_block_editor_assets`),
 * not just the Opa SPA, so any future block editor surface stays curated.
 */
add_action( 'enqueue_block_editor_assets', 'opa_enqueue_editor_restrictions' );

function opa_enqueue_editor_restrictions() {
	$asset_path = OPA_PLATFORM_DIR . 'build/editor-restrictions.asset.php';

	if ( ! file_exists( $asset_path ) ) {
		return;
	}

	$asset = require $asset_path;

	wp_enqueue_script(
		'opa-editor-restrictions',
		OPA_PLATFORM_URL . 'build/editor-restrictions.js',
		$asset['dependencies'],
		$asset['version'],
		true
	);
}
