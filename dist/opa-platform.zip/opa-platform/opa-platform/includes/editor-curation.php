<?php
/**
 * Opa Editor Curation
 *
 * Controls the editing experience at the platform level using WordPress
 * core filters. Independent of whatever theme is active on the site.
 *
 * Architecture:
 * - Theme (TT5) = how the site looks to visitors (styles, variations, templates).
 * - Opa platform = how the editor works for writers (blocks, controls, behavior).
 *
 * Tunable values (block allowlist, embed kept set, theme.json layout sizes)
 * track .planning/phases/02.5-editor-experience-lock-in/02.5-TUNABLES.md.
 *
 * @package Opa_Platform
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter 1 (Layer 1) — wp_theme_json_data_theme
 *
 * Disables design controls in the editor (color, typography, border, spacing,
 * shadow, position, dimensions, background) without disabling the active
 * theme's front-end styles or style variations. Sets editor canvas widths.
 */
add_filter( 'wp_theme_json_data_theme', 'opa_editor_curation' );

function opa_editor_curation( $theme_json ) {
	return $theme_json->update_with(
		array(
			'version'  => 3,
			'settings' => array(
				'layout'     => array(
					'contentSize' => '680px',
					'wideSize'    => '1080px',
				),
				'color'      => array(
					'custom'           => false,
					'customGradient'   => false,
					'customDuotone'    => false,
					'defaultPalette'   => false,
					'defaultGradients' => false,
					'defaultDuotone'   => false,
				),
				'typography' => array(
					'customFontSize' => false,
					'dropCap'        => false,
					'fontStyle'      => false,
					'fontWeight'     => false,
					'letterSpacing'  => false,
					'lineHeight'     => false,
					'textDecoration' => false,
					'textTransform'  => false,
					'writingMode'    => false,
				),
				'border'     => array(
					'color'  => false,
					'radius' => false,
					'style'  => false,
					'width'  => false,
				),
				'spacing'    => array(
					'margin'            => false,
					'padding'           => false,
					'customSpacingSize' => false,
				),
				'shadow'     => array(
					'defaultPresets' => false,
					'presets'        => array(),
				),
				'position'   => array(
					'sticky' => false,
				),
				'dimensions' => array(
					'minHeight'           => false,
					'defaultAspectRatios' => false,
				),
				'background' => array(
					'backgroundImage' => false,
					'backgroundSize'  => false,
				),
				'blocks'     => array(
					'core/image' => array(
						'lightbox' => array(
							'allowEditing' => false,
							'enabled'      => false,
						),
					),
				),
			),
		)
	);
}

/**
 * Filter 2 (Layer 2) — allowed_block_types_all
 *
 * Restricts the block inserter (sidebar, slash command, "+" button) to a
 * writing-focused allowlist. See 02.5-TUNABLES.md item 1 for the current
 * 16-block set.
 */
add_filter( 'allowed_block_types_all', 'opa_allowed_blocks', 25, 2 );

function opa_allowed_blocks( $allowed_blocks, $editor_context ) {
	return array(
		'core/paragraph',
		'core/heading',
		'core/list',
		'core/list-item',
		'core/quote',
		'core/pullquote',
		'core/verse',
		'core/code',
		'core/table',
		'core/image',
		'core/gallery',
		'core/video',
		'core/audio',
		'core/separator',
		'core/embed',
		'core/missing',
	);
}

/**
 * Filter 3 (Layer 3) — block_editor_settings_all
 *
 * Editor-level behavior settings not covered by theme.json. Disables the
 * code editor view; restricts block locking to network admins.
 */
add_filter( 'block_editor_settings_all', 'opa_editor_behavior', 10, 2 );

function opa_editor_behavior( $settings, $context ) {
	$settings['codeEditingEnabled'] = false;

	if ( ! current_user_can( 'manage_network' ) ) {
		$settings['canLockBlocks'] = false;
	}

	// REQ-12 (D-A5c): replace Gutenberg's "Add title" with Opa-voiced prompt.
	// Source: Gutenberg's PostTitle component reads titlePlaceholder via
	// getSettings() and falls back to __( 'Add title' ) when absent.
	$settings['titlePlaceholder'] = __( "What's on your mind?", 'opa-platform' );

	// REQ-12 (Plan 01 follow-up): inject Subtitle canvas styles into the
	// BlockCanvas iframe. editor-overrides.css only loads in the editor shell
	// (enqueue_block_editor_assets), not inside the iframe. Settings.styles
	// is the canonical primitive for canvas-scoped CSS.
	if ( ! isset( $settings['styles'] ) || ! is_array( $settings['styles'] ) ) {
		$settings['styles'] = array();
	}
	$settings['styles'][] = array(
		'css' => '
			.opa-post-subtitle-wrapper { margin-top: 0.5rem; margin-bottom: 1.5rem; }
			.opa-post-subtitle {
				font-family: inherit;
				font-size: 1.125rem;
				line-height: 1.5;
				color: inherit;
				opacity: 0.72;
				margin: 0;
				padding: 0;
			}
			.opa-post-subtitle[data-rich-text-placeholder]::before,
			.opa-post-subtitle.is-empty::before {
				opacity: 0.55;
				font-style: normal;
			}
			/* Generous bottom padding so the writer never bumps into the canvas
			   edge — keeps the next block insert always feeling roomy. */
			.editor-styles-wrapper,
			.is-root-container,
			.wp-block-post-content {
				padding-bottom: 12rem;
			}

			/* Replace Gutenberg\'s default blue selected-block outline with
			   Opa coral. Design handoff (Block Editor Refinements): "1px
			   solid #FF5A5F selection outline around the focused block and
			   rgba(255, 90, 95, 0.22) text selection highlight are Opa
			   chrome behaviors painted over the canvas." Uses !important
			   because Gutenberg paints the blue with high specificity from
			   its own bundle.

			   Polish nuance: hide the selected-block outline while the
			   user is actively typing (body.is-typing is added by
			   block-editor when keystrokes flow). The cursor + the
			   floating toolbar are enough indicators during composition;
			   the outline reasserts itself when the user pauses. Hover
			   outline stays on always so block boundaries are
			   discoverable. */
			.block-editor-block-list__block.is-selected:not(.is-multi-selected),
			.block-editor-block-list__block.has-child-selected:not(.is-multi-selected) {
				outline: 1px solid #FF5A5F !important;
				outline-offset: -1px;
			}
			body.is-typing .block-editor-block-list__block.is-selected:not(.is-multi-selected),
			body.is-typing .block-editor-block-list__block.has-child-selected:not(.is-multi-selected) {
				outline: 1px solid transparent !important;
			}
			.block-editor-block-list__block.is-hovered:not(.is-selected) {
				outline: 1px solid rgba(255, 90, 95, 0.30);
				outline-offset: -1px;
			}
			::selection {
				background: rgba(255, 90, 95, 0.22);
			}

			/* Restyle Gutenberg\'s default blue block-inserter line + ⊕
			   button to Opa coral. The full custom Opa inserter component
			   ships in State 1c; for now we paint coral over the native
			   DOM so the canvas reads as Opa, not WordPress.

			   Targets are stable WP class names (.block-editor-block-list
			   __insertion-point-*). !important throughout because these
			   inherit from .wp-admin-theme-color CSS custom properties
			   that we can\'t override at the variable level inside the
			   iframe. */
			.block-editor-block-list__insertion-point-indicator {
				background: #FF5A5F !important;
			}
			.block-editor-block-list__insertion-point-inserter .block-editor-button-block-appender,
			.block-editor-block-list__insertion-point-inserter .block-editor-inserter__toggle,
			.block-editor-inserter__toggle.has-icon {
				background: #FFFFFF !important;
				color: #FF5A5F !important;
				border-radius: 50% !important;
				box-shadow: 0 0 0 1.5px #FF5A5F !important;
				width: 24px !important;
				min-width: 24px !important;
				height: 24px !important;
				padding: 0 !important;
				transition: background 120ms ease, color 120ms ease, transform 120ms ease, box-shadow 120ms ease !important;
			}
			.block-editor-block-list__insertion-point-inserter .block-editor-button-block-appender:hover,
			.block-editor-block-list__insertion-point-inserter .block-editor-inserter__toggle:hover,
			.block-editor-inserter__toggle.has-icon:hover {
				background: #FF5A5F !important;
				color: #FFFFFF !important;
				transform: scale(1.1) !important;
				box-shadow: 0 2px 8px rgba(255, 90, 95, 0.30), 0 0 0 1.5px #FF5A5F !important;
			}
			.block-editor-block-list__insertion-point-inserter .block-editor-button-block-appender svg,
			.block-editor-block-list__insertion-point-inserter .block-editor-inserter__toggle svg,
			.block-editor-inserter__toggle.has-icon svg {
				width: 14px !important;
				height: 14px !important;
			}
		',
	);

	// core/embed placeholder — Opa-token styling for WP's native embed flow.
	//
	// Behavior is 100% native: the +inserter / slash command / paste-autoembed
	// all stay as WordPress shipped them, including the real provider brand
	// icons that core/embed variations register via wp.blocks.registerBlockVariation.
	// We only restyle the .components-placeholder surface so picking YouTube /
	// Vimeo / Spotify / etc. reads as the same dialog language as OpaLinkPopover
	// (12px radius, soft drop shadow, coral focus on the URL input, pill coral
	// submit). Hardcoded color values because CSS custom properties don't cross
	// the editor iframe.
	$settings['styles'][] = array(
		'css' => '
			.wp-block-embed .components-placeholder,
			.wp-block-embed .components-placeholder.is-large {
				background: #ffffff;
				border: 1px solid #f3f4f6;
				border-radius: 12px;
				box-shadow:
					0 0 0 1px rgba(17, 17, 17, 0.04),
					0 4px 8px rgba(17, 17, 17, 0.03),
					0 12px 32px rgba(17, 17, 17, 0.08);
				font-family: "Rubik", "Noto Sans", system-ui, sans-serif;
				color: #111111;
				padding: 24px;
				outline: none;
			}
			.wp-block-embed .components-placeholder::before,
			.wp-block-embed .components-placeholder.is-large::before {
				display: none !important;
			}
			.wp-block-embed .components-placeholder__label {
				font-size: 14px;
				font-weight: 600;
				color: #111111;
				margin: 0 0 8px;
				gap: 8px;
			}
			.wp-block-embed .components-placeholder__label .block-editor-block-icon svg,
			.wp-block-embed .components-placeholder__label svg {
				width: 24px;
				height: 24px;
			}
			.wp-block-embed .components-placeholder__instructions {
				font-size: 13px;
				color: #6b7280;
				margin: 0 0 14px;
				line-height: 1.5;
			}
			.wp-block-embed .components-placeholder__fieldset {
				display: flex;
				gap: 8px;
				margin: 0;
			}
			.wp-block-embed .components-placeholder__input {
				flex: 1;
				height: 38px;
				padding: 0 12px;
				border-radius: 8px;
				border: 1.5px solid #e5e7eb;
				background: #f5f5f7;
				font-family: inherit;
				font-size: 13.5px;
				color: #111111;
				transition: border-color 120ms ease, background 120ms ease, box-shadow 120ms ease;
			}
			.wp-block-embed input:focus,
			.wp-block-embed input:focus-visible,
			.wp-block-embed input[type="url"]:focus,
			.wp-block-embed input[type="url"]:focus-visible,
			.wp-block-embed .components-placeholder input:focus,
			.wp-block-embed .components-placeholder input:focus-visible,
			.wp-block-embed .components-placeholder__input:focus,
			.wp-block-embed .components-placeholder__input:focus-visible,
			.wp-block-embed .components-text-control__input:focus,
			.wp-block-embed .components-text-control__input:focus-visible {
				outline: none !important;
				border-color: #FF5A5F !important;
				background: #ffffff !important;
				box-shadow: 0 0 0 3px rgba(255, 90, 95, 0.12) !important;
			}
			.wp-block-embed .components-placeholder__input::placeholder {
				color: #6b7280;
				opacity: 0.65;
			}
			.wp-block-embed .components-placeholder__fieldset .components-button.is-primary {
				background: #FF5A5F;
				color: #ffffff;
				border-radius: 999px;
				font-family: "Rubik", "Noto Sans", system-ui, sans-serif;
				font-size: 14px;
				font-weight: 500;
				padding: 8px 16px;
				min-height: 36px;
				border: 0;
				box-shadow: none;
				transition: background 120ms ease, box-shadow 120ms ease;
			}
			.wp-block-embed .components-placeholder__fieldset .components-button.is-primary:hover {
				background: #e04e52;
				box-shadow: 0 6px 18px rgba(255, 90, 95, 0.24);
			}
			.wp-block-embed .components-placeholder__learn-more,
			.wp-block-embed .components-placeholder .components-external-link,
			.wp-block-embed .components-placeholder a[href*="wordpress.org"] {
				display: none !important;
			}
			.wp-block-embed .components-placeholder__error {
				margin-top: 12px;
				color: #dc2626;
				font-size: 13px;
			}

			/* Selection / hover ring for the embed block follows the
			   placeholder\'s 12px radius. CSS outline can\'t round, so we
			   swap the generic coral outline (lines ~195-207) for a
			   box-shadow on the embed block specifically. */
			.block-editor-block-list__block.wp-block-embed.is-selected:not(.is-multi-selected),
			.block-editor-block-list__block.wp-block-embed.has-child-selected:not(.is-multi-selected) {
				outline: 1px solid transparent !important;
				border-radius: 12px;
				box-shadow: 0 0 0 1px #FF5A5F;
			}
			body.is-typing .block-editor-block-list__block.wp-block-embed.is-selected:not(.is-multi-selected),
			body.is-typing .block-editor-block-list__block.wp-block-embed.has-child-selected:not(.is-multi-selected) {
				box-shadow: none;
			}
			.block-editor-block-list__block.wp-block-embed.is-hovered:not(.is-selected) {
				outline: 1px solid transparent !important;
				border-radius: 12px;
				box-shadow: 0 0 0 1px rgba(255, 90, 95, 0.30);
			}
		',
	);

	return $settings;
}

/**
 * Action — remove core block patterns
 *
 * Opa supplies its own patterns (Phase 2.5+). Core patterns clutter the
 * inserter and don't match the writing-first editorial intent.
 */
add_action( 'after_setup_theme', 'opa_remove_core_patterns' );

function opa_remove_core_patterns() {
	remove_theme_support( 'core-block-patterns' );
}

/**
 * Action — load active theme's editor styles into the canvas
 *
 * Required so the writer sees the theme's typography and layout in the
 * editor (not just on the front end).
 */
add_action( 'after_setup_theme', 'opa_add_editor_styles_support' );

function opa_add_editor_styles_support() {
	add_theme_support( 'editor-styles' );
}

/**
 * Enqueue — editor-restrictions.js (Layers 4-6)
 *
 * Runs `wp.richText.unregisterFormatType`, `wp.blocks.unregisterBlockStyle`,
 * and `wp.blocks.unregisterBlockVariation` calls per
 * .planning/phases/02.5-editor-experience-lock-in/02.5-TUNABLES.md.
 *
 * Loaded on every block editor surface (`enqueue_block_editor_assets`),
 * not just the Opa SPA, so any future block editor surface stays curated.
 */
add_action( 'enqueue_block_editor_assets', 'opa_enqueue_editor_restrictions' );

function opa_enqueue_editor_restrictions() {
	$asset_path = OPA_PLATFORM_DIR . 'build/editor-restrictions.asset.php';

	if ( ! file_exists( $asset_path ) ) {
		return;
	}

	$asset = require $asset_path;

	wp_enqueue_script(
		'opa-editor-restrictions',
		OPA_PLATFORM_URL . 'build/editor-restrictions.js',
		$asset['dependencies'],
		$asset['version'],
		true
	);
}
