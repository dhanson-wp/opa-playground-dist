<?php
/**
 * User-meta-backed UI preferences for the Opa SPA.
 *
 * Registered as REST-visible user meta so the React shell can read/write
 * via @wordpress/core-data's useEntityProp('root','user','meta',userId).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_meta( 'user', 'opa_sidebar_expanded', array(
		'type'              => 'boolean',
		'default'           => false,
		'single'            => true,
		'show_in_rest'      => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'auth_callback'     => function ( $allowed, $meta_key, $object_id ) {
			return get_current_user_id() === (int) $object_id;
		},
	) );

	register_meta( 'user', 'opa_rhythm_cadence', array(
		'type'              => 'string',
		'default'           => 'weekly',
		'single'            => true,
		'show_in_rest'      => array(
			'schema' => array(
				'type' => 'string',
				'enum' => array( 'daily', 'weekly', 'monthly' ),
			),
		),
		'sanitize_callback' => function ( $value ) {
			$allowed = array( 'daily', 'weekly', 'monthly' );
			return in_array( $value, $allowed, true ) ? $value : 'weekly';
		},
		'auth_callback'     => function ( $allowed, $meta_key, $object_id ) {
			return get_current_user_id() === (int) $object_id;
		},
	) );

	// Per-user goals for the dashboard Rhythm Section. Heterogeneous list of
	// smart (auto-tracked by activity) and manual (user-checked) goals.
	register_meta( 'user', 'opa_rhythm_goals', array(
		'type'              => 'array',
		'default'           => opa_rhythm_default_goals(),
		'single'            => true,
		'show_in_rest'      => array(
			'schema' => array(
				'type'  => 'array',
				'items' => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'properties'           => array(
						'id'      => array( 'type' => 'string' ),
						'kind'    => array( 'type' => 'string', 'enum' => array( 'smart', 'manual' ) ),
						'trigger' => array( 'type' => array( 'string', 'null' ) ),
						'text'    => array( 'type' => 'string' ),
						'icon'    => array( 'type' => 'string' ),
						'done'    => array( 'type' => 'boolean' ),
					),
				),
			),
		),
		'sanitize_callback' => 'opa_rhythm_sanitize_goals',
		'auth_callback'     => function ( $allowed, $meta_key, $object_id ) {
			return get_current_user_id() === (int) $object_id;
		},
	) );
} );

/**
 * First-run seed: one smart goal (auto-checks on publish) + one manual goal
 * so the user sees both shapes in the list on their first dashboard load.
 */
function opa_rhythm_default_goals() {
	return array(
		array(
			'id'      => 's_publish_default',
			'kind'    => 'smart',
			'trigger' => 'publish',
			'text'    => 'Publish a post',
			'icon'    => 'ph-paper-plane-tilt',
		),
		array(
			'id'   => 'm_outline_default',
			'kind' => 'manual',
			'text' => 'Outline your next post',
			'done' => false,
		),
	);
}

/**
 * Validate each goal in the array. Drop any item that doesn't match a known
 * shape; never persist garbage. Returns an empty array on completely invalid
 * input rather than the default seed — the user is explicitly clearing here.
 */
function opa_rhythm_sanitize_goals( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}

	$allowed_triggers = array( 'publish', 'draft', 'idea', 'publish_n:2', 'publish_n:3' );
	$out              = array();

	foreach ( $value as $item ) {
		if ( ! is_array( $item ) || empty( $item['id'] ) || empty( $item['kind'] ) ) {
			continue;
		}

		$id   = sanitize_key( $item['id'] );
		$kind = $item['kind'];

		if ( 'smart' === $kind ) {
			$trigger = isset( $item['trigger'] ) ? (string) $item['trigger'] : '';
			if ( ! in_array( $trigger, $allowed_triggers, true ) ) {
				continue;
			}
			$out[] = array(
				'id'      => $id,
				'kind'    => 'smart',
				'trigger' => $trigger,
				'text'    => isset( $item['text'] ) ? wp_strip_all_tags( (string) $item['text'] ) : '',
				'icon'    => isset( $item['icon'] ) ? sanitize_key( $item['icon'] ) : '',
			);
		} elseif ( 'manual' === $kind ) {
			$text = isset( $item['text'] ) ? trim( wp_strip_all_tags( (string) $item['text'] ) ) : '';
			if ( '' === $text ) {
				continue;
			}
			$out[] = array(
				'id'   => $id,
				'kind' => 'manual',
				'text' => mb_substr( $text, 0, 140 ),
				'done' => ! empty( $item['done'] ),
			);
		}
	}

	return $out;
}
