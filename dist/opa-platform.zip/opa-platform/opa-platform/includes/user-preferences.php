<?php
/**
 * User-meta-backed UI preferences for the Opa SPA.
 *
 * Registered as REST-visible user meta so the React shell can read/write
 * via @wordpress/core-data's useEntityProp('root','user','meta',userId).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_meta( 'user', 'opa_sidebar_expanded', array(
		'type'              => 'boolean',
		'default'           => false,
		'single'            => true,
		'show_in_rest'      => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'auth_callback'     => function ( $allowed, $meta_key, $object_id ) {
			return get_current_user_id() === (int) $object_id;
		},
	) );
} );
