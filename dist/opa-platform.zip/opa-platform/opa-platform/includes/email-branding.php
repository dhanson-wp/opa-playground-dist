<?php
/**
 * Brand the password-reset email — subject + HTML body.
 *
 * Composes the body via opa_email_shell() so every future transactional
 * email Opa sends (welcome, magic-link login, comment notifications,
 * etc.) inherits the same envelope: brand strip, wordmark, heading,
 * greeting, paragraphs, pill CTA, copy-paste fallback URL, meta links,
 * note, sender footer.
 *
 * Filters:
 * - retrieve_password_title:   custom subject line
 * - retrieve_password_message: HTML body via opa_email_shell()
 * - wp_mail_content_type:      scoped to text/html for this single send
 *   (one-shot filter that removes itself after firing)
 *
 * The reset URL in the email is generated via network_site_url() inside
 * core's retrieve_password(); login-url-rewrite.php's network_site_url
 * filter rewrites wp-login.php → /login before the URL ever lands here.
 *
 * Other core wp_mail emails (comment notifications, post notifications,
 * etc.) are NOT touched by this file — they still get the wp_mail_from
 * and wp_mail_from_name filters applied in multisite-provisioning.php
 * (sender brand is correct) but their bodies stay as core's defaults.
 * Full template branding for those is a future polish branch.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'retrieve_password_title',   'opa_email_password_reset_title',   10, 3 );
add_filter( 'retrieve_password_message', 'opa_email_password_reset_message', 10, 4 );

/**
 * Subject line for the password-reset / new-invite email.
 *
 * One subject for both first-time-invitee and existing-user-reset
 * scenarios. Reads as a welcome on first send and as a reset
 * confirmation on subsequent sends.
 */
function opa_email_password_reset_title( $title, $user_login, $user_data ) {
	return 'Set your Opa password';
}

/**
 * HTML body for the password-reset / new-invite email.
 *
 * Builds the reset URL the same way core's retrieve_password() does —
 * network_site_url() with action=rp + key + login. The login-url-rewrite
 * filter on network_site_url turns this into /login?action=rp&... so the
 * email body never contains "wp-login.php".
 */
function opa_email_password_reset_message( $message, $key, $user_login, $user_data ) {
	// Reset URL — same composition as core wp-login.php's lostpassword
	// flow. The network_site_url filter rewrites wp-login.php → login.
	$reset_url = network_site_url(
		'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $user_login ),
		'login'
	);

	// Greet by username. user_login is the canonical, predictable identifier;
	// display_name is often derived from the site title at creation time and
	// reads worse than the slug. Fall back to the filter's $user_login arg
	// if the $user_data object is shaped unexpectedly (defensive).
	$user_name = '';
	if ( is_object( $user_data ) && ! empty( $user_data->user_login ) ) {
		$user_name = (string) $user_data->user_login;
	} elseif ( is_string( $user_login ) && $user_login !== '' ) {
		$user_name = $user_login;
	}

	// "Your site" should point at the invitee's own subsite, not the site
	// retrieve_password() happened to run from (which is the main site
	// whenever the reset is triggered from /login or by `wp opa create-site`).
	// Use the user's active/primary blog for the URL.
	$site_url = opa_email_user_primary_site_url( $user_data );

	// Switch to HTML for this single send via a one-shot content-type
	// filter. Other wp_mail() calls in this request stay plain-text.
	add_filter( 'wp_mail_content_type', 'opa_email_one_shot_html_content_type' );

	return opa_email_shell( array(
		'subject'    => 'Set your Opa password',
		'preheader'  => 'Click the button to set a password and log in to your new Opa site.',
		'heading'    => 'Set your password',
		'greeting'   => $user_name !== '' ? sprintf( 'Hi %s,', $user_name ) : 'Hi there,',
		'paragraphs' => array(
			'Welcome to Opa. Click the button below to set a password and log in to your new site.',
		),
		'cta_label'  => 'Set password',
		'cta_url'    => $reset_url,
		'meta'       => array(
			array( 'label' => 'Your site:', 'url' => $site_url ),
		),
		'note'       => "If you didn't expect this email, you can safely ignore it.",
	) );
}

/**
 * One-shot wp_mail_content_type filter. Returns text/html and unhooks
 * itself so subsequent wp_mail() calls in the same request stay
 * plain-text.
 */
function opa_email_one_shot_html_content_type() {
	remove_filter( 'wp_mail_content_type', 'opa_email_one_shot_html_content_type' );
	return 'text/html';
}

/**
 * Resolve the URL of the user's primary subsite on the network.
 *
 * Password-reset emails get triggered from main-site context (either
 * /login on opa.blog OR `wp opa create-site` running as super-admin),
 * so home_url() would return the network's main site URL — wrong for
 * the "Your site:" line in the welcome email body, which should point
 * at the invitee's actual blog (e.g. marjorie.opa.blog).
 *
 * Uses get_active_blog_for_user() which returns the user's primary
 * blog as a WP_Site object (or false if the user isn't a member of any
 * blog). Falls back to main-site home_url on miss.
 */
function opa_email_user_primary_site_url( $user_data ) {
	if ( is_object( $user_data ) && ! empty( $user_data->ID ) && function_exists( 'get_active_blog_for_user' ) ) {
		$primary = get_active_blog_for_user( (int) $user_data->ID );
		if ( $primary && ! empty( $primary->home ) ) {
			return trailingslashit( (string) $primary->home );
		}
		if ( $primary && ! empty( $primary->blog_id ) ) {
			return trailingslashit( (string) get_home_url( (int) $primary->blog_id ) );
		}
	}
	return home_url( '/' );
}
