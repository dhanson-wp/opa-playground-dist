<?php
/**
 * Visual branding for the login screens.
 *
 * Replaces the WordPress logo with Opa, applies the brand coral as the
 * primary action color, and switches link/button hovers to match. Affects
 * /login (the login form), /login?action=rp (reset-password), and
 * /login?action=resetpass (set-new-password) uniformly.
 *
 * URL hide is in login-url-rewrite.php; this file only handles visuals.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'login_enqueue_scripts', 'opa_login_enqueue_styles' );
add_filter( 'login_headerurl',       'opa_login_header_url' );
add_filter( 'login_headertext',      'opa_login_header_text' );

/**
 * Enqueue our login stylesheet on top of the core login screen.
 */
function opa_login_enqueue_styles() {
	wp_enqueue_style(
		'opa-login',
		OPA_PLATFORM_URL . 'assets/css/login.css',
		array(),
		OPA_PLATFORM_VERSION
	);
}

/**
 * Logo link target — point at the marketing site instead of wordpress.org.
 */
function opa_login_header_url() {
	return 'https://opa.blog/';
}

/**
 * Logo anchor text. Used as alt text for the logo image and as visible
 * text when the wordmark CSS treatment is in effect.
 */
function opa_login_header_text() {
	return 'Opa';
}
