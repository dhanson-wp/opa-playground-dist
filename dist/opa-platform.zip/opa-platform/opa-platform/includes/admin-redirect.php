<?php
/**
 * Redirect standard wp-admin pages to the Opa SPA.
 *
 * Allows a ?opa_bypass=1 query param to access raw wp-admin for debugging.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_init', function () {
	// Allow bypass for debugging.
	if ( isset( $_GET['opa_bypass'] ) && $_GET['opa_bypass'] === '1' ) {
		return;
	}

	// Don't redirect AJAX, REST, or Cron requests.
	if ( wp_doing_ajax() || wp_doing_cron() || defined( 'REST_REQUEST' ) ) {
		return;
	}

	// Don't redirect the Opa page itself.
	if ( isset( $_GET['page'] ) && $_GET['page'] === 'opa' ) {
		return;
	}

	// Don't redirect admin-post.php or admin-ajax.php.
	$script = basename( $_SERVER['SCRIPT_FILENAME'] ?? '' );
	if ( in_array( $script, array( 'admin-post.php', 'admin-ajax.php', 'async-upload.php' ), true ) ) {
		return;
	}

	wp_safe_redirect( admin_url( 'admin.php?page=opa' ) );
	exit;
} );
