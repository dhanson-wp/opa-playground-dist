<?php
/**
 * Redirect standard wp-admin pages to the Opa SPA.
 *
 * Allows a ?opa_bypass=1 query param to access raw wp-admin for debugging.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_init', function () {
	// Allow bypass for debugging.
	if ( isset( $_GET['opa_bypass'] ) && $_GET['opa_bypass'] === '1' ) {
		return;
	}

	// Don't redirect AJAX, REST, or Cron requests.
	if ( wp_doing_ajax() || wp_doing_cron() || defined( 'REST_REQUEST' ) ) {
		return;
	}

	// Don't redirect Network Admin. The Opa SPA is end-user-facing chrome;
	// Network Admin is super-admin platform UI (site creation, theme
	// network-enable, network plugin management, network settings) and
	// must stay accessible as raw wp-admin.
	if ( is_network_admin() ) {
		return;
	}

	// Don't redirect the production marketing site.
	//
	// On opa.blog production, the network main site (blog_id 1) is the
	// marketing / landing site — Opa user blogs live on subsites
	// (blog_id > 1) and those keep the SPA redirect. A single-site
	// production fork would also be the marketing site.
	//
	// Local / development / staging always get the SPA. Studio is
	// single-site by default, and gating purely on multisite/main-site
	// would block SPA dev there. `wp_get_environment_type()` returns
	// 'production' when WP_ENVIRONMENT_TYPE is unset (Pressable prod
	// behavior); Studio sets it to 'local'.
	$is_production_env = function_exists( 'wp_get_environment_type' )
		? wp_get_environment_type() === 'production'
		: true;
	if ( $is_production_env && ( ! is_multisite() || is_main_site() ) ) {
		return;
	}

	// Don't redirect the Opa page itself.
	if ( isset( $_GET['page'] ) && $_GET['page'] === 'opa' ) {
		return;
	}

	// Don't redirect admin-post.php or admin-ajax.php.
	$script = basename( $_SERVER['SCRIPT_FILENAME'] ?? '' );
	if ( in_array( $script, array( 'admin-post.php', 'admin-ajax.php', 'async-upload.php' ), true ) ) {
		return;
	}

	// Don't redirect when the Opa SPA hasn't been built. Redirecting to
	// admin.php?page=opa with no compiled JS just lands the admin on a
	// blank page — a worse experience than raw wp-admin. Skipping the
	// redirect lets the local-dev / fresh-checkout flow degrade
	// gracefully (Studio testing without `npm run build`, or a deploy
	// that lands the PHP before the build artifacts).
	if ( ! file_exists( OPA_PLATFORM_DIR . 'build/index.js' ) ) {
		return;
	}

	wp_safe_redirect( admin_url( 'admin.php?page=opa' ) );
	exit;
} );
