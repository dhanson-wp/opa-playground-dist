<?php
/**
 * Rename WordPress's default "Uncategorized" category to "Posts".
 *
 * WordPress ships every site with a default category term named
 * "Uncategorized" (slug `uncategorized`, usually term ID 1). When a
 * writer publishes without picking a category, the post gets that
 * default — and "Uncategorized" reads like a placeholder, not a brand
 * voice. We rename it once per site so every Opa site gets a friendlier
 * default.
 *
 * Idempotent + one-shot: guarded by the `opa_default_category_renamed`
 * option so the rename runs once. If a writer later renames the term
 * themselves (or back to "Uncategorized"), we don't revert it on the
 * next page load.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', 'opa_rename_default_category', 99 );

function opa_rename_default_category() {
	if ( get_option( 'opa_default_category_renamed' ) ) {
		return;
	}

	$term = get_term_by( 'slug', 'uncategorized', 'category' );

	// Term doesn't exist yet (fresh install, before WP seeds defaults)
	// — leave the flag unset so we try again next request. Once WP has
	// seeded the term, this branch won't fire.
	if ( ! $term ) {
		return;
	}

	// Someone already renamed it — set the flag so we don't keep
	// checking every page load, but don't touch the name.
	if ( $term->name !== 'Uncategorized' ) {
		update_option( 'opa_default_category_renamed', 1, true );
		return;
	}

	// Avoid colliding with an existing "posts" slug (rare, but possible
	// if a writer has created a category with that slug).
	$existing = get_term_by( 'slug', 'posts', 'category' );
	$args     = array( 'name' => 'Posts' );
	if ( ! $existing || (int) $existing->term_id === (int) $term->term_id ) {
		$args['slug'] = 'posts';
	}

	$result = wp_update_term( $term->term_id, 'category', $args );

	if ( ! is_wp_error( $result ) ) {
		update_option( 'opa_default_category_renamed', 1, true );
	}
}
