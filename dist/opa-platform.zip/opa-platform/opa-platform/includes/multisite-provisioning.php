<?php
/**
 * Multisite onboarding: provision new sites with Opa defaults.
 *
 * Hooks the wp_initialize_site action (WP 5.1+) to activate opa-theme,
 * set Opa option defaults, seed inviter metadata, clean up WordPress
 * default content (Hello World post, Sample Page, sample comment), and
 * mark the site as provisioned (idempotency).
 *
 * Also registers wp_uninitialize_site teardown to clear Opa-specific
 * site meta before core drops the tables.
 *
 * Top-level Pressable-invisibility filters live here too:
 * - remove core's WP-branded site-creation notification email
 * - suppress legacy multisite welcome / signup notification emails
 * - rewrite From-address + From-Name on every wp_mail send so any
 *   email leaking through still presents as Opa, not Pressable
 *
 * Sender address is configurable via the OPA_FROM_EMAIL constant in
 * wp-config.php (defaults to hello@opa.blog) so we can flip from a
 * working address (e.g. a personal Automattic alias) to the production
 * opa.blog mailbox once SPF/DKIM/DMARC alignment lands.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const OPA_PROVISIONED_META_KEY = 'opa_provisioned_at';
const OPA_DEFAULT_THEME        = 'opa-theme';

/* -------------------------------------------------------------------------
 * Pressable / WP invisibility — top-level filters.
 * ----------------------------------------------------------------------- */

// Stop core's "Your new site at X has been created" admin email.
remove_action( 'wp_initialize_site', 'newblog_notify_siteadmin', 100 );

// Suppress legacy multisite welcome / signup notification emails. These
// fire from wpmu signup flows we don't use, but suppressing them is cheap
// insurance against any code path firing them through.
add_filter( 'wpmu_welcome_notification',     '__return_false' );
add_filter( 'wpmu_signup_blog_notification', '__return_false' );
add_filter( 'newuser_notify_siteadmin',      '__return_false' );

// Network-wide From-address + From-Name. Any email leaking past our
// branding still shows as Opa.
add_filter( 'wp_mail_from',      'opa_get_from_email' );
add_filter( 'wp_mail_from_name', 'opa_get_from_name' );

/**
 * Resolve the platform "From:" email address.
 *
 * Reads OPA_FROM_EMAIL from wp-config.php if defined, otherwise falls
 * back to hello@opa.blog. Lets ops flip senders without a code change
 * during the period before opa.blog SPF/DKIM/DMARC are aligned.
 */
function opa_get_from_email() {
	if ( defined( 'OPA_FROM_EMAIL' ) && constant( 'OPA_FROM_EMAIL' ) ) {
		return (string) constant( 'OPA_FROM_EMAIL' );
	}
	return 'hello@opa.blog';
}

/**
 * Resolve the platform "From:" name.
 */
function opa_get_from_name() {
	if ( defined( 'OPA_FROM_NAME' ) && constant( 'OPA_FROM_NAME' ) ) {
		return (string) constant( 'OPA_FROM_NAME' );
	}
	return 'Opa';
}

/* -------------------------------------------------------------------------
 * Provisioning callback.
 *
 * Fires from wp_insert_site() at line 105 of wp-includes/ms-site.php.
 *
 * IMPORTANT: this callback runs at priority 20, AFTER the default
 * wp_initialize_site() function (priority 10) which does the
 * switch_to_blog → table creation → option populate → admin assign →
 * restore_current_blog cycle. By the time we run, blog context has been
 * restored to the parent site, so we must switch_to_blog explicitly to
 * touch the new site's options and posts.
 * ----------------------------------------------------------------------- */

add_action( 'wp_initialize_site', 'opa_provision_new_site', 20, 2 );

/**
 * @param \WP_Site $new_site The newly inserted site object.
 * @param array    $args     Args passed to wp_insert_site() (with core
 *                           defaults stripped). Custom keys placed at
 *                           $args['opa_provisioning'] (direct callers like
 *                           our WP-CLI command) or $args['options']['opa_provisioning']
 *                           (callers that go through wpmu_create_blog).
 */
function opa_provision_new_site( $new_site, $args ) {
	$site_id = (int) $new_site->id;

	// Idempotency guard. If we've already provisioned this site, bail.
	$provisioned_at = get_site_meta( $site_id, OPA_PROVISIONED_META_KEY, true );
	if ( ! empty( $provisioned_at ) ) {
		return;
	}

	// Pull the provisioning payload from either possible location.
	$provisioning = array();
	if ( ! empty( $args['opa_provisioning'] ) && is_array( $args['opa_provisioning'] ) ) {
		$provisioning = $args['opa_provisioning'];
	} elseif ( ! empty( $args['options']['opa_provisioning'] ) && is_array( $args['options']['opa_provisioning'] ) ) {
		$provisioning = $args['options']['opa_provisioning'];
	}

	// Default callback already restored blog context; switch back to the new site.
	switch_to_blog( $site_id );

	// Activate the canonical Opa theme. Verify it exists first — if it's
	// not Network Enabled yet we log and proceed without theme switch
	// rather than hard-failing provisioning on a runbook gap.
	$theme = wp_get_theme( OPA_DEFAULT_THEME );
	if ( $theme->exists() ) {
		switch_theme( OPA_DEFAULT_THEME );
	} else {
		error_log( sprintf(
			'[opa] %s theme not found at provisioning time for site %d; theme switch skipped. Network-Enable it via Network Admin → Themes.',
			OPA_DEFAULT_THEME,
			$site_id
		) );
	}

	// Sane Opa defaults. Tunable values; the option keys are load-bearing.
	update_option( 'blog_public',             1 );
	update_option( 'permalink_structure',     '/%postname%/' );
	update_option( 'default_pingback_flag',   0 );
	update_option( 'default_ping_status',     'closed' );
	update_option( 'default_comment_status',  'open' );
	update_option( 'timezone_string',         'UTC' );

	// Clean up WordPress's default content. New sites should not start
	// with "Hello world!" + "Sample Page".
	wp_delete_post( 1, true );    // "Hello world!" post
	wp_delete_post( 2, true );    // "Sample Page"
	wp_delete_comment( 1, true ); // sample comment on Hello World

	// Seed inviter metadata on the assigned site admin if we have it.
	$user_id = isset( $args['user_id'] ) ? (int) $args['user_id'] : 0;
	if ( $user_id > 0 ) {
		$inviter = isset( $provisioning['inviter'] ) ? sanitize_text_field( (string) $provisioning['inviter'] ) : '';
		if ( $inviter !== '' ) {
			update_user_meta( $user_id, 'opa_invited_by', $inviter );
		}
		update_user_meta( $user_id, 'opa_onboarding_state', 'invited' );
	}

	restore_current_blog();

	// Mark provisioned. Site meta is the per-site idiomatic post-WP-5.1
	// flag location; persists across requests and is cleared by our
	// teardown callback when the site is deleted.
	update_site_meta( $site_id, OPA_PROVISIONED_META_KEY, time() );
}

/* -------------------------------------------------------------------------
 * Teardown callback.
 *
 * Fires from wp_delete_site() at line 261 of wp-includes/ms-site.php,
 * before any data destruction. Register at priority < 10 to run before
 * core's default wp_uninitialize_site() drops the tables.
 * ----------------------------------------------------------------------- */

add_action( 'wp_uninitialize_site', 'opa_teardown_site', 5, 1 );

/**
 * @param \WP_Site $old_site The site about to be deleted.
 */
function opa_teardown_site( $old_site ) {
	$site_id = (int) $old_site->id;

	// Clear Opa-specific site meta. Currently just the provisioned flag;
	// future opa_* keys will sit in this list.
	delete_site_meta( $site_id, OPA_PROVISIONED_META_KEY );

	// User meta (opa_invited_by, opa_onboarding_state) is global and
	// follows the user across sites. We don't clear it on site delete
	// because the user might be invited again later.
}
