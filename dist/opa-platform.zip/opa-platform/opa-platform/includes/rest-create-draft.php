<?php
/**
 * Custom REST endpoint to create a draft post.
 *
 * Uses get_default_post_to_edit() — the same mechanism WordPress uses
 * on post-new.php — to reliably create an auto-draft.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'opa/v1', '/create-draft', array(
		'methods'             => 'POST',
		'callback'            => 'opa_rest_create_draft',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'args'                => array(
			'content' => array(
				'type'              => 'string',
				'required'          => false,
				'sanitize_callback' => 'wp_kses_post',
			),
		),
	) );
} );

function opa_rest_create_draft( \WP_REST_Request $request ) {
	require_once ABSPATH . 'wp-admin/includes/post.php';

	$post = get_default_post_to_edit( 'post', true );

	if ( ! $post || ! $post->ID ) {
		return new \WP_Error(
			'opa_draft_failed',
			'Could not create auto-draft.',
			array( 'status' => 500 )
		);
	}

	// Seed the body content if the client provided a thought / first line.
	// Wrapped in a paragraph block so the editor renders it correctly inside
	// BlockEditor (raw text would render as a freeform / classic block).
	$seed = trim( (string) $request->get_param( 'content' ) );
	if ( '' !== $seed ) {
		$paragraph = "<!-- wp:paragraph -->\n<p>" . esc_html( $seed ) . "</p>\n<!-- /wp:paragraph -->";
		wp_update_post( array(
			'ID'           => $post->ID,
			'post_content' => $paragraph,
		) );
		$post = get_post( $post->ID );
	}

	// Return the full post object in REST edit context so the client can
	// pre-seed the core-data store and skip a second fetch.
	$controller = new \WP_REST_Posts_Controller( 'post' );
	$rest_request = new \WP_REST_Request( 'GET', '/wp/v2/posts/' . $post->ID );
	$rest_request->set_param( 'context', 'edit' );
	$response = $controller->prepare_item_for_response( $post, $rest_request );

	return rest_ensure_response( $response->get_data() );
}
