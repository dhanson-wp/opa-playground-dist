<?php
/**
 * Custom REST endpoint to create a draft post.
 *
 * Uses get_default_post_to_edit() — the same mechanism WordPress uses
 * on post-new.php — to reliably create an auto-draft.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'opa/v1', '/create-draft', array(
		'methods'             => 'POST',
		'callback'            => 'opa_rest_create_draft',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'args'                => array(
			'content' => array(
				'type'        => 'string',
				'required'    => false,
				'description' => 'Optional seed text to drop in as the first paragraph of the new post. When present, the post is promoted from auto-draft to draft so the typed work survives auto-draft GC (~10 days).',
				// REST validates type; sanitization happens in the
				// callback via wp_kses_post so we keep paragraph-level
				// HTML if any client ever wants to send richer seed.
			),
		),
	) );
} );

function opa_rest_create_draft( $request ) {
	require_once ABSPATH . 'wp-admin/includes/post.php';

	$post = get_default_post_to_edit( 'post', true );

	if ( ! $post || ! $post->ID ) {
		return new \WP_Error(
			'opa_draft_failed',
			'Could not create auto-draft.',
			array( 'status' => 500 )
		);
	}

	// Optional seed content from the dashboard quick-capture. When the
	// user types something and hits "Start draft", we drop it in as the
	// opening paragraph block and promote the post from auto-draft to
	// draft. Promotion matters: WP garbage-collects auto-drafts after ~10
	// days, but the user has already invested keystrokes — that work
	// shouldn't vanish if they wander off mid-flow.
	$raw_content = $request->get_param( 'content' );
	if ( is_string( $raw_content ) ) {
		$seed = trim( wp_kses_post( $raw_content ) );
		if ( $seed !== '' ) {
			$paragraph = '<!-- wp:paragraph -->' . "\n"
				. '<p>' . $seed . '</p>' . "\n"
				. '<!-- /wp:paragraph -->';

			wp_update_post( array(
				'ID'           => $post->ID,
				'post_content' => $paragraph,
				'post_status'  => 'draft',
			) );

			// Refresh the in-memory post object so the response below
			// reflects the seeded content + promoted status.
			$post = get_post( $post->ID );
		}
	}

	// Return the full post object in REST edit context so the client can
	// pre-seed the core-data store and skip a second fetch.
	$controller = new \WP_REST_Posts_Controller( 'post' );
	$rest_request = new \WP_REST_Request( 'GET', '/wp/v2/posts/' . $post->ID );
	$rest_request->set_param( 'context', 'edit' );
	$response = $controller->prepare_item_for_response( $post, $rest_request );

	return rest_ensure_response( $response->get_data() );
}
