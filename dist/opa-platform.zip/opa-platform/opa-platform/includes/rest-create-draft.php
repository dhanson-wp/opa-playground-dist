<?php
/**
 * Custom REST endpoint to create a draft post.
 *
 * Uses get_default_post_to_edit() — the same mechanism WordPress uses
 * on post-new.php — to reliably create an auto-draft.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'opa/v1', '/create-draft', array(
		'methods'             => 'POST',
		'callback'            => 'opa_rest_create_draft',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	) );
} );

function opa_rest_create_draft() {
	require_once ABSPATH . 'wp-admin/includes/post.php';

	$post = get_default_post_to_edit( 'post', true );

	if ( ! $post || ! $post->ID ) {
		return new \WP_Error(
			'opa_draft_failed',
			'Could not create auto-draft.',
			array( 'status' => 500 )
		);
	}

	// Return the full post object in REST edit context so the client can
	// pre-seed the core-data store and skip a second fetch.
	$controller = new \WP_REST_Posts_Controller( 'post' );
	$request    = new \WP_REST_Request( 'GET', '/wp/v2/posts/' . $post->ID );
	$request->set_param( 'context', 'edit' );
	$response = $controller->prepare_item_for_response( $post, $request );

	return rest_ensure_response( $response->get_data() );
}
