<?php
/**
 * Opa author chrome — server-rendered floating avatar + dropdown injected on
 * the public frontend via wp_body_open. Logged-in users only. Logged-out
 * readers see no Opa chrome at all (login is a network-level concern).
 *
 * The dropdown surfaces an Edit-this-post entry when the user can edit the
 * current singular post, plus quick-access links to the SPA's existing routes
 * (Dashboard, New post, Drafts, Posts, Profile, Settings, Sign out).
 *
 * Theme-agnostic: the chrome floats above whatever theme is active. No JS
 * bundle on the public frontend beyond a tiny vanilla helper for dropdown
 * toggle, outside-click, and Escape handling. Icons are inline SVG.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hide WordPress's default frontend admin bar — Opa owns frontend chrome, and
 * exposing wp-admin UI on the public site contradicts the project rule
 * ("No WordPress admin exposure in the UI. Ever." — see CLAUDE.md). Authors
 * use the floating Opa avatar dropdown instead.
 */
add_filter( 'show_admin_bar', '__return_false' );

/**
 * Add a body class when the Opa author chrome is rendering. The CSS uses this
 * to push theme content below the floating avatar's row.
 */
add_filter( 'body_class', function ( $classes ) {
	if ( opa_public_toolbar_should_render() && is_user_logged_in() ) {
		$classes[] = 'has-opa-author-chrome';
	}
	return $classes;
} );

/**
 * Enqueue the chrome's CSS + JS on public-frontend page loads where the chrome
 * will actually render.
 */
add_action( 'wp_enqueue_scripts', 'opa_public_toolbar_enqueue' );
function opa_public_toolbar_enqueue() {
	if ( ! opa_public_toolbar_should_render() ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		return;
	}

	$css_path = OPA_PLATFORM_DIR . 'src/brand/public-toolbar.css';
	$js_path  = OPA_PLATFORM_DIR . 'src/brand/public-toolbar.js';

	if ( file_exists( $css_path ) ) {
		wp_enqueue_style(
			'opa-public-toolbar',
			OPA_PLATFORM_URL . 'src/brand/public-toolbar.css',
			array(),
			OPA_PLATFORM_VERSION . '-' . filemtime( $css_path )
		);
	}

	if ( file_exists( $js_path ) ) {
		wp_enqueue_script(
			'opa-public-toolbar',
			OPA_PLATFORM_URL . 'src/brand/public-toolbar.js',
			array(),
			OPA_PLATFORM_VERSION . '-' . filemtime( $js_path ),
			true
		);
	}
}

/**
 * Render the floating avatar + dropdown at the top of <body>.
 */
add_action( 'wp_body_open', 'opa_public_toolbar_render' );
function opa_public_toolbar_render() {
	if ( ! opa_public_toolbar_should_render() ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		return;
	}

	$user = wp_get_current_user();
	if ( ! $user || ! $user->ID ) {
		return;
	}

	$avatar_url   = get_avatar_url( $user->ID, array( 'size' => 80 ) );
	$display_name = $user->display_name ? $user->display_name : $user->user_login;
	$handle       = '@' . $user->user_login;
	$current_url  = opa_public_toolbar_current_url();

	// Sign-out destination. Production: bring the user back to where they
	// were (now logged out). Beta / Playground: redirect to an external URL
	// (opa.blog waitlist) by setting `opa_external_signout_url` option.
	$external_signout = get_option( 'opa_external_signout_url', '' );
	$signout_redirect = ( is_string( $external_signout ) && '' !== $external_signout )
		? esc_url_raw( $external_signout )
		: $current_url;
	$logout_url       = wp_logout_url( $signout_redirect );

	$dashboard_url = admin_url( 'admin.php?page=opa#/dashboard' );
	$editor_url    = admin_url( 'admin.php?page=opa#/editor' );
	$drafts_url    = admin_url( 'admin.php?page=opa#/drafts' );
	$posts_url     = admin_url( 'admin.php?page=opa#/posts' );
	$profile_url   = admin_url( 'admin.php?page=opa#/profile' );
	$settings_url  = admin_url( 'admin.php?page=opa#/settings' );

	// Edit-this-post entry only when on a singular post the user can edit.
	$edit_post_url = '';
	if ( is_singular( 'post' ) ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post && current_user_can( 'edit_post', $post->ID ) ) {
			$edit_post_url = admin_url( 'admin.php?page=opa#/editor/' . $post->ID );
		}
	}

	?>
	<aside class="opa-author-chrome" data-opa-author-chrome>
		<button
			type="button"
			class="opa-author-chrome__trigger"
			aria-expanded="false"
			aria-haspopup="menu"
			aria-controls="opa-author-menu"
			aria-label="<?php echo esc_attr( sprintf( __( 'Open menu for %s', 'opa' ), $display_name ) ); ?>"
			data-opa-author-trigger
		>
			<span class="opa-author-chrome__avatar">
				<?php if ( $avatar_url ) : ?>
					<img src="<?php echo esc_url( $avatar_url ); ?>" alt="" width="40" height="40" loading="lazy" />
				<?php else : ?>
					<?php echo opa_public_toolbar_icon( 'user-circle' ); ?>
				<?php endif; ?>
			</span>
			<span class="opa-author-chrome__chevron" aria-hidden="true">
				<?php echo opa_public_toolbar_icon( 'caret-down' ); ?>
			</span>
		</button>

		<div
			class="opa-author-chrome__menu"
			id="opa-author-menu"
			role="menu"
			aria-labelledby="opa-author-menu-trigger"
		>
			<div class="opa-author-chrome__header">
				<div class="opa-author-chrome__header-avatar">
					<?php if ( $avatar_url ) : ?>
						<img src="<?php echo esc_url( $avatar_url ); ?>" alt="" width="44" height="44" loading="lazy" />
					<?php else : ?>
						<?php echo opa_public_toolbar_icon( 'user-circle' ); ?>
					<?php endif; ?>
				</div>
				<div>
					<div class="opa-author-chrome__header-name"><?php echo esc_html( $display_name ); ?></div>
					<div class="opa-author-chrome__header-handle"><?php echo esc_html( $handle ); ?></div>
				</div>
			</div>

			<ul class="opa-author-chrome__list">
				<?php if ( $edit_post_url ) : ?>
					<li class="opa-author-chrome__item">
						<a class="opa-author-chrome__link" href="<?php echo esc_url( $edit_post_url ); ?>" role="menuitem" data-variant="edit">
							<?php echo opa_public_toolbar_icon( 'pencil-simple' ); ?>
							<?php echo esc_html__( 'Edit this post', 'opa' ); ?>
						</a>
					</li>
				<?php endif; ?>

				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $dashboard_url ); ?>" role="menuitem">
						<?php echo opa_public_toolbar_icon( 'house' ); ?>
						<?php echo esc_html__( 'Dashboard', 'opa' ); ?>
					</a>
				</li>
				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $editor_url ); ?>" role="menuitem">
						<?php echo opa_public_toolbar_icon( 'pencil-simple' ); ?>
						<?php echo esc_html__( 'New post', 'opa' ); ?>
					</a>
				</li>
				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $drafts_url ); ?>" role="menuitem">
						<?php echo opa_public_toolbar_icon( 'note-pencil' ); ?>
						<?php echo esc_html__( 'Drafts', 'opa' ); ?>
					</a>
				</li>
				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $posts_url ); ?>" role="menuitem">
						<?php echo opa_public_toolbar_icon( 'newspaper' ); ?>
						<?php echo esc_html__( 'Posts', 'opa' ); ?>
					</a>
				</li>

				<li class="opa-author-chrome__divider" role="separator"></li>

				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $profile_url ); ?>" role="menuitem">
						<?php echo opa_public_toolbar_icon( 'user' ); ?>
						<?php echo esc_html__( 'Profile', 'opa' ); ?>
					</a>
				</li>
				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $settings_url ); ?>" role="menuitem">
						<?php echo opa_public_toolbar_icon( 'gear' ); ?>
						<?php echo esc_html__( 'Settings', 'opa' ); ?>
					</a>
				</li>

				<li class="opa-author-chrome__divider" role="separator"></li>

				<li class="opa-author-chrome__item">
					<a class="opa-author-chrome__link" href="<?php echo esc_url( $logout_url ); ?>" role="menuitem" data-variant="signout">
						<?php echo opa_public_toolbar_icon( 'sign-out' ); ?>
						<?php echo esc_html__( 'Sign out', 'opa' ); ?>
					</a>
				</li>
			</ul>
		</div>
	</aside>
	<?php
}

/**
 * Front-end only — never render in admin, customizer preview, REST, AJAX, or
 * feed contexts.
 */
function opa_public_toolbar_should_render() {
	if ( is_admin() ) {
		return false;
	}
	if ( wp_doing_ajax() ) {
		return false;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return false;
	}
	if ( is_feed() ) {
		return false;
	}
	if ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) {
		return false;
	}
	return true;
}

/**
 * Build the current URL — used to redirect back here after sign-out.
 */
function opa_public_toolbar_current_url() {
	$scheme = is_ssl() ? 'https' : 'http';
	$host   = isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : '';
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
	return $scheme . '://' . $host . $uri;
}

/**
 * Inline SVG for Phosphor Bold icons used by the chrome. Sourced from
 * @phosphor-icons/core (MIT) — node_modules/@phosphor-icons/core/assets/bold/
 * {name}-bold.svg. Inline keeps the public frontend free of font assets.
 */
function opa_public_toolbar_icon( $name ) {
	$icons = array(
		'pencil-simple' => '<path d="M230.14,70.54,185.46,25.85a20,20,0,0,0-28.29,0L33.86,149.17A19.85,19.85,0,0,0,28,163.31V208a20,20,0,0,0,20,20H92.69a19.86,19.86,0,0,0,14.14-5.86L230.14,98.82a20,20,0,0,0,0-28.28ZM91,204H52V165l84-84,39,39ZM192,103,153,64l18.34-18.34,39,39Z"/>',
		'user-circle'   => '<path d="M128,20A108,108,0,1,0,236,128,108.12,108.12,0,0,0,128,20ZM79.57,196.57a60,60,0,0,1,96.86,0,83.72,83.72,0,0,1-96.86,0ZM100,120a28,28,0,1,1,28,28A28,28,0,0,1,100,120ZM194,179.94a83.48,83.48,0,0,0-29-23.42,52,52,0,1,0-74,0,83.48,83.48,0,0,0-29,23.42,84,84,0,1,1,131.9,0Z"/>',
		'house'         => '<path d="M222.14,105.85l-80-80a20,20,0,0,0-28.28,0l-80,80A19.86,19.86,0,0,0,28,120v96a12,12,0,0,0,12,12h64a12,12,0,0,0,12-12V164h24v52a12,12,0,0,0,12,12h64a12,12,0,0,0,12-12V120A19.86,19.86,0,0,0,222.14,105.85ZM204,204H164V152a12,12,0,0,0-12-12H104a12,12,0,0,0-12,12v52H52V121.65l76-76,76,76Z"/>',
		'note-pencil'   => '<path d="M232.49,55.51l-32-32a12,12,0,0,0-17,0l-96,96A12,12,0,0,0,84,128v32a12,12,0,0,0,12,12h32a12,12,0,0,0,8.49-3.51l96-96A12,12,0,0,0,232.49,55.51ZM192,49l15,15L196,75,181,60Zm-69,99H108V133l56-56,15,15Zm105-7.43V208a20,20,0,0,1-20,20H48a20,20,0,0,1-20-20V48A20,20,0,0,1,48,28h67.43a12,12,0,0,1,0,24H52V204H204V140.57a12,12,0,0,1,24,0Z"/>',
		'newspaper'     => '<path d="M92,108a12,12,0,0,1,12-12h72a12,12,0,0,1,0,24H104A12,12,0,0,1,92,108Zm12,52h72a12,12,0,0,0,0-24H104a12,12,0,0,0,0,24ZM236,64V184a28,28,0,0,1-28,28H36A32,32,0,0,1,4,180V88a12,12,0,0,1,24,0v92a8,8,0,0,0,16,0V64A20,20,0,0,1,64,44H216A20,20,0,0,1,236,64Zm-24,4H68V180a32,32,0,0,1-1,8H208a4,4,0,0,0,4-4Z"/>',
		'user'          => '<path d="M234.38,210a123.36,123.36,0,0,0-60.78-53.23,76,76,0,1,0-91.2,0A123.36,123.36,0,0,0,21.62,210a12,12,0,1,0,20.77,12c18.12-31.32,50.12-50,85.61-50s67.49,18.69,85.61,50a12,12,0,0,0,20.77-12ZM76,96a52,52,0,1,1,52,52A52.06,52.06,0,0,1,76,96Z"/>',
		'gear'          => '<path d="M128,76a52,52,0,1,0,52,52A52.06,52.06,0,0,0,128,76Zm0,80a28,28,0,1,1,28-28A28,28,0,0,1,128,156Zm92-27.21v-1.58l14-17.51a12,12,0,0,0,2.23-10.59A111.75,111.75,0,0,0,225,71.89,12,12,0,0,0,215.89,66L193.61,63.5l-1.11-1.11L190,40.1A12,12,0,0,0,184.11,31a111.67,111.67,0,0,0-27.23-11.27A12,12,0,0,0,146.3,22L128.79,36h-1.58L109.7,22a12,12,0,0,0-10.59-2.23A111.75,111.75,0,0,0,71.89,31.05,12,12,0,0,0,66,40.11L63.5,62.39,62.39,63.5,40.1,66A12,12,0,0,0,31,71.89,111.67,111.67,0,0,0,19.77,99.12,12,12,0,0,0,22,109.7l14,17.51v1.58L22,146.3a12,12,0,0,0-2.23,10.59,111.75,111.75,0,0,0,11.29,27.22A12,12,0,0,0,40.11,190l22.28,2.48,1.11,1.11L66,215.9A12,12,0,0,0,71.89,225a111.67,111.67,0,0,0,27.23,11.27A12,12,0,0,0,109.7,234l17.51-14h1.58l17.51,14a12,12,0,0,0,10.59,2.23A111.75,111.75,0,0,0,184.11,225a12,12,0,0,0,5.91-9.06l2.48-22.28,1.11-1.11L215.9,190a12,12,0,0,0,9.06-5.91,111.67,111.67,0,0,0,11.27-27.23A12,12,0,0,0,234,146.3Zm-24.12-4.89a70.1,70.1,0,0,1,0,8.2,12,12,0,0,0,2.61,8.22l12.84,16.05A86.47,86.47,0,0,1,207,166.86l-20.43,2.27a12,12,0,0,0-7.65,4,69,69,0,0,1-5.8,5.8,12,12,0,0,0-4,7.65L166.86,207a86.47,86.47,0,0,1-10.49,4.35l-16.05-12.85a12,12,0,0,0-7.5-2.62c-.24,0-.48,0-.72,0a70.1,70.1,0,0,1-8.2,0,12.06,12.06,0,0,0-8.22,2.6L99.63,211.33A86.47,86.47,0,0,1,89.14,207l-2.27-20.43a12,12,0,0,0-4-7.65,69,69,0,0,1-5.8-5.8,12,12,0,0,0-7.65-4L49,166.86a86.47,86.47,0,0,1-4.35-10.49l12.84-16.05a12,12,0,0,0,2.61-8.22,70.1,70.1,0,0,1,0-8.2,12,12,0,0,0-2.61-8.22L44.67,99.63A86.47,86.47,0,0,1,49,89.14l20.43-2.27a12,12,0,0,0,7.65-4,69,69,0,0,1,5.8-5.8,12,12,0,0,0,4-7.65L89.14,49a86.47,86.47,0,0,1,10.49-4.35l16.05,12.85a12.06,12.06,0,0,0,8.22,2.6,70.1,70.1,0,0,1,8.2,0,12,12,0,0,0,8.22-2.6l16.05-12.85A86.47,86.47,0,0,1,166.86,49l2.27,20.43a12,12,0,0,0,4,7.65,69,69,0,0,1,5.8,5.8,12,12,0,0,0,7.65,4L207,89.14a86.47,86.47,0,0,1,4.35,10.49l-12.84,16.05A12,12,0,0,0,195.88,123.9Z"/>',
		'sign-out'      => '<path d="M124,216a12,12,0,0,1-12,12H48a12,12,0,0,1-12-12V40A12,12,0,0,1,48,28h64a12,12,0,0,1,0,24H60V204h52A12,12,0,0,1,124,216Zm108.49-96.49-40-40a12,12,0,0,0-17,17L195,116H112a12,12,0,0,0,0,24h83l-19.52,19.51a12,12,0,0,0,17,17l40-40A12,12,0,0,0,232.49,119.51Z"/>',
		'caret-down'    => '<path d="M216.49,104.49l-80,80a12,12,0,0,1-17,0l-80-80a12,12,0,0,1,17-17L128,159l71.51-71.52a12,12,0,0,1,17,17Z"/>',
	);

	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}

	return sprintf(
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true" focusable="false">%s</svg>',
		$icons[ $name ]
	);
}
