<?php
/**
 * Hide wp-login.php from URL bars and generated links.
 *
 * Maps /login to wp-login.php internally on request. Filters every
 * WordPress URL generator (site_url, network_site_url, login_url,
 * lostpassword_url, register_url) so any wp-login.php URL we'd otherwise
 * emit is rewritten to /login. Direct unauthenticated hits to
 * /wp-login.php return 404 — the URL doesn't reveal that WordPress is
 * the auth backend.
 *
 * Critical for the password-reset email: retrieve_password() generates
 * the reset URL via network_site_url('wp-login.php?action=rp&...'). The
 * network_site_url filter rewrites that to /login?action=rp&... before
 * it lands in the email body.
 *
 * Escape hatch: define OPA_WPLOGIN_PASSTHROUGH true in wp-config.php to
 * disable the hide-and-block behavior. Useful for emergency admin
 * recovery if anything in this rewrite breaks login.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const OPA_LOGIN_SLUG = 'login';

/**
 * Whether the hide-wp-login behavior is active.
 *
 * False if the OPA_WPLOGIN_PASSTHROUGH escape hatch is set in wp-config.
 */
function opa_login_hide_active() {
	if ( defined( 'OPA_WPLOGIN_PASSTHROUGH' ) && constant( 'OPA_WPLOGIN_PASSTHROUGH' ) ) {
		return false;
	}
	return true;
}

/**
 * Path component of the current request, normalized (no leading/trailing slash).
 */
function opa_login_request_path() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
	$path = (string) parse_url( $uri, PHP_URL_PATH );
	return trim( $path, '/' );
}

/* -------------------------------------------------------------------------
 * Request handling.
 *
 * Run on init at priority 1. Late enough that WordPress's bootstrap has
 * defined all the constants wp-login.php depends on (notably
 * AUTOSAVE_INTERVAL, set in wp_functionality_constants() at line 596 of
 * wp-settings.php — which fires AFTER plugins_loaded on line 593). Early
 * enough that we short-circuit before WordPress's request routing
 * decides /login is a 404 (which happens on template_redirect, much
 * later in the bootstrap).
 * ----------------------------------------------------------------------- */

add_action( 'init', 'opa_login_handle_request', 1 );

function opa_login_handle_request() {
	if ( ! opa_login_hide_active() ) {
		return;
	}

	$path = opa_login_request_path();

	if ( $path === OPA_LOGIN_SLUG ) {
		// /login — serve wp-login.php internally so the URL bar shows /login.
		// Setting SCRIPT_NAME / PHP_SELF lets wp-login.php's own URL-generation
		// logic compose the right links inside the form.
		define( 'OPA_LOGIN_ALIAS_ACTIVE', true );
		$_SERVER['SCRIPT_NAME'] = '/wp-login.php';
		$_SERVER['PHP_SELF']    = '/wp-login.php';

		// Pre-initialize variables wp-login.php expects to exist when it
		// renders the login form. wp-login.php sets these inside specific
		// action-branch case statements (e.g. on POST submissions); on a
		// plain GET, the render code at line ~1599 reads $user_login and
		// $error without them being set. PHP emits "Undefined variable"
		// warnings, which, with display_errors=On in dev, get injected
		// directly into the form's value="..." attribute. Pre-initializing
		// in this function's scope makes the variables visible to the
		// required wp-login.php (which inherits this scope when included
		// from inside a function).
		$user_login = '';
		$error      = '';

		require_once ABSPATH . 'wp-login.php';
		exit;
	}

	if ( $path === 'wp-login.php' && ! defined( 'OPA_LOGIN_ALIAS_ACTIVE' ) ) {
		// Direct hit to wp-login.php — 404, don't reveal the auth backend.
		opa_login_render_404();
		exit;
	}
}

/**
 * Send a generic 404 response. Doesn't reveal that wp-login.php is the
 * URL we're hiding.
 */
function opa_login_render_404() {
	status_header( 404 );
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	echo "<!doctype html>\n<html><head><title>Not Found</title></head><body><h1>Not Found</h1><p>The page you requested could not be found.</p></body></html>";
}

/* -------------------------------------------------------------------------
 * URL filters.
 *
 * Rewrite any URL containing wp-login.php to use /login. Variadic
 * signature handles every WP filter regardless of arg count
 * (site_url passes 4, login_url passes 3, lostpassword_url passes 2).
 * ----------------------------------------------------------------------- */

add_filter( 'site_url',         'opa_login_rewrite_url', 10, 4 );
add_filter( 'network_site_url', 'opa_login_rewrite_url', 10, 3 );
add_filter( 'login_url',        'opa_login_rewrite_url', 10, 3 );
add_filter( 'lostpassword_url', 'opa_login_rewrite_url', 10, 2 );
add_filter( 'register_url',     'opa_login_rewrite_url', 10, 1 );
add_filter( 'logout_url',       'opa_login_rewrite_url', 10, 2 );

// wp-login.php's lost-password and a few other branches use literal
// `wp_safe_redirect( 'wp-login.php?...' )` calls — bypassing site_url() and
// our URL filters above. The redirect URL slips out as-is and lands on our
// 404. Catch redirects that point at wp-login.php and rewrite to /login.
add_filter( 'wp_redirect',      'opa_login_rewrite_url', 10, 1 );

/**
 * Rewrite wp-login.php → /login in any URL, normalized to network root.
 *
 * In subdirectory multisite, wp_logout_url() / wp_login_url() / friends call
 * site_url('wp-login.php'), which on a subsite returns
 * http://host/sub-path/wp-login.php. A naïve str_replace would emit
 * http://host/sub-path/login — but opa_login_handle_request() only matches
 * the exact root path 'login', so subsite-prefixed URLs fall through and
 * (e.g.) Sign Out from a subsite frontend silently fails. Force every login
 * URL to the canonical /login at network root regardless of which blog
 * generated it.
 *
 * @param string $url   Filtered URL (always the first argument).
 * @param mixed  ...$rest Remaining filter args (path, scheme, blog_id, etc.) — ignored.
 */
function opa_login_rewrite_url( $url, ...$rest ) {
	if ( ! opa_login_hide_active() ) {
		return $url;
	}
	if ( ! is_string( $url ) ) {
		return $url;
	}
	if ( strpos( $url, 'wp-login.php' ) === false ) {
		return $url;
	}

	$parts = wp_parse_url( $url );
	if ( ! is_array( $parts ) ) {
		// Couldn't parse — fall back to the simple swap so we at least
		// don't emit a wp-login.php URL into the page.
		return str_replace( 'wp-login.php', OPA_LOGIN_SLUG, $url );
	}

	$path  = '/' . OPA_LOGIN_SLUG;
	$query = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
	$frag  = isset( $parts['fragment'] ) ? '#' . $parts['fragment'] : '';

	if ( ! empty( $parts['host'] ) ) {
		$scheme = isset( $parts['scheme'] ) ? $parts['scheme'] . '://' : '//';
		$port   = isset( $parts['port'] ) ? ':' . $parts['port'] : '';
		return $scheme . $parts['host'] . $port . $path . $query . $frag;
	}

	return $path . $query . $frag;
}
