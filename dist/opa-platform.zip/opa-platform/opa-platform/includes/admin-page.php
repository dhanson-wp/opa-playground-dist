<?php
/**
 * Register the Opa admin page and enqueue the SPA assets.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_menu_page(
		'Opa',
		'Opa',
		'read',
		'opa',
		'opa_render_app_shell',
		'dashicons-edit-large',
		2
	);
} );

// Enqueue assets when the Opa page is loaded.
add_action( 'admin_enqueue_scripts', function ( $hook_suffix ) {
	if ( $hook_suffix !== 'toplevel_page_opa' ) {
		return;
	}
	// Required for wp.media frame + wp.media.controller.SiteIconCropper.
	wp_enqueue_media();
	opa_enqueue_app_assets();
} );

// Preconnect to the Google Fonts CDN whenever the Opa SPA is loaded.
// Knocks ~150ms off first-paint for the brand fonts.
add_filter( 'wp_resource_hints', function ( $hints, $relation_type ) {
	if ( ! is_admin() ) {
		return $hints;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || $screen->id !== 'toplevel_page_opa' ) {
		return $hints;
	}
	if ( 'preconnect' === $relation_type ) {
		$hints[] = array(
			'href'        => 'https://fonts.googleapis.com',
			'crossorigin' => false,
		);
		$hints[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $hints;
}, 10, 2 );

function opa_render_app_shell() {
	echo '<div id="opa-root"></div>';
}

function opa_enqueue_app_assets() {
	$asset_file = OPA_PLATFORM_DIR . 'build/index.asset.php';

	if ( ! file_exists( $asset_file ) ) {
		return;
	}

	$asset = require $asset_file;
	$script_file       = OPA_PLATFORM_DIR . 'build/index.js';
	$style_file        = OPA_PLATFORM_DIR . 'build/index.css';
	$shared_style_file = OPA_PLATFORM_DIR . 'build/style-index.css';
	$script_ver        = $asset['version'] . '-' . filemtime( $script_file );
	$style_ver         = $asset['version'] . '-' . filemtime( $style_file );

	// Brand fonts — the design system references Comfortaa (display),
	// Rubik (sans body), Newsreader (serif) and JetBrains Mono (mono).
	// Without these enqueued, every chrome surface falls back to the
	// system stack and the brand voice disappears. Loaded from Google
	// Fonts; preconnect added below to keep first-paint snappy.
	wp_enqueue_style(
		'opa-brand-fonts',
		'https://fonts.googleapis.com/css2?family=Comfortaa:wght@400;500;600;700&family=Rubik:wght@300;400;500;600;700&family=Newsreader:ital,wght@0,400;0,500;0,600;1,400;1,500&family=JetBrains+Mono:wght@400;500;600&display=swap',
		array(),
		null
	);

	// wp-scripts emits a dependency list that includes every @wordpress/* package
	// our bundle imports (e.g. wp-dataviews, wp-format-library). On environments
	// where one of those isn't a registered script handle, wp_enqueue_script
	// silently drops the entire enqueue and the SPA never mounts. Filter to only
	// registered handles so a missing optional dep doesn't take down the page.
	$deps = array_values( array_filter(
		(array) $asset['dependencies'],
		static function ( $handle ) {
			return wp_script_is( $handle, 'registered' );
		}
	) );

	wp_enqueue_script(
		'opa-app',
		OPA_PLATFORM_URL . 'build/index.js',
		$deps,
		$script_ver,
		true
	);

	wp_enqueue_style(
		'opa-app',
		OPA_PLATFORM_URL . 'build/index.css',
		array( 'wp-components', 'wp-block-library', 'wp-block-editor', 'wp-editor', 'wp-edit-post' ),
		$style_ver
	);

	// wp-scripts splits CSS imports whose source filename matches `style.{css,scss}`
	// into a separate `style-index.css` output (the wp-scripts theme-style convention).
	// The vendored Phosphor `style.css` files land here. Enqueue alongside the main
	// stylesheet so `@font-face` declarations resolve at runtime.
	if ( file_exists( $shared_style_file ) ) {
		wp_enqueue_style(
			'opa-app-styles',
			OPA_PLATFORM_URL . 'build/style-index.css',
			array( 'opa-app' ),
			$asset['version'] . '-' . filemtime( $shared_style_file )
		);
	}

	// Build native block editor settings from the active theme's theme.json.
	// Use a post-aware context so the block_editor_settings_all filter
	// receives the correct post type and our editor-curation.php overrides apply.
	$context_post          = new \WP_Post( (object) array( 'ID' => 0, 'post_type' => 'post' ) );
	$block_editor_context  = new \WP_Block_Editor_Context( array( 'post' => $context_post ) );
	$editor_settings       = get_block_editor_settings(
		// Fixed top toolbar off until Phase 2.7 redesigns the editor surface.
		array( 'hasFixedToolbar' => false ),
		$block_editor_context
	);

	// Pass data to the SPA.
	// Note: canManageOptions / canUploadFiles are UX-only signals so the
	// shell can hide forms and disable controls. The REST layer
	// (wp/v2/settings, wp/v2/media) enforces the actual authorization.
	// Closed-alpha splash gate. wp_get_environment_type() returns 'local'
	// when the blueprint sets WP_ENVIRONMENT_TYPE=local (Playground) or when
	// Studio sets the same. Production Pressable returns 'production' and
	// the splash is suppressed.
	$env_type          = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'unknown';
	$show_alpha_splash = ( $env_type === 'local' );

	wp_localize_script( 'opa-app', 'opaSettings', array(
		'rootUrl'          => esc_url_raw( rest_url() ),
		'nonce'            => wp_create_nonce( 'wp_rest' ),
		'adminUrl'         => esc_url( admin_url() ),
		'siteUrl'          => esc_url( home_url() ),
		'userId'           => get_current_user_id(),
		'canManageOptions' => current_user_can( 'manage_options' ),
		'canUploadFiles'   => current_user_can( 'upload_files' ),
		'editorSettings'   => $editor_settings,
		'showAlphaSplash'  => $show_alpha_splash,
		'envType'          => $env_type,
	) );
}
