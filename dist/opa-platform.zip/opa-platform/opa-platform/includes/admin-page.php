<?php
/**
 * Register the Opa admin page and enqueue the SPA assets.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_menu_page(
		'Opa',
		'Opa',
		'read',
		'opa',
		'opa_render_app_shell',
		'dashicons-edit-large',
		2
	);
} );

// Enqueue assets when the Opa page is loaded.
add_action( 'admin_enqueue_scripts', function ( $hook_suffix ) {
	if ( $hook_suffix !== 'toplevel_page_opa' ) {
		return;
	}
	opa_enqueue_app_assets();
} );

function opa_render_app_shell() {
	echo '<div id="opa-root"></div>';
}

function opa_enqueue_app_assets() {
	$asset_file = OPA_PLATFORM_DIR . 'build/index.asset.php';

	if ( ! file_exists( $asset_file ) ) {
		return;
	}

	$asset = require $asset_file;
	$script_file       = OPA_PLATFORM_DIR . 'build/index.js';
	$style_file        = OPA_PLATFORM_DIR . 'build/index.css';
	$shared_style_file = OPA_PLATFORM_DIR . 'build/style-index.css';
	$script_ver        = $asset['version'] . '-' . filemtime( $script_file );
	$style_ver         = $asset['version'] . '-' . filemtime( $style_file );

	wp_enqueue_script(
		'opa-app',
		OPA_PLATFORM_URL . 'build/index.js',
		$asset['dependencies'],
		$script_ver,
		true
	);

	wp_enqueue_style(
		'opa-app',
		OPA_PLATFORM_URL . 'build/index.css',
		array( 'wp-components', 'wp-block-library', 'wp-block-editor', 'wp-editor', 'wp-edit-post' ),
		$style_ver
	);

	// wp-scripts splits CSS imports whose source filename matches `style.{css,scss}`
	// into a separate `style-index.css` output (the wp-scripts theme-style convention).
	// The vendored Phosphor `style.css` files land here. Enqueue alongside the main
	// stylesheet so `@font-face` declarations resolve at runtime.
	if ( file_exists( $shared_style_file ) ) {
		wp_enqueue_style(
			'opa-app-styles',
			OPA_PLATFORM_URL . 'build/style-index.css',
			array( 'opa-app' ),
			$asset['version'] . '-' . filemtime( $shared_style_file )
		);
	}

	// Build native block editor settings from the active theme's theme.json.
	// Use a post-aware context so the block_editor_settings_all filter
	// receives the correct post type and our editor-curation.php overrides apply.
	$context_post          = new \WP_Post( (object) array( 'ID' => 0, 'post_type' => 'post' ) );
	$block_editor_context  = new \WP_Block_Editor_Context( array( 'post' => $context_post ) );
	$editor_settings       = get_block_editor_settings(
		// Fixed top toolbar off until Phase 2.7 redesigns the editor surface.
		array( 'hasFixedToolbar' => false ),
		$block_editor_context
	);

	// Pass data to the SPA.
	wp_localize_script( 'opa-app', 'opaSettings', array(
		'rootUrl'        => esc_url_raw( rest_url() ),
		'nonce'          => wp_create_nonce( 'wp_rest' ),
		'adminUrl'       => esc_url( admin_url() ),
		'siteUrl'        => esc_url( home_url() ),
		'userId'         => get_current_user_id(),
		'editorSettings' => $editor_settings,
	) );
}
