<?php
/**
 * WP-CLI command: wp opa create-site.
 *
 * Creates a subdomain site on the network for an invitee, runs the
 * provisioning callback (theme, defaults, cleanup), and triggers
 * WordPress core's password-reset email — fully Opa-branded — so the
 * invitee gets a one-click set-password link without us touching SMTP
 * directly.
 *
 * Usage:
 *
 *   wp opa create-site marjorie --user=marjorie@example.com --inviter=Derek
 *   wp opa create-site test1    --user=test@example.com    --no-email
 *
 * Behavior:
 * - Looks up the user by email; creates one via wpmu_create_user if missing.
 * - Validates slug against DNS-style rules + 20-name reserved list.
 * - Calls wp_insert_site() so the wp_initialize_site action fires the
 *   provisioning callback (multisite-provisioning.php).
 * - Auto-triggers retrieve_password() → branded HTML email from
 *   hello@opa.blog (or whatever OPA_FROM_EMAIL is set to in wp-config).
 * - --no-email suppresses the reset email (testing / batch creation
 *   where email triggering happens later).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Only load when WP-CLI is the runtime.
if ( ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	return;
}

const OPA_SLUG_REGEX = '/^[a-z0-9](?:[a-z0-9-]{1,61}[a-z0-9])?$/';

const OPA_RESERVED_SLUGS = array(
	'www', 'admin', 'mail', 'api', 'ftp', 'staging', 'test',
	'root', 'web', 'main', 'invite', 'administrator',
	'opa', 'blog',
	'app', 'help', 'support', 'status', 'cdn', 'static',
);

WP_CLI::add_command( 'opa', 'Opa_CLI_Command' );

/**
 * Opa platform commands.
 */
class Opa_CLI_Command extends WP_CLI_Command {

	/**
	 * Create a new Opa site for an invitee.
	 *
	 * ## OPTIONS
	 *
	 * <slug>
	 * : Subdomain slug. Lowercase letters, digits, hyphens. 3-63 chars.
	 *   Cannot start or end with a hyphen. Reserved names blocked.
	 *
	 * --user=<email>
	 * : Invitee email. If a user with this email exists, they'll be
	 *   added as administrator on the new site. Otherwise a new user is
	 *   created with a random password.
	 *
	 * [--inviter=<name>]
	 * : Display name of the person inviting them. Stored as user meta
	 *   (opa_invited_by) on the new admin user. Defaults to the current
	 *   network admin's display name, or "Opa" if running as system.
	 *
	 * [--no-email]
	 * : Don't auto-trigger the password-reset email after site creation.
	 *   Useful for batch creation where you want to send invites
	 *   manually later, or for testing.
	 *
	 * ## EXAMPLES
	 *
	 *     wp opa create-site marjorie --user=marjorie@example.com --inviter=Derek
	 *     wp opa create-site test1    --user=test@example.com     --no-email
	 *
	 * @when after_wp_load
	 */
	public function create_site( $args, $assoc_args ) {
		$slug    = isset( $args[0] )                  ? strtolower( trim( (string) $args[0] ) )                  : '';
		$email   = isset( $assoc_args['user'] )       ? sanitize_email( (string) $assoc_args['user'] )           : '';
		$inviter = isset( $assoc_args['inviter'] )    ? sanitize_text_field( (string) $assoc_args['inviter'] )   : '';
		$no_mail = isset( $assoc_args['no-email'] );

		// 1. Validate slug.
		if ( $slug === '' ) {
			WP_CLI::error( 'Slug is required.' );
		}
		if ( ! preg_match( OPA_SLUG_REGEX, $slug ) ) {
			WP_CLI::error( 'Slug must be 3-63 chars, lowercase alphanumeric and hyphens, no leading or trailing hyphen.' );
		}
		if ( in_array( $slug, OPA_RESERVED_SLUGS, true ) ) {
			WP_CLI::error( sprintf( 'Slug "%s" is reserved.', $slug ) );
		}

		// 2. Validate email.
		if ( $email === '' || ! is_email( $email ) ) {
			WP_CLI::error( 'A valid --user=<email> is required.' );
		}

		// 3. Resolve network. Domain construction works on both staging
		//    (opa.mystagingwebsite.com) and prod (opa.blog) — uses
		//    the live network's domain.
		$network = get_network();
		if ( ! $network ) {
			WP_CLI::error( 'Could not resolve the current network.' );
		}
		$domain = $slug . '.' . $network->domain;
		$path   = $network->path;

		// 4. Slug uniqueness — fail fast before user creation.
		if ( domain_exists( $domain, $path ) ) {
			WP_CLI::error( sprintf( 'Domain %s is already taken.', $domain ) );
		}

		// 5. Resolve or create user.
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			$username = $this->generate_unique_username( $email );
			$user_id  = wpmu_create_user( $username, wp_generate_password( 24 ), $email );
			if ( ! $user_id ) {
				WP_CLI::error( sprintf( 'Failed to create user for %s.', $email ) );
			}
			$user = get_user_by( 'id', $user_id );
			WP_CLI::log( sprintf( 'Created user %s (id %d).', $username, $user_id ) );
		} else {
			WP_CLI::log( sprintf( 'Using existing user %s (id %d).', $user->user_login, $user->ID ) );
		}

		// 6. Default inviter if not provided.
		if ( $inviter === '' ) {
			$current = wp_get_current_user();
			$inviter = ( $current && $current->ID ) ? (string) $current->display_name : 'Opa';
		}

		// 7. Insert the site. Provisioning callback fires from
		//    wp_initialize_site action (priority 20, after core's
		//    default initialization at priority 10).
		$site_id = wp_insert_site( array(
			'domain'           => $domain,
			'path'             => $path,
			'network_id'       => (int) $network->id,
			'user_id'          => (int) $user->ID,
			'title'            => sprintf( '%s on Opa', $user->display_name ?: $user->user_login ),
			'opa_provisioning' => array(
				'inviter' => $inviter,
			),
		) );

		if ( is_wp_error( $site_id ) ) {
			WP_CLI::error( sprintf( 'Site insert failed: %s', $site_id->get_error_message() ) );
		}

		$site_url = sprintf( 'https://%s%s', $domain, $path );

		// 8. Trigger the branded password-reset email unless suppressed.
		if ( $no_mail ) {
			WP_CLI::log( '--no-email passed; skipping welcome email.' );
		} else {
			$result = retrieve_password( $user->user_login );
			if ( is_wp_error( $result ) ) {
				WP_CLI::warning( sprintf(
					'Site created but reset email failed: %s. Trigger manually via Network Admin → Users.',
					$result->get_error_message()
				) );
			} else {
				WP_CLI::log( sprintf( 'Welcome / password-reset email queued to %s.', $email ) );
			}
		}

		WP_CLI::success( sprintf( 'Site created: %s (id %d)', $site_url, $site_id ) );
	}

	/**
	 * Generate a unique username from the email's local part. Strips
	 * non-username chars and disambiguates with a numeric suffix if
	 * collisions exist.
	 */
	private function generate_unique_username( $email ) {
		$local    = strtolower( explode( '@', $email )[0] );
		$base     = preg_replace( '/[^a-z0-9_]/', '', $local );
		if ( $base === '' || strlen( $base ) < 3 ) {
			$base = 'user' . wp_rand( 100, 9999 );
		}
		$username = $base;
		$i        = 1;
		while ( username_exists( $username ) ) {
			$username = $base . $i;
			$i++;
		}
		return $username;
	}
}
