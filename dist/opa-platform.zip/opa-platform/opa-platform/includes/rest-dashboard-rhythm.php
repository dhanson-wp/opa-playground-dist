<?php
/**
 * REST endpoint powering the dashboard's Rhythm Section and the legacy
 * "active days this week" stat. Returns the current user's per-day post
 * activity over either the trailing 28 days (default) or a full calendar
 * year (?range=year&year=YYYY).
 *
 * Definitions
 *   "Active day"   — any day where the user has post activity (any type below).
 *   "this week"    — the trailing 7 calendar days ending today (inclusive),
 *                    in the site's timezone.
 *   activity types — per day, an array containing any of:
 *                      'publish' — a post had status=publish modified that day
 *                      'draft'   — an existing draft was edited that day
 *                                  (modified ≠ created, not a publish event)
 *                      'idea'    — a post was created that day (any new post,
 *                                  including same-day publishes)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'opa/v1', '/dashboard/rhythm', array(
		'methods'             => 'GET',
		'callback'            => 'opa_rest_dashboard_rhythm',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'args'                => array(
			'range' => array(
				'type'    => 'string',
				'enum'    => array( 'trailing28', 'year' ),
				'default' => 'trailing28',
			),
			'year'  => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
		),
	) );
} );

function opa_rest_dashboard_rhythm( $request ) {
	global $wpdb;

	$user_id = get_current_user_id();
	if ( ! $user_id ) {
		return new \WP_Error(
			'opa_rhythm_no_user',
			'No current user.',
			array( 'status' => 401 )
		);
	}

	$tz    = wp_timezone();
	$today = ( new \DateTimeImmutable( 'now', $tz ) )->setTime( 0, 0, 0 );
	$range = $request->get_param( 'range' );

	if ( 'year' === $range ) {
		$year       = (int) $request->get_param( 'year' );
		$now_year   = (int) $today->format( 'Y' );
		if ( $year <= 0 ) {
			$year = $now_year;
		}

		$start_local = ( new \DateTimeImmutable( sprintf( '%04d-01-01 00:00:00', $year ), $tz ) );
		$end_local   = $year === $now_year
			? $today
			: ( new \DateTimeImmutable( sprintf( '%04d-12-31 00:00:00', $year ), $tz ) );
	} else {
		$start_local = $today->modify( '-27 days' );
		$end_local   = $today;
	}

	$start_gmt = $start_local->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	$end_gmt   = $end_local->modify( '+1 day' )->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );

	$rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT ID, post_status, post_date_gmt, post_modified_gmt
		 FROM {$wpdb->posts}
		 WHERE post_author = %d
		   AND post_type = 'post'
		   AND post_status NOT IN ( 'inherit', 'trash' )
		   AND (
		     ( post_modified_gmt >= %s AND post_modified_gmt < %s )
		     OR
		     ( post_date_gmt >= %s AND post_date_gmt < %s )
		   )",
		$user_id,
		$start_gmt,
		$end_gmt,
		$start_gmt,
		$end_gmt
	) );

	// Build a date -> set of event types for in-window days only. Year mode
	// returns only days with activity (sparse); trailing28 fills empty days
	// so the legacy heatmap consumer keeps the 28-row contract.
	$by_day = array();

	foreach ( $rows as $row ) {
		$created_local  = opa_rhythm_local_date( $row->post_date_gmt, $tz );
		$modified_local = opa_rhythm_local_date( $row->post_modified_gmt, $tz );

		// Publish event lands on modified date when status is publish.
		if ( 'publish' === $row->post_status && '' !== $modified_local ) {
			opa_rhythm_add_type( $by_day, $modified_local, 'publish' );
		}

		// Any newly created post (regardless of status) counts as an "idea"
		// on its created date. This includes same-day publishes.
		if ( '' !== $created_local ) {
			opa_rhythm_add_type( $by_day, $created_local, 'idea' );
		}

		// A draft was touched if it was modified on a date that isn't the
		// creation date and the post isn't published. Captures "returned to
		// a living draft" without double-counting a same-day publish flip.
		if (
			'publish' !== $row->post_status
			&& '' !== $modified_local
			&& $modified_local !== $created_local
		) {
			opa_rhythm_add_type( $by_day, $modified_local, 'draft' );
		}
	}

	// Inclusive date-string bounds for filtering. DateTimeImmutable is
	// immutable so $end_local is still the original (today for trailing28
	// and current-year mode; Dec 31 for past years) — no off-by-one.
	$start_str = $start_local->format( 'Y-m-d' );
	$end_str   = $end_local->format( 'Y-m-d' );

	$activity_by_day = array();

	if ( 'year' === $range ) {
		// Sparse: only days with activity. Sort ascending by date.
		ksort( $by_day );
		foreach ( $by_day as $date => $types_set ) {
			if ( $date < $start_str || $date > $end_str ) {
				continue;
			}
			$activity_by_day[] = array(
				'date'  => $date,
				'types' => array_values( $types_set ),
			);
		}
	} else {
		// Dense 28-day fill (back-compat). Always exactly 28 entries.
		for ( $i = 0; $i < 28; $i++ ) {
			$date  = $start_local->modify( "+{$i} days" )->format( 'Y-m-d' );
			$types = isset( $by_day[ $date ] ) ? array_values( $by_day[ $date ] ) : array();
			$activity_by_day[] = array(
				'date'  => $date,
				'types' => $types,
			);
		}
	}

	// "Active days this week" — trailing 7 days, regardless of range mode.
	$week_start_str = $today->modify( '-6 days' )->format( 'Y-m-d' );
	$today_str      = $today->format( 'Y-m-d' );
	$active         = 0;
	foreach ( $by_day as $date => $types_set ) {
		if ( $date >= $week_start_str && $date <= $today_str && ! empty( $types_set ) ) {
			$active++;
		}
	}

	return rest_ensure_response( array(
		'active_days_this_week' => $active,
		'activity_by_day'       => $activity_by_day,
		'range'                 => $range,
		'year'                  => 'year' === $range ? (int) $start_local->format( 'Y' ) : null,
	) );
}

/**
 * Add an activity type to the day's set, creating the set on first use.
 * Uses associative keys to dedupe within a day (a post can only contribute
 * one of each type to a single day).
 */
function opa_rhythm_add_type( &$by_day, $date, $type ) {
	if ( ! isset( $by_day[ $date ] ) ) {
		$by_day[ $date ] = array();
	}
	$by_day[ $date ][ $type ] = $type;
}

/**
 * Convert a GMT MySQL datetime to a Y-m-d string in the site timezone.
 * Returns empty string for NULL/empty inputs (e.g. brand-new auto-drafts
 * before WP backfills the modified column).
 */
function opa_rhythm_local_date( $gmt, $tz ) {
	if ( empty( $gmt ) || '0000-00-00 00:00:00' === $gmt ) {
		return '';
	}
	try {
		$dt = new \DateTimeImmutable( $gmt, new \DateTimeZone( 'UTC' ) );
		return $dt->setTimezone( $tz )->format( 'Y-m-d' );
	} catch ( \Exception $e ) {
		return '';
	}
}
