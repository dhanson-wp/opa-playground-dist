<?php
/**
 * Custom REST endpoint that powers the dashboard's rhythm card and the
 * "active days this week" stat. Returns the current user's per-day post
 * activity for the trailing 28 days plus a derived count for the current
 * ISO week.
 *
 * Replaces the v0 hardcoded "5 active days" stub tracked in GH #55.
 *
 * Definitions
 *   "Active day"   — any day where the current user has a post (any status)
 *                    whose post_modified_gmt falls on that local date.
 *   "this week"    — the trailing 7 calendar days ending today (inclusive),
 *                    in the site's timezone. ISO week boundaries would
 *                    shift the count mid-week, which reads as confusing
 *                    on the dashboard.
 *   activity type  — derived per day:
 *                      'published' if any post was published that day
 *                      'idea'      if any post was created that day (no publishes)
 *                      'touched'   if any post was edited that day (no publishes/creates)
 *                      'multi'     if more than one of the above happened that day
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'opa/v1', '/dashboard/rhythm', array(
		'methods'             => 'GET',
		'callback'            => 'opa_rest_dashboard_rhythm',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	) );
} );

function opa_rest_dashboard_rhythm() {
	global $wpdb;

	$user_id = get_current_user_id();
	if ( ! $user_id ) {
		return new \WP_Error(
			'opa_rhythm_no_user',
			'No current user.',
			array( 'status' => 401 )
		);
	}

	$tz = wp_timezone();

	$today    = ( new \DateTimeImmutable( 'now', $tz ) )->setTime( 0, 0, 0 );
	$start_28 = $today->modify( '-27 days' );

	$start_gmt = $start_28->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );

	// Pull every interesting post for the user in the window. Filter to
	// post type 'post' since the dashboard rhythm only tracks blog posts;
	// auto-drafts are included because they represent captured ideas.
	$rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT ID, post_status, post_date_gmt, post_modified_gmt
		 FROM {$wpdb->posts}
		 WHERE post_author = %d
		   AND post_type = 'post'
		   AND post_status NOT IN ( 'inherit', 'trash' )
		   AND ( post_modified_gmt >= %s OR post_date_gmt >= %s )",
		$user_id,
		$start_gmt,
		$start_gmt
	) );

	// Build a date -> set of event types for the 28-day window.
	$by_day = array();
	for ( $i = 0; $i < 28; $i++ ) {
		$date              = $start_28->modify( "+{$i} days" )->format( 'Y-m-d' );
		$by_day[ $date ]   = array(
			'published' => false,
			'idea'      => false,
			'touched'   => false,
		);
	}

	foreach ( $rows as $row ) {
		$created_local  = opa_rhythm_local_date( $row->post_date_gmt, $tz );
		$modified_local = opa_rhythm_local_date( $row->post_modified_gmt, $tz );

		if ( 'publish' === $row->post_status && isset( $by_day[ $modified_local ] ) ) {
			// Use post_modified for the "published on" date — when a draft
			// is flipped to publish, modified_gmt is bumped to that moment.
			$by_day[ $modified_local ]['published'] = true;
			continue;
		}

		// Created today (or in window) and not a publish event.
		if ( isset( $by_day[ $created_local ] ) ) {
			$by_day[ $created_local ]['idea'] = true;
		}

		// Edits land on the modified date if it differs from the created date.
		if (
			$modified_local !== $created_local
			&& isset( $by_day[ $modified_local ] )
		) {
			$by_day[ $modified_local ]['touched'] = true;
		}
	}

	// Project the per-day flags into a single type label.
	$activity_by_day = array();
	$active_dates    = array();
	$today_str       = $today->format( 'Y-m-d' );
	$week_start      = $today->modify( '-6 days' )->format( 'Y-m-d' );

	foreach ( $by_day as $date => $flags ) {
		$type            = opa_rhythm_pick_type( $flags );
		$activity_by_day[] = array(
			'date' => $date,
			'type' => $type,
		);

		if ( '' !== $type && $date >= $week_start && $date <= $today_str ) {
			$active_dates[ $date ] = true;
		}
	}

	return rest_ensure_response( array(
		'active_days_this_week' => count( $active_dates ),
		'activity_by_day'       => $activity_by_day,
	) );
}

/**
 * Convert a GMT MySQL datetime to a Y-m-d string in the site timezone.
 * Returns empty string for NULL/empty inputs (e.g. brand-new auto-drafts
 * before WP backfills the modified column).
 */
function opa_rhythm_local_date( $gmt, $tz ) {
	if ( empty( $gmt ) || '0000-00-00 00:00:00' === $gmt ) {
		return '';
	}
	try {
		$dt = new \DateTimeImmutable( $gmt, new \DateTimeZone( 'UTC' ) );
		return $dt->setTimezone( $tz )->format( 'Y-m-d' );
	} catch ( \Exception $e ) {
		return '';
	}
}

/**
 * Pick the dominant activity type for a day.
 * 'multi' wins when more than one kind of event happened.
 */
function opa_rhythm_pick_type( $flags ) {
	$count = (int) $flags['published'] + (int) $flags['idea'] + (int) $flags['touched'];
	if ( 0 === $count ) {
		return '';
	}
	if ( $count > 1 ) {
		return 'multi';
	}
	if ( $flags['published'] ) {
		return 'published';
	}
	if ( $flags['idea'] ) {
		return 'idea';
	}
	return 'touched';
}
