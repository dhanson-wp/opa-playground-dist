<?php
/**
 * Reusable HTML email shell — opa_email_shell( $args ).
 *
 * Every transactional / branded email Opa sends composes its body via
 * this helper so we ship one visual identity. The shell handles:
 *
 * - doctype + head + viewport + utf-8 charset
 * - preheader (hidden inbox-preview text)
 * - coral brand strip across the top of the email
 * - centered white card with rounded corners + subtle border
 * - "Opa" wordmark in brand coral
 * - h1 heading (configurable)
 * - greeting line ("Hi <name>,")
 * - body paragraphs (array of strings)
 * - primary CTA button (pill radius + coral box-shadow, matches OpaButton)
 * - copy-paste fallback URL beneath the CTA
 * - meta link rows (e.g. "Your site: <url>")
 * - final muted note
 * - outer footer ("Sent from <addr>")
 *
 * Email-client constraints honored:
 * - Inline styles on every visual element (Outlook strips <style>)
 * - Table-based layout (still required for Outlook 2016/2019/365 desktop)
 * - <style> block in <head> with media queries (modern clients honor it;
 *   Outlook ignores but desktop padding base values render fine anyway)
 * - mso-hide:all + display:none for preheader hide in all clients
 *
 * Args (all optional unless noted; defaults applied via array_merge):
 *
 *   subject         string   Tab title; mirror the wp_mail subject. Default 'Opa'.
 *   preheader       string   Hidden inbox-preview text. Default ''.
 *   greeting        string   "Hi <name>," line. Default '' (omitted when empty).
 *   heading         string   H1 text. Required for a meaningful email.
 *   paragraphs      string[] Body paragraphs rendered as <p>. Default [].
 *   cta_label       string   Primary button label. Default '' (omitted when empty).
 *   cta_url         string   Primary button URL. Required if cta_label set.
 *   fallback_intro  string   Text before the copy-paste URL. Default standard.
 *   meta            array[]  Secondary link rows: [{ label, url }, ...]. Default [].
 *   note            string   Final muted paragraph. Default ''.
 *   sender_email    string   Footer "Sent from <addr>". Default opa_get_from_email().
 *
 * Returns the complete <!doctype html>...</html> string ready to pass to
 * wp_mail() as the body. Caller is responsible for setting the
 * Content-Type header to text/html (the existing one-shot filter in
 * email-branding.php handles this for the password-reset path; future
 * emails should do the same).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Inject Content-Type: text/html into wp_mail() headers when the body was
 * produced by opa_email_shell(). Self-tagged via the <!doctype html> prefix.
 *
 * email-branding.php registers a one-shot wp_mail_content_type filter for the
 * password-reset flow, but Pressable's wp_mail wrapper bypasses that filter —
 * the email arrived with text/plain content-type, rendering raw markup in
 * Gmail. Setting the header directly in $args runs before any host wrapper
 * can strip it, so it ships intact.
 */
add_filter( 'wp_mail', 'opa_email_shell_html_content_type' );

function opa_email_shell_html_content_type( $args ) {
	if ( ! is_array( $args ) || empty( $args['message'] ) ) {
		return $args;
	}
	if ( stripos( ltrim( (string) $args['message'] ), '<!doctype html>' ) !== 0 ) {
		return $args;
	}

	$headers = array();
	if ( isset( $args['headers'] ) ) {
		$headers = is_array( $args['headers'] ) ? $args['headers'] : (array) $args['headers'];
	}
	foreach ( $headers as $h ) {
		if ( is_string( $h ) && stripos( ltrim( $h ), 'content-type:' ) === 0 ) {
			return $args;
		}
	}
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
	$args['headers'] = $headers;
	return $args;
}

/**
 * @param array $args See file docblock for the supported keys.
 * @return string Fully-formed HTML email body.
 */
function opa_email_shell( array $args ) {
	$defaults = array(
		'subject'        => 'Opa',
		'preheader'      => '',
		'greeting'       => '',
		'heading'        => '',
		'paragraphs'     => array(),
		'cta_label'      => '',
		'cta_url'        => '',
		'fallback_intro' => "If the button doesn't work, copy and paste this link into your browser:",
		'meta'           => array(),
		'note'           => '',
		'sender_email'   => '',
	);
	$args = array_merge( $defaults, $args );

	if ( $args['sender_email'] === '' && function_exists( 'opa_get_from_email' ) ) {
		$args['sender_email'] = opa_get_from_email();
	}

	ob_start();
	include OPA_PLATFORM_DIR . 'templates/email-shell.php';
	return (string) ob_get_clean();
}
