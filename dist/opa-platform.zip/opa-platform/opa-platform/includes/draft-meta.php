<?php
/**
 * Post-meta-backed dashboard affordances for drafts in the Opa SPA.
 *
 * Two fields, both REST-visible so the React drafts screen can read/write
 * via @wordpress/core-data's useEntityProp('postType','post','meta',postId):
 *
 *   opa_draft_note   — string. A personal sticky-note the user attaches to
 *                      a draft from the dashboard. NOT rendered in the
 *                      published post body; lives only in the drafts grid.
 *
 *   opa_draft_pinned — boolean. When true, the draft floats to a "Pinned"
 *                      section at the top of the dashboard so the user can
 *                      keep specific drafts top-of-mind.
 *
 * Both fields scope to the post's author. We don't want one user pinning
 * or annotating drafts belonging to someone else.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {

	// Personal note (string). Length-capped at 500 to keep this lightweight —
	// it's a sticky-note, not a draft body. If users hit the cap we can lift
	// it later.
	register_post_meta( 'post', 'opa_draft_note', array(
		'type'              => 'string',
		'default'           => '',
		'single'            => true,
		'show_in_rest'      => true,
		'sanitize_callback' => function ( $value ) {
			$value = is_string( $value ) ? $value : '';
			// Trim and cap. wp_strip_all_tags also normalizes line breaks.
			$value = wp_strip_all_tags( $value );
			if ( function_exists( 'mb_substr' ) ) {
				return mb_substr( $value, 0, 500 );
			}
			return substr( $value, 0, 500 );
		},
		'auth_callback'     => function ( $allowed, $meta_key, $object_id ) {
			return current_user_can( 'edit_post', (int) $object_id );
		},
	) );

	// Pinned flag (boolean).
	register_post_meta( 'post', 'opa_draft_pinned', array(
		'type'              => 'boolean',
		'default'           => false,
		'single'            => true,
		'show_in_rest'      => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'auth_callback'     => function ( $allowed, $meta_key, $object_id ) {
			return current_user_can( 'edit_post', (int) $object_id );
		},
	) );
}, 11 ); // priority 11: after the post type is fully registered at default 10
