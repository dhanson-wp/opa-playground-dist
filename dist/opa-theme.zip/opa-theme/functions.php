<?php
/**
 * Opa child theme — frontend layer.
 *
 * Subtractive operations only. Editor curation, admin chrome, dashboard,
 * and site provisioning live in the Opa mu-plugin (mu-plugins/opa-platform/).
 *
 * @package opa-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Disable core block patterns. TT5 may register support at default priority,
 * so we run after.
 */
add_action( 'after_setup_theme', static function () {
	remove_theme_support( 'core-block-patterns' );
}, 11 );

/**
 * Disable the remote pattern directory.
 */
add_filter( 'should_load_remote_block_patterns', '__return_false' );

/**
 * Unregister Twenty Twenty-Five's user-facing patterns.
 *
 * TT5 registers ~70 patterns. Most are marketing-y (banners, pricing, services,
 * testimonials) and have no place in a writing-first product. A handful, however,
 * are referenced internally by TT5's own templates and template parts via
 * <!-- wp:pattern --> tags — removing them empties out the home/archive/single/
 * search/404 templates. We keep that essential set registered.
 *
 * To regenerate the keep-list when TT5 ships a new version:
 *   grep -rh 'wp:pattern' wp-content/themes/twentytwentyfive/{templates,parts}/
 *
 * TT5 registers its patterns on init at default priority; we run after.
 */
add_action( 'init', static function () {
	if ( ! class_exists( 'WP_Block_Patterns_Registry' ) ) {
		return;
	}

	// Patterns referenced by TT5 templates and parts. Keep registered.
	$keep = array(
		// templates/*.html
		'comments',
		'hidden-404',
		'hidden-blog-heading',
		'hidden-search',
		'hidden-written-by',
		'more-posts',
		'post-navigation',
		'template-query-loop',
		// parts/*.html (parent's; defense-in-depth in case any path resolves them)
		'footer',
		'footer-columns',
		'footer-newsletter',
		'header',
		'header-large-title',
		'hidden-sidebar',
		'vertical-header',
	);

	$prefix = 'twentytwentyfive/';
	$registry = WP_Block_Patterns_Registry::get_instance();
	foreach ( $registry->get_all_registered() as $pattern ) {
		if ( ! str_starts_with( $pattern['name'], $prefix ) ) {
			continue;
		}
		$slug = substr( $pattern['name'], strlen( $prefix ) );
		if ( in_array( $slug, $keep, true ) ) {
			continue;
		}
		unregister_block_pattern( $pattern['name'] );
	}
}, 20 );

/**
 * Hide unwanted TT5 templates and template parts from listings.
 *
 * The filter fires for both wp_template and wp_template_part queries; the
 * third argument distinguishes them.
 *
 * @param array  $query_result   Templates returned so far.
 * @param array  $query          Query parameters.
 * @param string $template_type  'wp_template' or 'wp_template_part'.
 * @return array
 */
add_filter( 'get_block_templates', static function ( $query_result, $query, $template_type ) {
	$hidden_templates = array(
		'page-no-title',
	);

	$hidden_parts = array(
		'header-large-title',
		'vertical-header',
		'sidebar',
		'footer-columns',
		'footer-newsletter',
	);

	$hidden = ( $template_type === 'wp_template_part' ) ? $hidden_parts : $hidden_templates;

	return array_values( array_filter(
		$query_result,
		static fn( $template ) => ! in_array( $template->slug, $hidden, true )
	) );
}, 10, 3 );

// (Removed: previous filter set show_in_rest=false on category to hide the
// native taxonomy sidebar panel back when categories weren't part of the
// editing flow. The publish drawer now ships an Opa-canonical Category
// picker (opa-category-picker.js) that reads/writes via core-data, which
// requires the /wp/v2/categories REST route. Leaving the filter in place
// silently broke category creation from the picker — saveEntityRecord
// returned undefined because no entity config existed.)
