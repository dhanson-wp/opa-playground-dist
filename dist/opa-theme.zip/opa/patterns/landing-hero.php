<?php
/**
 * Title: Landing — Hero
 * Slug: opa/landing-hero
 * Categories: opa
 * Description: Centered hero with badge, headline, sub, and two CTAs.
 * Keywords: hero, landing, opa
 * Viewport Width: 1280
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"800px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
	<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"1.5rem"}}} -->
	<div class="wp-block-group">

		<!-- wp:html -->
		<span class="opa-hero-badge">
			<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
			<span>Coming soon</span>
		</span>
		<style>
			.opa-hero-badge { display: inline-flex; align-items: center; gap: 0.375rem; padding: 0.375rem 0.875rem; background: var(--wp--preset--color--coral-light); color: var(--wp--preset--color--coral); border-radius: 999px; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.01em; }
		</style>
		<!-- /wp:html -->

		<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"clamp(2.5rem, 6vw, 3.5rem)","lineHeight":"1.12","letterSpacing":"-0.03em"}}} -->
		<h1 class="wp-block-heading has-text-align-center" style="font-size:clamp(2.5rem, 6vw, 3.5rem);letter-spacing:-0.03em;line-height:1.12">Your space online.<br><em style="font-style:normal;color:var(--wp--preset--color--coral)">Write and publish in seconds.</em></h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"align":"center","fontSize":"large","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"},"spacing":{"margin":{"top":"0.25rem","bottom":"0.5rem"}},"layout":{"selfStretch":"fixed","flexSize":"520px"}}} -->
		<p class="has-text-align-center has-ink-muted-color has-text-color has-large-font-size" style="margin-top:0.25rem;margin-bottom:0.5rem;line-height:1.6">A mobile-first space to write, share, and grow your space online. Start writing in seconds.</p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center","flexWrap":"wrap"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"coral","textColor":"white","style":{"border":{"radius":"999px"},"shadow":"var:preset|shadow|coral","spacing":{"padding":{"top":"0.875rem","right":"2rem","bottom":"0.875rem","left":"2rem"}},"typography":{"fontSize":"0.9375rem","fontWeight":"600"}}} -->
			<div class="wp-block-button has-custom-font-size" style="font-size:0.9375rem;font-weight:600"><a class="wp-block-button__link has-white-color has-coral-background-color has-text-color has-background wp-element-button" href="/signup" style="border-radius:999px;box-shadow:var(--wp--preset--shadow--coral);padding-top:0.875rem;padding-right:2rem;padding-bottom:0.875rem;padding-left:2rem">Join the waitlist</a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-outline","style":{"border":{"radius":"999px","width":"2px","color":"var:preset|color|border"},"color":{"background":"transparent","text":"var:preset|color|ink"},"spacing":{"padding":{"top":"0.875rem","right":"2rem","bottom":"0.875rem","left":"2rem"}},"typography":{"fontSize":"0.9375rem","fontWeight":"600"}}} -->
			<div class="wp-block-button is-style-outline has-custom-font-size" style="font-size:0.9375rem;font-weight:600"><a class="wp-block-button__link has-text-color has-background wp-element-button" href="#features" style="border-color:var(--wp--preset--color--border);border-width:2px;border-radius:999px;color:var(--wp--preset--color--ink);background-color:transparent;padding-top:0.875rem;padding-right:2rem;padding-bottom:0.875rem;padding-left:2rem">See how it works</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
