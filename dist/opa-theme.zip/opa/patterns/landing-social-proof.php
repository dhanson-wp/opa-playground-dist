<?php
/**
 * Title: Landing — Social Proof
 * Slug: opa/landing-social-proof
 * Categories: opa
 * Description: Soft-gray section with three big stats.
 * Keywords: social proof, stats, landing, opa
 * Viewport Width: 1280
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"soft-gray","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","wideSize":"900px"}} -->
<div class="wp-block-group alignfull has-soft-gray-background-color has-background" style="padding-top:4rem;padding-right:var(--wp--preset--spacing--40);padding-bottom:4rem;padding-left:var(--wp--preset--spacing--40)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large","style":{"typography":{"fontWeight":"600"},"spacing":{"margin":{"bottom":"2rem"}}}} -->
	<h2 class="wp-block-heading has-text-align-center has-x-large-font-size" style="margin-bottom:2rem;font-weight:600">Trusted by creators worldwide</h2>
	<!-- /wp:heading -->

	<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"center","verticalAlignment":"top"},"style":{"spacing":{"blockGap":"4rem"}}} -->
	<div class="wp-block-group">

		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"2.25rem","fontWeight":"700","lineHeight":"1.1","fontFamily":"var(--wp--preset--font-family--comfortaa)"},"color":{"text":"var:preset|color|coral"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
			<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--coral);margin-top:0;margin-bottom:0;font-family:var(--wp--preset--font-family--comfortaa);font-size:2.25rem;font-weight:700;line-height:1.1">12K+</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"align":"center","fontSize":"small","textColor":"ink-muted"} -->
			<p class="has-text-align-center has-ink-muted-color has-text-color has-small-font-size">Active creators</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"2.25rem","fontWeight":"700","lineHeight":"1.1","fontFamily":"var(--wp--preset--font-family--comfortaa)"},"color":{"text":"var:preset|color|coral"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
			<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--coral);margin-top:0;margin-bottom:0;font-family:var(--wp--preset--font-family--comfortaa);font-size:2.25rem;font-weight:700;line-height:1.1">3.2M</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"align":"center","fontSize":"small","textColor":"ink-muted"} -->
			<p class="has-text-align-center has-ink-muted-color has-text-color has-small-font-size">Posts published</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"2.25rem","fontWeight":"700","lineHeight":"1.1","fontFamily":"var(--wp--preset--font-family--comfortaa)"},"color":{"text":"var:preset|color|coral"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
			<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--coral);margin-top:0;margin-bottom:0;font-family:var(--wp--preset--font-family--comfortaa);font-size:2.25rem;font-weight:700;line-height:1.1">98%</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"align":"center","fontSize":"small","textColor":"ink-muted"} -->
			<p class="has-text-align-center has-ink-muted-color has-text-color has-small-font-size">Satisfaction rate</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
