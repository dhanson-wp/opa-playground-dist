<?php
/**
 * Title: Landing — CTA
 * Slug: opa/landing-cta
 * Categories: opa
 * Description: Coral gradient CTA box with white headline and pill button.
 * Keywords: cta, conversion, landing, opa
 * Viewport Width: 1280
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"600px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--40)">

	<!-- wp:group {"gradient":"coral-warm","style":{"border":{"radius":"1rem"},"spacing":{"padding":{"top":"3.5rem","right":"2.5rem","bottom":"3.5rem","left":"2.5rem"},"blockGap":"0.75rem"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group has-coral-warm-gradient-background has-background" style="border-radius:1rem;padding-top:3.5rem;padding-right:2.5rem;padding-bottom:3.5rem;padding-left:2.5rem">

		<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xx-large","textColor":"white","style":{"typography":{"fontWeight":"700"}}} -->
		<h2 class="wp-block-heading has-text-align-center has-white-color has-text-color has-xx-large-font-size" style="font-weight:700">Be first to write on Opa.</h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"align":"center","fontSize":"medium","style":{"color":{"text":"rgba(255,255,255,0.85)"},"spacing":{"margin":{"bottom":"1.75rem"}}}} -->
		<p class="has-text-align-center has-text-color has-medium-font-size" style="color:rgba(255,255,255,0.85);margin-bottom:1.75rem">We're letting writers in slowly. Get on the list and we'll save you a spot.</p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"white","textColor":"coral","style":{"border":{"radius":"999px"},"spacing":{"padding":{"top":"0.875rem","right":"2rem","bottom":"0.875rem","left":"2rem"}},"typography":{"fontSize":"0.9375rem","fontWeight":"600"},"shadow":"none"}} -->
			<div class="wp-block-button has-custom-font-size" style="font-size:0.9375rem;font-weight:600"><a class="wp-block-button__link has-coral-color has-white-background-color has-text-color has-background wp-element-button" href="/signup" style="border-radius:999px;box-shadow:none;padding-top:0.875rem;padding-right:2rem;padding-bottom:0.875rem;padding-left:2rem">Join the waitlist →</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->

	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
