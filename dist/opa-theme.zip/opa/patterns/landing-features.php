<?php
/**
 * Title: Landing — Features
 * Slug: opa/landing-features
 * Categories: opa
 * Description: Six-card feature grid with tinted icon tiles.
 * Keywords: features, grid, landing, opa
 * Viewport Width: 1280
 */
?>
<!-- wp:group {"align":"full","anchor":"features","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","wideSize":"1100px"}} -->
<div id="features" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--40)">

	<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"0.75rem","margin":{"bottom":"3rem"}}}} -->
	<div class="wp-block-group" style="margin-bottom:3rem">
		<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xx-large","style":{"typography":{"fontWeight":"600"}}} -->
		<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size" style="font-weight:600">Everything you need to publish</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","fontSize":"medium","textColor":"ink-muted"} -->
		<p class="has-text-align-center has-ink-muted-color has-text-color has-medium-font-size">Write beautifully, grow your audience, and own your content.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"280px"},"style":{"spacing":{"blockGap":"1.5rem"}}} -->
	<div class="wp-block-group">

		<!-- wp:group {"className":"opa-feature-card","style":{"border":{"radius":"1rem","width":"1px","color":"var:preset|color|border"},"spacing":{"padding":{"top":"1.75rem","right":"1.75rem","bottom":"1.75rem","left":"1.75rem"},"blockGap":"1rem"},"color":{"background":"#FFFFFF"}}} -->
		<div class="wp-block-group opa-feature-card has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:1rem;background-color:#FFFFFF;padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem">
			<!-- wp:html -->
			<span class="opa-icon opa-icon-coral" aria-hidden="true">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
			</span>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"typography":{"fontWeight":"600"}}} -->
			<h3 class="wp-block-heading has-large-font-size" style="font-weight:600">Beautiful editor</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"}}} -->
			<p class="has-ink-muted-color has-text-color has-small-font-size" style="line-height:1.6">A distraction-free writing space with rich formatting, embeds, and a real-time preview.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"opa-feature-card","style":{"border":{"radius":"1rem","width":"1px","color":"var:preset|color|border"},"spacing":{"padding":{"top":"1.75rem","right":"1.75rem","bottom":"1.75rem","left":"1.75rem"},"blockGap":"1rem"},"color":{"background":"#FFFFFF"}}} -->
		<div class="wp-block-group opa-feature-card has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:1rem;background-color:#FFFFFF;padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem">
			<!-- wp:html -->
			<span class="opa-icon opa-icon-purple" aria-hidden="true">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
			</span>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"typography":{"fontWeight":"600"}}} -->
			<h3 class="wp-block-heading has-large-font-size" style="font-weight:600">Grow your audience</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"}}} -->
			<p class="has-ink-muted-color has-text-color has-small-font-size" style="line-height:1.6">Built-in subscriber management, email newsletters, and audience analytics.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"opa-feature-card","style":{"border":{"radius":"1rem","width":"1px","color":"var:preset|color|border"},"spacing":{"padding":{"top":"1.75rem","right":"1.75rem","bottom":"1.75rem","left":"1.75rem"},"blockGap":"1rem"},"color":{"background":"#FFFFFF"}}} -->
		<div class="wp-block-group opa-feature-card has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:1rem;background-color:#FFFFFF;padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem">
			<!-- wp:html -->
			<span class="opa-icon opa-icon-success" aria-hidden="true">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
			</span>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"typography":{"fontWeight":"600"}}} -->
			<h3 class="wp-block-heading has-large-font-size" style="font-weight:600">Your own domain</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"}}} -->
			<p class="has-ink-muted-color has-text-color has-small-font-size" style="line-height:1.6">Custom domains, SEO tools, and a public page that's entirely yours to customize.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"opa-feature-card","style":{"border":{"radius":"1rem","width":"1px","color":"var:preset|color|border"},"spacing":{"padding":{"top":"1.75rem","right":"1.75rem","bottom":"1.75rem","left":"1.75rem"},"blockGap":"1rem"},"color":{"background":"#FFFFFF"}}} -->
		<div class="wp-block-group opa-feature-card has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:1rem;background-color:#FFFFFF;padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem">
			<!-- wp:html -->
			<span class="opa-icon opa-icon-sunshine" aria-hidden="true">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="8" r="1.5" fill="currentColor"/><circle cx="8" cy="14" r="1.5" fill="currentColor"/><circle cx="16" cy="14" r="1.5" fill="currentColor"/></svg>
			</span>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"typography":{"fontWeight":"600"}}} -->
			<h3 class="wp-block-heading has-large-font-size" style="font-weight:600">Themes that pop</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"}}} -->
			<p class="has-ink-muted-color has-text-color has-small-font-size" style="line-height:1.6">Choose from curated themes or customize every detail. Make your page unmistakably you.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"opa-feature-card","style":{"border":{"radius":"1rem","width":"1px","color":"var:preset|color|border"},"spacing":{"padding":{"top":"1.75rem","right":"1.75rem","bottom":"1.75rem","left":"1.75rem"},"blockGap":"1rem"},"color":{"background":"#FFFFFF"}}} -->
		<div class="wp-block-group opa-feature-card has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:1rem;background-color:#FFFFFF;padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem">
			<!-- wp:html -->
			<span class="opa-icon opa-icon-coral" aria-hidden="true">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
			</span>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"typography":{"fontWeight":"600"}}} -->
			<h3 class="wp-block-heading has-large-font-size" style="font-weight:600">Email newsletters</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"}}} -->
			<p class="has-ink-muted-color has-text-color has-small-font-size" style="line-height:1.6">Every post becomes a beautiful email. Track opens, clicks, and subscriber growth.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"opa-feature-card","style":{"border":{"radius":"1rem","width":"1px","color":"var:preset|color|border"},"spacing":{"padding":{"top":"1.75rem","right":"1.75rem","bottom":"1.75rem","left":"1.75rem"},"blockGap":"1rem"},"color":{"background":"#FFFFFF"}}} -->
		<div class="wp-block-group opa-feature-card has-background" style="border-color:var(--wp--preset--color--border);border-width:1px;border-radius:1rem;background-color:#FFFFFF;padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem">
			<!-- wp:html -->
			<span class="opa-icon opa-icon-purple" aria-hidden="true">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>
			</span>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"typography":{"fontWeight":"600"}}} -->
			<h3 class="wp-block-heading has-large-font-size" style="font-weight:600">Analytics built in</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","textColor":"ink-muted","style":{"typography":{"lineHeight":"1.6"}}} -->
			<p class="has-ink-muted-color has-text-color has-small-font-size" style="line-height:1.6">See what resonates. Page views, reading time, subscriber sources — all in one dashboard.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<style>
		.opa-icon { display: inline-flex; align-items: center; justify-content: center; width: 44px; height: 44px; border-radius: 0.5rem; }
		.opa-icon-coral    { background: var(--wp--preset--color--coral-light);    color: var(--wp--preset--color--coral); }
		.opa-icon-purple   { background: var(--wp--preset--color--purple-light);   color: var(--wp--preset--color--purple); }
		.opa-icon-success  { background: var(--wp--preset--color--success-light);  color: var(--wp--preset--color--success); }
		.opa-icon-sunshine { background: var(--wp--preset--color--sunshine-light); color: #B8860B; }
		.opa-feature-card { transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease; }
		.opa-feature-card:hover { border-color: var(--wp--preset--color--coral) !important; box-shadow: 0 4px 12px rgba(0,0,0,0.08); transform: translateY(-2px); }
	</style>
	<!-- /wp:html -->

</div>
<!-- /wp:group -->
