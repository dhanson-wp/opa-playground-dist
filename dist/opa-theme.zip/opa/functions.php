<?php
/**
 * Opa theme bootstrap.
 *
 * @package Opa
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'OPA_THEME_VERSION' ) ) {
	define( 'OPA_THEME_VERSION', '0.1.0' );
}

/**
 * Theme supports + asset URI helpers.
 */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'custom-logo', [
		'height'      => 32,
		'width'       => 100,
		'flex-height' => true,
		'flex-width'  => true,
	] );
	add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
} );

/**
 * Register the Opa pattern category so the inserter groups landing patterns together.
 */
add_action( 'init', function () {
	register_block_pattern_category( 'opa', [
		'label'       => __( 'Opa', 'opa' ),
		'description' => __( 'Patterns for the Opa marketing site.', 'opa' ),
	] );
} );

/**
 * Preload the most-used font weights to keep the hero from shifting on first paint.
 *
 * Self-hosted fonts live in assets/fonts/ — see theme.json for the full @font-face registry.
 * Rubik 400 is the body default; Comfortaa 700 is the heading face.
 */
add_action( 'wp_head', function () {
	$base = get_theme_file_uri( 'assets/fonts' );
	$preload = [
		'rubik-400.woff2',
		'comfortaa-700.woff2',
	];
	foreach ( $preload as $file ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin />' . "\n",
			esc_url( "{$base}/{$file}" )
		);
	}
}, 1 );

/**
 * Emit the Opa favicon. The square coral icon mark lives in assets/favicon.svg —
 * we register it via wp_head so it works without a manual Site Identity upload.
 */
add_action( 'wp_head', function () {
	$href = get_theme_file_uri( 'assets/favicon.svg' );
	printf( '<link rel="icon" type="image/svg+xml" href="%s" />' . "\n", esc_url( $href ) );
} );

/**
 * Helper exposed to patterns: the absolute URI of a theme asset.
 *
 * @param string $path Relative path under the theme root, e.g. "assets/logo.svg".
 * @return string Absolute URL.
 */
function opa_asset_uri( $path ) {
	return get_theme_file_uri( ltrim( $path, '/' ) );
}
